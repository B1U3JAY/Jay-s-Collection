package Games;

import java.util.Scanner;

public class TicTacToe {
	
	static char[][] board = new char[3][3];

    public static void printBoard() {
        System.out.println("-------");
        for (int i=0; i < 3; i++) {
            System.out.print("|");
            for (int j=0; j < 3; j++) {
                if (board[i][j] == '\0') {
                    System.out.print(" |");
                } else if (board[i][j] == 'O' || board[i][j] == 'X') {
                    System.out.print(board[i][j] + "|");
                }

            }
            System.out.println();
            System.out.println("-------");
        }
    }

    public static void getInput() {
    	Scanner scanner = new Scanner(System.in);
    	
    	System.out.println("Enter Your Character ('O' or 'X'): ");
    	String c = scanner.next();
    	
    	System.out.println("Enter Your Row #:");
    	int row = scanner.nextInt();

    	System.out.println("Enter Your Column #:");
    	int col = scanner.nextInt();
    	
    	board[row][col] = c.charAt(0);
    }

    public static boolean isWinner() {
    	// Horizontal 
    	if(board[0][0]==board[0][1] && board[0][0]==board[0][2]) {
    		return true;
    	}
    	if(board[1][0]==board[1][1] && board[1][0]==board[1][2]) {
    		return true;
    	}
    	if(board[2][0]==board[2][1] && board[2][0]==board[2][2]) {
    		return true;
    	}
    	
    	// Vertical
    	if(board[0][0]==board[1][0] && board[0][0]==board[2][0]) {
    		return true;
    	}
    	if(board[0][1]==board[1][1] && board[0][1]==board[2][1]) {
    		return true;
    	}
    	if(board[0][2]==board[1][2] && board[0][2]==board[2][2]) {
    		return true;
    	}
    	
    	// Diagonal
    	if(board[0][0]==board[1][1] && board[0][0]==board[2][2]) {
    		return true;
    	}
    	if(board[2][0]==board[1][1] && board[0][2]==board[0][2]) {
    		return true;
    	}
    	
    	return false;
    }

    public static void main(String[] args) {
        while(!isWinner()) {
            getInput();
            printBoard();
        }
	}

}
