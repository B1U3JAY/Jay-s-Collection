package Jay_Art_and_Tech;

public class KinecticArt_MirrorCode2 {
	
	// Mirror Code 1: Mirroring Any Images
	// Mirror Code 2: Domino Effect
	
	public static int numberOfRowMirrors = 10; // Number of rows 
	public static int numberOfColumnMirrors = 10; // Number of columns

	public static void main(String[] args) {
		
		int arr[][] = new int[10][10];
		
		for(int i=0; i<numberOfRowMirrors; i++) {
			for(int j=0; j<numberOfColumnMirrors; j++) {
				arr[i][j] = 0;
			}
		}
		
		
		// Print the whole array
		for(int i=0; i<numberOfRowMirrors; i++) {
			for(int j=0; j<numberOfColumnMirrors; j++) {
				System.out.print(arr[i][j] + "    ");
			}
			System.out.println();
		}
		
		System.out.println();
		
		for(int i=0; i<numberOfRowMirrors; i++) {
			for(int j=0; j<numberOfColumnMirrors; j++) {
				// Update the value in the array one at a time
				if(i%2==0) {
					arr[i][j] = 180;
				}
				else {
					arr[i][9-j] = 180;
				}
				
				// Print the updated array:
				for(int k=0; k<numberOfRowMirrors; k++) {
					for(int l=0; l<numberOfColumnMirrors; l++) {
						System.out.print(arr[k][l] + "  ");
					}
					System.out.println();
				}
				System.out.println();
				
				try {
					Thread.sleep(100);
				} catch (Exception e) {
					
				}
			}
		}
	}

}
