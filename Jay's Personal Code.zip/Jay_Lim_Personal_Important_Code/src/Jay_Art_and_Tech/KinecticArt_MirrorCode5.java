package Jay_Art_and_Tech;

public class KinecticArt_MirrorCode5 {
	
	// Mirror Code 5: Art + Tech Logo

	public static int numberOfRowMirrors = 10; // Number of rows 
	public static int numberOfColumnMirrors = 10; // Number of columns

	public static void main(String[] args) {

		int arr[][] = new int[10][10];

		for(int i=0; i<numberOfRowMirrors; i++) {
			for(int j=0; j<numberOfColumnMirrors; j++) {
				arr[i][j] = 0;
			}
		}


		// Print the whole array
		for(int i=0; i<numberOfRowMirrors; i++) {
			for(int j=0; j<numberOfColumnMirrors; j++) {
				System.out.print(arr[i][j] + "  ");
			}
			System.out.println();
		}

		System.out.println();
		
		int a;
		
		/* Outside 'A' Shape:
		
			arr[8][1] = 1;
			arr[7][1] = 1;
	
			arr[6][2] = 1;
			arr[5][2] = 1;
	
			arr[4][3] = 1;
			arr[3][3] = 1;
	
			arr[2][4] = 1;
			arr[1][4] = 1;
	
			// 
	
			arr[1][5] = 1;
			arr[2][5] = 1;
	
			arr[3][6] = 1;
			arr[4][6] = 1;
	
			arr[5][7] = 1;
			arr[6][7] = 1;
	
			arr[7][8] = 1;
			arr[8][8] = 1;
			
		*/
		
		while(true) {
			// Update the value in the array one at a time
			
			// Outside 'A' Shape:
			
			a = 1; 
			
			for(int i=8; i>=1; i--) {
				arr[i][a] = 1;
				if(i%2==1) {
					a+=1;
				}
			}
			for(int i=1; i<=8; i++) {
				arr[i][a] = 1;
				if(i%2==0) {
					a+=1;
				}
			}

			// Line through the middle for the 'A':

			for(int l=3; l<=6; l++) {
				arr[5][l] = 1;
			}

			// Print the updated array:
			for(int k=0; k<numberOfRowMirrors; k++) {
				for(int l=0; l<numberOfColumnMirrors; l++) {
					System.out.print(arr[k][l] + "  ");
				}
				System.out.println();
			}
			System.out.println();
			
			for(int i=0; i<numberOfRowMirrors; i++) {
				for(int j=0; j<numberOfColumnMirrors; j++) {
					arr[i][j] = 0;
				}
			}
			
			// '+' Shape:
			for(int l=2; l<=7; l++) {
				arr[l][4] = 1;
				arr[l][5] = 1;
			}
			for(int l=2; l<=7; l++) {
				arr[4][l] = 1;
				arr[5][l] = 1;
			}
			
			// Print the updated array:
			for(int k=0; k<numberOfRowMirrors; k++) {
				for(int l=0; l<numberOfColumnMirrors; l++) {
					System.out.print(arr[k][l] + "  ");
				}
				System.out.println();
			}
			System.out.println();
			
			for(int i=0; i<numberOfRowMirrors; i++) {
				for(int j=0; j<numberOfColumnMirrors; j++) {
					arr[i][j] = 0;
				}
			}
			
			// 'T' Shape:
			for(int l=1; l<=8; l++) {
				arr[1][l] = 1;
				arr[2][l] = 1;
			}
			for(int l=3; l<=8; l++) {
				arr[l][4] = 1;
				arr[l][5] = 1;
			}
			
			// Print the updated array:
			for(int k=0; k<numberOfRowMirrors; k++) {
				for(int l=0; l<numberOfColumnMirrors; l++) {
					System.out.print(arr[k][l] + "  ");
				}
				System.out.println();
			}
			System.out.println();
			
			for(int i=0; i<numberOfRowMirrors; i++) {
				for(int j=0; j<numberOfColumnMirrors; j++) {
					arr[i][j] = 0; 
				} 
			}

			try {
				Thread.sleep(100);
			} catch (Exception e) {

			}
		}
	 }
}
