package Jay_Art_and_Tech;

public class KinecticArt_MirrorCode3and4 {
	
	// Mirror Code 3: Spiral-in
	// Mirror Code 4: Spiral-out
	
	public static int direction = 0;
	public static int xArray[] = new int[100];
	public static int yArray[] = new int[100];
	
	public static void main(String[] args) {
		int[][] array = new int[10][10];
		GetSpiralSeqArray(xArray, yArray, 10, 10);
		
		// Outside -> Inside:
		for(int idx=0; idx<=99; idx++) {
			int xpos = xArray[idx]; 
			int ypos = yArray[idx];
			array[xpos][ypos] = 1;
			for(int i=0; i<10; i++) {
				for(int j=0; j<10; j++) {
					System.out.print(array[i][j] + " ");
				}
				System.out.println();
			}
			System.out.println();
			try {
				Thread.sleep(100);
			} catch (Exception e) {
				
			}
		}
		
		System.out.println();
		
		// Inside -> Outside:
		for(int idx=99; idx>=0; idx--) {
			int xpos = xArray[idx]; 
			int ypos = yArray[idx];
			array[xpos][ypos] = 0;
			for(int i=0; i<10; i++) {
				for(int j=0; j<10; j++) {
					System.out.print(array[i][j] + " ");
				}
				System.out.println();
			}
			System.out.println();
			try {
				Thread.sleep(100);
			} catch (Exception e) {

			}
		}
	}
	
	public static void GetSpiralSeqArray(int[] xArray, int[] yArray, int numberOfRowMirrors, int numberOfColumnMirrors) {
		int T = 0; // Top-most row (In this case it is '0')
		int B = numberOfRowMirrors-1; // Bottom-most row (In this case it is '9')
		int L = 0; // Left-most column (In this case it is '0')
		int R = numberOfColumnMirrors-1; // Right-most column (In this case it is '9')
		int index = 0;
		
		while(T<=B && L<=R) { // Repeat the cycle:
			if(direction==0) { // Left To Right
				for(int i=L; i<=R; i++) {
					// System.out.print((array[T][i])); // Example: (0, '0 to 9') (forward) (Note: There were increments and decrements)
					System.out.println("(" + T + "," + i + ") ");
					xArray[index] = T;
					yArray[index] = i;
					index++;
				}
				T++; // Once we took care of the first row, we increment 'T' by '1' so that we can move on to the next row (during the loop).
			}
			else if(direction==1) { // Top to Bottom
				for(int i=T; i<=B; i++) {
					// System.out.print((array[i][R])); // Example: ('1 to 9', 9) (downward) (Note: There were increments and decrements)
					System.out.println("(" + i + "," + R + ") ");
					xArray[index] = i;
					yArray[index] = R;
					index++;
				}
				R--; // Once we took care of the last column, we decrement 'R' by '1' so that we can move on to the column on its left (during the loop).
			}
			else if(direction==2) { // Right-Most Bottom to Left-Most Bottom
				for(int i=R; i>=L; i--) {
					// System.out.print((array[B][i])); // Example: (9, '8 to 0') (backward) (Note: There were increments and decrements)
					System.out.println("(" + B + "," + i + ") ");
					xArray[index] = B;
					yArray[index] = i;
					index++;
				}
				B--; // Once we took care of the last row, we decrement 'B' by '1' so that we can move on to the row above (during the loop).
			}
			else if(direction==3) { // Left-Most Bottom to Top-Most row
				for(int i=B; i>=T; i--) {
					// System.out.print((array[i][L])); // Example: ('8 to 1', 0) (upward) (Note: There were increments and decrements)
					System.out.println("(" + i + "," + L + ") ");
					xArray[index] = i;
					yArray[index] = L;
					index++;
				}
				L++; // Once we took care of the first column, we increment 'L' by '1' so that we can move on to the column on its right (during the loop).
			}
			direction = (direction+1)%4; // We want the value of 'direction' to only be the following: '0', '1', '2', and '3'. So, we use '%4' to get the remainder of numbers greater than '3' so that we can get the values we need.
		}
	}
}
	
