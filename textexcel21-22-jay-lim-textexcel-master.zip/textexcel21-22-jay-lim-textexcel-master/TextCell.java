import java.util.*;

/**
 * Write a description of class TextCell here.
 *
 * @ Jay Lim
 * @ 3/12/22
 */

public class TextCell extends Cell
{
    // instance variables - replace the example below with your own
    private String value;

    /**
     * Constructor for objects of class TextCell
     */
    public TextCell(String value)
    {
        this.value = value;
    }

    public String abbreviatedCellText() {
        System.out.println("Value: " + "{" + value + "}");
        StringBuilder sb = new StringBuilder();
        if(value.length()<=12){
            /*
            if(value.length()==2){
                sb.append("          ");
                return sb.toString();
            }
            */
            sb.append(value.substring(1,value.length()-1));
            if(sb.length()!=10){
                for(int i=sb.length(); i<10; i++){
                    sb.append(" ");
                }
            }
            return sb.toString();
        }
        return value.substring(1, 11);
    }
    
    public String fullCellText() {
        return value ;
    }
}
