
//*******************************************************
//DO NOT MODIFY THIS FILE!!!
//*******************************************************
/**
 * Location interface
 * 
 * @ Jay Lim
 * @ 3/12/22
 */
public class Location
{
    // represents a location like B6
    // must be implemented by your SpreadsheetLocation class
    /**
     * Gets row of this location
     * 
     * @return row
     */
    public int getRow() {
        return 0;
    }

    /**
     * Gets col of this location
     * 
     * @return col
     */
    public int getCol() {
        return 0;
    }
}
