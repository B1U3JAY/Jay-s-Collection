
//*******************************************************
// DO NOT MODIFY THIS FILE!!!
//*******************************************************
/**
 * Cell interface
 * 
 * @ Jay Lim
 * @ 3/12/22
 */
public class Cell
{
    /**
     * Text for spreadsheet cell display, must be exactly length 10
     * 
     * @return string
     */
    public String abbreviatedCellText() {
        return "";
    }

    /**
     * Text for individual cell inspection, not truncated or padded
     * 
     * @return string
     */
    public String fullCellText() {
        return "";
    }
}
