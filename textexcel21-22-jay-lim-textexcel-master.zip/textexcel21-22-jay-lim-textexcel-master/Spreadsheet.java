
/**
 * Spreadsheet
 * 
 * @ Jay Lim
 * @ 3/12/22
 */
import java.util.*;

public class Spreadsheet
{
    private Cell[][] cell;
    private int r, c;
    
    public Spreadsheet(){
        r = 20;
        c = 12;
        cell = new Cell[r][c];
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                cell[i][j] = new EmptyCell();
            }
        }   
        
    }
    
    class TextCellCompare implements Comparator<TextCell>{ 
        public int compare(TextCell c1, TextCell c2){
            return c1.fullCellText().compareTo(c2.fullCellText());
        }
    }
    
    public String processCommand(String command)
    {
        String[] commands = command.split("=", 2);
        // System.out.println(java.util.Arrays.toString(commands));
        if(command.isEmpty()){
            return "";
        }
        else if(commands.length==1){
            if(command.trim().toLowerCase().startsWith("clear")){ // Case 3
                String[] s = command.split(" ");
                if(s.length==1){
                    for (int i = 0; i < r; i++) {
                        for (int j = 0; j < c; j++) {
                            cell[i][j] = new EmptyCell();
                        }
                    }
                }
                else{ // Case 4
                    SpreadsheetLocation sl = new SpreadsheetLocation(s[1].toUpperCase());
                    cell[sl.getRow()][sl.getCol()] = new EmptyCell();
                }
                return getGridText();
            }
            else if(command.trim().toLowerCase().startsWith("sorta")){ // Case 5
                System.out.println("Case 5");
                String[] l = command.split(" ");
                String[] s = l[1].split("-");
                Location loc1 = new SpreadsheetLocation(s[0].toUpperCase());
                Location loc2 = new SpreadsheetLocation(s[1].toUpperCase());
                // System.out.println("loc1:" + loc1.getRow() + ", " + loc1.getCol() + "loc2: " + loc2.getRow() + ", " + loc2.getCol());
                int areaSize= (loc2.getRow()+1-loc1.getRow()) * (loc2.getCol()+1-loc1.getCol());
                ArrayList<TextCell> al = new ArrayList<TextCell>();
                for(int j=loc1.getRow(); j<=loc2.getRow(); j++){
                    for(int i=loc1.getCol(); i<=loc2.getCol(); i++){
                        al.add((TextCell) cell[j][i]);
                        // System.out.println("Cell: " + cell[j][i].fullCellText());
                    }
                }
                TextCellCompare tcc = new TextCellCompare();
                Collections.sort(al, tcc);
                
                for(int j=loc1.getRow(); j<=loc2.getRow(); j++){
                    for(int i=loc1.getCol(); i<=loc2.getCol(); i++){
                        System.out.println("Array Size: " + al.size() + " New Cell Index: " + (((j-loc1.getRow())*(loc2.getRow()-loc1.getRow()+1))+(i-loc1.getCol())));
                        cell[j][i] = al.get(((j-loc1.getRow())*(loc2.getCol()-loc1.getCol()+1))+(i-loc1.getCol()));
                    }
                }
                
                return getGridText();
            }
            else{ // Case 1
                Location loc = new SpreadsheetLocation(command.toUpperCase());
                Cell cell = getCell(loc);
                if(cell instanceof TextCell){
                    return cell.fullCellText();
                }
                return "";
            }
        }
        else if(commands.length==2){ // Case 2
            SpreadsheetLocation sl = new SpreadsheetLocation(commands[0].toUpperCase());
            // System.out.println("Row " + sl.getRow());
            // System.out.println("Col " + sl.getCol());
            cell[sl.getRow()][sl.getCol()] = new TextCell(commands[1].trim());
            // System.out.println("[" + commands[1].trim() + "]");
            return getGridText();
        }
        
        return "";
    }

    public int getRows()
    {
        return r;
    }

    public int getCols()
    {
        return c;
    }

    public Cell getCell(Location loc)
    {
        int lr = loc.getRow();
        int lc = loc.getCol();
        return cell[lr][lc];
    }

    public String getGridText()
    {   
        String str = "   ";
        
        for (int j = 0; j < c; j++) {
            str += "|" + (char)('A'+j) + "         ";
        }
        
        str += "|";
        
        for (int i = 0; i < r; i++) {
            if(i+1<10){
                str += "\n" + (i+1) + "  ";
            }
            else{
                str += "\n" + (i+1) + " ";
            }
            for (int j = 0; j < c; j++) {
                str += "|" + cell[i][j].abbreviatedCellText();
                for (int k = cell[i][j].abbreviatedCellText().length(); k < 10; k++) {
                    str += " ";
                }
            }
            str += "|";
        }
        
        str += "\n";
        
        return str;
    }

}
