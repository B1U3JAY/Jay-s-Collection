
/**
 * Write a description of class EmptyCell here.
 *
 * @ Jay Lim
 * @ 3/12/22
 */
public class EmptyCell extends Cell
{
    public EmptyCell() {
        
    }
    
    public String abbreviatedCellText() {
        return "          ";
    }
}
