
//Update this file with your own code.
/**
 * Represents a location in the spreadsheet
 *
 * @ Jay Lim
 * @ 3/12/22
 */
public class SpreadsheetLocation extends Location
{
    private String cellName;
    
    @Override
    public int getRow()
    {
        int val = 0;
        // System.out.println(cellName.length());
        val = cellName.charAt(1)-'0'; // '0' = 48
        if(cellName.length()==3){
            val = val*10 + cellName.charAt(2) - '0'; 
        }
        return val - 1;
    }

    @Override
    public int getCol()
    {
        int c = cellName.charAt(0) - 'A'; // 'A' = 65; (ASCII Value)
        return c;
    }

    /**
     * Constructor
     * 
     * @param cellName Name of cell, like "A1"
     */
    public SpreadsheetLocation(String cellName)
    {
        this.cellName = cellName.trim();
    }

}
