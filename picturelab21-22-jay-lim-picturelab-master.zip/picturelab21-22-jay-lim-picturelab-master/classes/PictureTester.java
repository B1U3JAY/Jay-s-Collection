/**
 * This class contains class (static) methods
 * that will help you test the Picture class 
 * methods.  Uncomment the methods and the code
 * in the main to test.
 * 
 * @author Barbara Ericson 
 * @version (a version number or a date)
 */
public class PictureTester
{
    /** Method to test zeroBlue */
    public static void testZeroBlue()
    {
        Picture beach = new Picture("beach.jpg");
        beach.explore();
        beach.zeroBlue();
        beach.explore();
    }

    /** Method to test mirrorVertical */
    public static void testMirrorVertical()
    {
        Picture caterpillar = new Picture("caterpillar.jpg");
        caterpillar.explore();
        caterpillar.mirrorVertical();
        caterpillar.explore();
    }

    /** Method to test mirrorTemple */
    public static void testMirrorTemple()
    {
        Picture temple = new Picture("temple.jpg");
        temple.explore();
        temple.mirrorTemple();
        temple.explore();
    }

    /** Method to test the collage method */
    public static void testCollage()
    {
        Picture canvas = new Picture("640x480.jpg");
        canvas.createCollage();
        canvas.explore();
    }

    /** Method to test edgeDetection */
    public static void testEdgeDetection()
    {
        Picture swan = new Picture("swan.jpg");
        swan.edgeDetection(10);
        swan.explore();
    }
    
    public static void testNegate() {
        Picture beach = new Picture("beach.jpg");
        beach.negate();
        beach.explore();
    }
    
    public static void testGrayscale() {
        Picture beach = new Picture("beach.jpg");
        beach.grayscale();
        beach.explore();
    }
    
    public static void testFixUnderwater() {
        Picture beach = new Picture("water.jpg");
        beach.fixUnderwater();
        beach.explore();
    }
    
    public static void testMirrorVerticalRightToLeft()
    {
        Picture redMotorcycle = new Picture("redMotorcycle.jpg");
        redMotorcycle.explore();
        redMotorcycle.mirrorVerticalRightToLeft();
        redMotorcycle.explore();
    }
    
    public static void testMirrorHorizontal()
    {
        Picture redMotorcycle = new Picture("redMotorcycle.jpg");
        redMotorcycle.explore();
        redMotorcycle.mirrorHorizontal();
        redMotorcycle.explore();
    }
    
    public static void testMirrorHorizontalBotToTop()
    {
        Picture caterpillar = new Picture("redMotorcycle.jpg");
        caterpillar.explore();
        caterpillar.mirrorHorizontalBotToTop();
        caterpillar.explore();
    }
    
    public static void testMirrorDiagonal()
    {
        Picture beach = new Picture("beach.jpg");
        beach.explore();
        beach.mirrorDiagonal();
        beach.explore();
    }
    
    public static void testMirrorArms()
    {
        Picture snowman = new Picture("snowman.jpg");
        snowman.explore();
        snowman.mirrorArms();
        snowman.explore();
    }
    
    public static void testMirrorGull()
    {
        Picture seagull = new Picture("seagull.jpg");
        seagull.explore();
        seagull.mirrorGull();
        seagull.explore();
    }
    
    public static void testCopy()
    {
        Picture seagull = new Picture("seagull.jpg");
        seagull.explore();
        seagull.copy(seagull, 250, 250);
        seagull.explore();
    }
    
    public static void testCopy2() {
        Picture seagull = new Picture("seagull.jpg");
        seagull.explore();
        seagull.copy(seagull, 350, 350, 225, 225, 325, 350);
        seagull.explore();
    }
    
    public static void testCollage2()
    {
        Picture canvas = new Picture("640x480.jpg");
        canvas.createCollage2();
        canvas.explore();
    }
    
    public static void testEdgeDetection2()
    {
        Picture swan = new Picture("swan.jpg");
        swan.edgeDetection2(10);
        swan.explore();
    }
    
    public static void testEdgeDetection3()
    {
        Picture swan = new Picture("swan.jpg");
        swan.edgeDetection2(10);
        swan.explore();
    }
    
    public static void changeAlien() {
        Picture aquaAlien = new Picture("AquaAlien.jpg");
        aquaAlien.mirrorHorizontal();
        aquaAlien.explore();
    }
    
    public static void changeOreo() {
        Picture oreo = new Picture("OreoMini.jpg");
        Picture oreoMini = oreo.scale(0.1, 0.1);
        oreoMini.edgeDetection2(10);
        oreoMini.explore();
    }

    /** Main method for testing.  Every class can have a main
     * method in Java
     * 
     * @param args Not used.
     */
    public static void main(String[] args)
    {
        // uncomment a call here to run a test
        // and comment out the ones you don't want
        // to run
        // Picture Lab Part 1 Work:
        //testZeroBlue();
        //testKeepOnlyBlue();
        //testKeepOnlyRed();
        //testKeepOnlyGreen();
        //testNegate();
        //testGrayscale();
        //testFixUnderwater();
        //testMirrorVertical();
        //testMirrorVerticalRightToLeft();
        //testMirrorHorizontal();
        //testMirrorHorizontalBotToTop();
        //testMirrorTemple();
        //testMirrorArms();
        //testMirrorGull();
        //testMirrorDiagonal();
        //testCollage();
        //testCopy();
        //testCopy2();
        //testCollage2();
        //testEdgeDetection();
        //testEdgeDetection2();
        //testEdgeDetection3();
        //testChromakey();
        //testEncodeAndDecode();
        //testGetCountRedOverValue(250);
        //testSetRedToHalfValueInTopHalf();
        //testClearBlueOverValue(200);
        //testGetAverageForColumn(0);
        
        // Picture Lab Part 2 Work:
        //changeAlien();
        //changeOreo();
    }
}