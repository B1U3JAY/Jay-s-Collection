import java.awt.Image;
import java.awt.image.BufferedImage;

/**
 * Interface to describe a digital picture.  A digital picture can have an 
 * associated file name.  It can have a title.  It has pixels 
 * associated with it and you can get and set the pixels.  You 
 * can get an Image from a picture or a BufferedImage.  You can load
 * it from a file name or image.  You can show a picture.  You can 
 * explore a picture.  You can create a new image for it.
 * 
 * @author Barb Ericson ericson@cc.gatech.edu
 * @version 1.0
 */
public interface DigitalPicture 
{
    /**
     * Get the file name that the picture came from.
     * 
     * @return file name
     */
    public String getFileName();
    
    /**
     * Get the title of the picture.
     * 
     * @return title
     */
    public String getTitle();
    
    /**
     * Set the title of the picture.
     * 
     * @param title Title
     */
    public void setTitle(String title);
    
    /**
     * Get the width of the picture in pixels.
     * 
     * @return width
     */
    public int getWidth();
    
    /**
     * Get the height of the picture in pixels.
     * 
     * @return height
     */
    public int getHeight();
    
    /**
     * Get the image from the picture.
     * 
     * @return image
     */
    public Image getImage();
    
    /**
     * Get the buffered image.
     * 
     * @return buffered image
     */
    public BufferedImage getBufferedImage();
    
    /**
     * Get the pixel information as an int.
     * 
     * @param x x
     * @param y y
     * @return pixel information
     */
    public int getBasicPixel(int x, int y); 
    
    /**
     * Set the pixel information.
     * 
     * @param x x
     * @param y y
     * @param rgb RBG values
     */
    public void setBasicPixel(int x, int y, int rgb);
    
    /** 
     * Get the pixel information as an object
     * 
     * @param x x
     * @param y y
     * @return Pixel the object
     */
    public Pixel getPixel(int x, int y);
    
    /**
     * Get all pixels in row-major order.
     * 
     * @return Pixel[] array of pixels
     */
    public Pixel[] getPixels();
    
    /**
     * Get 2-D array of pixels in row-major order.
     * 
     * @return Pixel[][] array of pixels
     */
    public Pixel[][] getPixels2D();
    
    /**
     * Load the image into the picture.
     * 
     * @param image the object
     */
    public void load(Image image);
    
    /**
     * Load the picture from a file
     * 
     * @param fileName name of file
     * @return boolean success
     */
    public boolean load(String fileName);
    
    /**
     * Show the picture.
     */
    public void show();
    
    /**
     * Explore the picture.
     */
    public void explore();
    
    /**
     * Write out a file.
     * 
     * @param fileName name of file
     * @return boolean success
     */
    public boolean write(String fileName);
}
