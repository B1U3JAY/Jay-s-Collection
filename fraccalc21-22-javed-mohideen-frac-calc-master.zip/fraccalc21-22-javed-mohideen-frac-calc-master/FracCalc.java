import java.util.*; 

/**
 * Calculates fractions.
 */
public class FracCalc {

    /**
     * Runs a fraction calculator.
     * 
     * @param args Not used
     */
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        // System.out.println("Input Expression: ");
        String input = inputScanner.nextLine();
        
        System.out.println(produceAnswer(input));
        
    }

    /**
     * ** IMPORTANT ** DO NOT DELETE THIS FUNCTION.
     * This function will be used to test your code
     * This function takes a String 'input' and produces the result
     * 
     * @param input A fraction string that needs to be evaluated.
     * For your program, this will be the user input.
     *     e.g. input ==> "1/2 + 3/4"
     * @return The result of the fraction after it has been calculated
     *     e.g. return ==> "1_1/4"
     */
    public static String produceAnswer(String input)
    { 
        char tempInt;
        String frac1;
        String frac2;
        char operator;
        String solution;
        int num1 = 0;
        int num2 = 0;
        int p1 = 0;
        int p2 = 0;
        int q1 = 1;
        int q2 = 1;
   
        int spaceIndex = input.indexOf(' ');
        int underscore1 = 0;
        int underscore2 = 0;

        frac1 = input.substring(0, spaceIndex);
        // System.out.println("1st Operand: " + frac1);
        frac2 = input.substring(spaceIndex + 3, input.length());
        // System.out.println("2nd Operand: " + frac2);
        operator = input.charAt(spaceIndex + 1);
        // System.out.println("Operator: " + operator);
        
        // Fraction 1:
        
        // In case there is a whole number:
        if (frac1.indexOf('_') != -1) {
        	underscore1 = frac1.indexOf('_');
            num1 = Integer.parseInt(frac1.substring(0, underscore1++));  
        }
        // In case there is a fraction:
        if (frac1.indexOf('/') != -1) {
            p1 = Integer.parseInt(frac1.substring(underscore1, frac1.indexOf('/')));
            q1 = Integer.parseInt(frac1.substring(frac1.indexOf('/') + 1, frac1.length()));
        }
        // If case there is only a whole number:
        else {
        	num1 = Integer.parseInt(frac1);  
        }
        
        // Fraction 2:
        
        if (frac2.indexOf('_') != -1) {
        	underscore2 = frac2.indexOf('_');
            num2 = Integer.parseInt(frac2.substring(0, underscore2++));  
        }
        // In case there is a fraction:
        if (frac2.indexOf('/') != -1) {
            p2 = Integer.parseInt(frac2.substring(underscore2, frac2.indexOf('/')));
            q2 = Integer.parseInt(frac2.substring(frac2.indexOf('/') + 1, frac2.length()));
        }
        // If case there is only a whole number:
        else {
        	num2 = Integer.parseInt(frac2);  
        }
        
        
        
        // Calculation:
        
        int improperNumerator1, improperNumerator2;
        
        if(num1*q1<0) {
        	improperNumerator1 = num1*q1-p1;
        }
        else {
        	improperNumerator1 = num1*q1+p1;
        }
        
        if(num2*q2<0) {
        	improperNumerator2 = num2*q2-p2;
        }
        else {
        	improperNumerator2 = num2*q2+p2;
        }
        
        int LCD = q1;
        
        int calculatedNumerator = 0;
        int calculatedDenominator = 0;
        
        // System.out.println("Improper Numerator1: " + improperNumerator1);
        // System.out.println("Improper Numerator2: " + improperNumerator2);
        
        if(operator == '+') {
        	// Make denominator the same:
            if(q1!=q2) {
            	LCD = LCD(q1, q2);
            }
            
            improperNumerator1 *= LCD/q1;
            improperNumerator2 *= LCD/q2;
            
            // System.out.println("LCD: " + LCD);
            
            // System.out.println("Improper Numerator1: " + improperNumerator1);
            // System.out.println("Improper Numerator2: " + improperNumerator2);
            
        	calculatedNumerator = improperNumerator1 + improperNumerator2;
        	calculatedDenominator = LCD;
        	
        	// System.out.println("Calculated Numerator: " + calculatedNumerator);
        	// System.out.println("Calculated Denominator: " + calculatedDenominator);
        }
        else if(operator == '-') {
        	// Make denominator the same:
            if(q1!=q2) {
            	LCD = LCD(q1, q2);
            }
            
            improperNumerator1 *= LCD/q1;
            improperNumerator2 *= LCD/q2;
            
        	calculatedNumerator = improperNumerator1 - improperNumerator2;
        	calculatedDenominator = LCD;
        }
        else if(operator == '*') {
        	calculatedNumerator = improperNumerator1 * improperNumerator2;
        	calculatedDenominator = q1 * q2;
        }
        else if(operator == '/') {
        	calculatedNumerator = improperNumerator1 * q2;
        	calculatedDenominator = q1 * improperNumerator2;
        }
        
        int GCFOfNums = GCF(Math.abs(calculatedNumerator), calculatedDenominator);
        
        calculatedNumerator /= GCFOfNums;
        calculatedDenominator /= GCFOfNums;
        // System.out.println(GCFOfNums);
        
        // Switch from improper to mixed fraction(s):
        int wholeNum = calculatedNumerator/calculatedDenominator;
        calculatedNumerator %= calculatedDenominator;
        
        // return "Whole: " + num2 + " Numerator: " + p2 + " Denominator: " + q2;
        if(wholeNum != 0){
        	if(calculatedNumerator == 0) {
        		return "" + wholeNum;
        	}
        	return wholeNum + "_" + Math.abs(calculatedNumerator) + "/" + Math.abs(calculatedDenominator);
        }
        else {
        	if(calculatedNumerator == 0) {
        		return "0";
        	}
        	return calculatedNumerator + "/" + Math.abs(calculatedDenominator);
        }
        
    }

    // TODO: Fill in the space below with any helper methods

    public static int LCD(int p, int q) {
        return (p*q/GCF(p,q));
    }
    
    public static int GCF(int p, int q) {
        while (q != 0) {
            int temp = q;
            q = p % q;
            p = temp;
            // System.out.println("p: " + p + " q: " + q);
        }
        return p;
    }

}
