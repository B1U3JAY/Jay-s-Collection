public class Caterpillar extends Animal {
    private int move = 1;
    
    public Caterpillar(int r, int c) {
        super(r, c);
    }
    
    public void move() {
        if(move%3==1){
            setCol(getCol() + 1);
            move++;
        }
        else{
            move++;
        }
    }
    
    public Animal evolve() {
        if(move==10){
            return new Chrysalis(getRow(), getCol());
        }
        return this;
    }

    public String toGridLetter() {
        return "~";
    }
}
