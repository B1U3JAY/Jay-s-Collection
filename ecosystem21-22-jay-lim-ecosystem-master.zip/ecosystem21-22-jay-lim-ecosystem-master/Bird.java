public class Bird extends Animal {
    private int count = 0;
    private boolean goUp = true;
    
    public Bird(int r, int c) {
        super(r, c);
    }
    
    public void move() {
        if(count==10){
            goUp = false;
        }
        if(count==0){
            goUp = true;
        }
        
        if(goUp){
            setRow(getRow() - 1);
            count++;
        }
        else {
            setRow(getRow() + 1);
            count--;
        }
    }
    
    public void interactWith(Animal other, World world) { 
        if(other instanceof Caterpillar){
            if(Math.abs(getCol()-other.getCol()) <= 1 && getRow()==other.getRow() || Math.abs(getRow()-other.getRow()) <= 1 && getCol()==other.getCol()){
                world.removeAnimal(other);
                return;
            }

        }
    }

    public String toGridLetter() {
        return "^";
    }
}
