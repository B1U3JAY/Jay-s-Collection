/*

Q1: Then it shows up to the far right side of the grid.
Q2: You can change the EnergizerBunny's position through the constructor by changing the r and c values.
Q3: You can change the World's size through the constructor by changing the r and c values.
Q4: It compiles because the Animal class also has a move method. Therefore, the program still runs but EnergizerBunny doesn't move.
Q5: You can add 1 instead of subtracting 1. In order to move down you can call the getRow() method and add 1.
Q6: You can change the return value of the 'toGridLetter' method as a different character.
Q7: You can add another EnergizerBunny to the 'Animal' ArrayList.
Q8: If multiple bunnies occupy the same position an '*' takes it place.
Q9: You can change it to '- 3' instead of '- 1' in the move method in order to move it three spaces isntead of 1.

 */
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        World world = new World(10, 10);
        
        //world.addAnimal(new EnergizerBunny(2, 5));
        //world.addAnimal(new Bird(9, 0));
        //world.addAnimal(new Rabbit(0, 2));
        //world.addAnimal(new Rabbit(0, 3));
        world.addAnimal(new Cat(0, 3));
        world.addAnimal(new Mouse(1, 5));
        //world.addAnimal(new Caterpillar(3, 5));
        
        //world.addAnimal(new Deer(7, 9));
        //world.addAnimal(new Deer(9, 9));
        //world.addAnimal(new BabyDragon(5, 5));
        
        mainLoop(world);
    }

    private static void mainLoop(World world) {    
        Scanner console = new Scanner(System.in);
        String line;
        do {
            clearConsole();
            System.out.println(world);
            System.out.println("(Enter to continue, q to quit)");
            line = console.nextLine();
            world.tick();
        } while(!line.equals("q"));
    }

    /* doesn't seem to work in REPL classroom assignment. */
    private static void clearConsole() {
        System.out.print('\u000C');
    }
}
