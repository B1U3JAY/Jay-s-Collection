public class EnergizerBunny extends Animal {
    public EnergizerBunny(int r, int c) {
        super(r, c);
    }
    
    public void move() {
        setCol(getCol() - 1);
    }

    public String toGridLetter() {
        return "E";
    }
}
