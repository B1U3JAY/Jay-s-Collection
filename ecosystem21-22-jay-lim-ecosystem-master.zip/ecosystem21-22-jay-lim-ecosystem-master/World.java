import java.util.List;
import java.util.ArrayList;

public class World {
    private List<Animal> animals;
    private List<Animal>[][] grid;

    public World(int r, int c) {
        animals = new ArrayList<Animal>();
        grid = new List[r][c];  // causes unchecked warning
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                grid[i][j] = new ArrayList<Animal>();
            }
        }
    }

    public void addAnimal(Animal a) {
        normalizeAnimalCoordinates(a);
        animals.add(a);
        grid[a.getRow()][a.getCol()].add(a);
    }

    public void removeAnimal(Animal a) {
        animals.remove(a);
        grid[a.getRow()][a.getCol()].remove(a);
    }

    public void tick() {
        for (int i = animals.size() - 1; i >= 0; i--) {
            Animal a = animals.get(i);
            // remove the animal from its old place
            // grid[a.getRow()][a.getCol()].remove(a);
            removeAnimal(a);

            // update the animal's position
            a.move();
            normalizeAnimalCoordinates(a);

            // get the evolved form of the Animal
            Animal ea = a.evolve();

            // add the animal to its new place
            // grid[ea.getRow()][ea.getCol()].add(ea);
            addAnimal(ea);
        }

        // run through each pair of animals and call interactWith
        ArrayList<Animal> copy = new ArrayList<Animal>(animals);
        for (int i = 0; i < copy.size(); i++) {
            for (int j = 0; j < copy.size(); j++) {
                if (i == j) {
                    // animal cannot interact with itself
                    continue;
                }
                Animal first = copy.get(i);
                Animal second = copy.get(j);
                first.interactWith(second, this);
            }
        }
    }

    public String toString() {
        String gridStr = "";
        String header = "o";
        for (int j = 0; j < getNumberOfCols(); j++) {
            header += "-";
        }
        header += "o\n";
        gridStr += header;
        for (int i = 0; i < getNumberOfRows(); i++) {
            // start of row
            gridStr += "|";
            for (int j = 0; j < getNumberOfCols(); j++) {
                if (grid[i][j].size() == 0) {
                    // no animals at this position
                    gridStr += " ";
                } else if (grid[i][j].size() == 1) {
                    // exactly one animal at this position
                    // print its representative character
                    gridStr += grid[i][j].get(0).toGridLetter().charAt(0);
                } else {
                    // multiple animals occupying one space
                    // print * to indicate multiple
                    gridStr += "*";
                }
            }
            // add new line for end of row
            gridStr += "|\n";
        }
        gridStr += header;
        return gridStr;
    }

    private void normalizeAnimalCoordinates(Animal a) {
        // wrap the Animal's position so it's always in the grid
        a.setRow(Math.floorMod(a.getRow(), getNumberOfRows()));
        a.setCol(Math.floorMod(a.getCol(), getNumberOfCols()));
    }

    private int getNumberOfRows() {
        return grid.length;
    }

    private int getNumberOfCols() {
        if (grid.length == 0) {
            return 0;
        }
        return grid[0].length;
    }
}
