import java.util.Random;

public class Dragon extends Animal {
    private int move = 1;
    private boolean chaseMode = false;
    private int chaseMCol;
    private int chaseMRow;
    Random r = new Random();
    private int rn;
    
    public Dragon(int r, int c) {
        super(r, c);
    }
    
    public void move() { // I made it move by 2 in any direction with the addition of diagonal movement as well (which the BabyDragon could not). When it enters chaseMode it will move even faster than the BabyDragon (because it evolved from it).
        if(chaseMode==false){
            rn = r.nextInt(8);
            switch(rn){
                case 0: setRow(getRow() - 2);
                        break;
                case 1: setRow(getRow() + 2);
                        break;
                case 2: setCol(getCol() + 2);
                        break;
                case 3: setCol(getCol() - 2);
                        break;
                case 4: setCol(getCol() - 2); 
                        setRow(getRow() - 2); 
                        break;
                case 5: setCol(getCol() - 2); 
                        setRow(getRow() + 2);
                        break;            
                case 6: setCol(getCol() + 2); 
                        setRow(getRow() - 2); 
                        break;          
                case 7: setCol(getCol() + 2);
                        setRow(getRow() + 2);
                        break;
            }
        }
        else {
            if(chaseMCol<0){
                setCol(getCol() + 3);
            }
            else{
                setCol(getCol() - 3);
            }
            
            if(chaseMRow<0){
                setCol(getCol() + 3);
            }
            else{
                setCol(getCol() - 3);
            }
            chaseMode=false;
        }
        move++;
    }
    
    public void interactWith(Animal other, World world) { // Now that it is an adult dragon, it can eat EVRERYTHING!
        if(Math.abs(getCol()-other.getCol()) <= 2 && getRow()==other.getRow() || Math.abs(getRow()-other.getRow()) <= 2 && getCol()==other.getCol()){
            world.removeAnimal(other);
        }
                        
        if(Math.abs(getCol()-other.getCol()) <= 5 && getRow()==other.getRow()){
            chaseMCol = getCol()-other.getCol();
            chaseMode=true;
        }
        else if(Math.abs(getRow()-other.getRow()) <= 5 && getCol()==other.getCol()){
            chaseMRow = getRow()-other.getRow();
            chaseMode=true;
        }          
    }

    public String toGridLetter() {
        return "}";
    }
}
