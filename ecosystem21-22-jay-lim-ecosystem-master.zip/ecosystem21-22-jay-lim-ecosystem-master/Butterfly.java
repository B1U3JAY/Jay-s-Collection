import java.util.Random;

public class Butterfly extends Animal {
    private int move = 1;
    Random rn = new Random();
    
    public Butterfly(int r, int c) {
        super(r, c);
    }
    
    public void move() {
        int n = rn.nextInt(4);
        switch(n){
            case 0: setCol(getCol() - 1); 
                    setRow(getRow() - 1); 
                    break;
            case 1: setCol(getCol() - 1); 
                    setRow(getRow() + 1);
                    break;            
            case 2: setCol(getCol() + 1); 
                    setRow(getRow() - 1); 
                    break;          
            case 3: setCol(getCol() + 1);
                    setRow(getRow() + 1);
                    break;
        }
        move++;
    }
    
    public Animal evolve() {
        return this;
    }

    public String toGridLetter() {
        return "%";
    }
}
