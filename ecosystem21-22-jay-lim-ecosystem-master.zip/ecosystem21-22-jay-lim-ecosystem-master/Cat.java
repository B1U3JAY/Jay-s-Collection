public class Cat extends Animal {
    private int move = 1;
    private boolean chaseMode = false;
    private int chaseMCol;
    private int chaseMRow;
    
    public Cat(int r, int c) {
        super(r, c);
    }
    
    public void move() {
        if(chaseMode==false){
            if(move%4==0){
                move++;
                return;
            }
            else{
                setCol(getCol() - 1);
                move++;
            }
        }
        else {
            if(chaseMCol<0){
                setCol(getCol() + 2);
            }
            else{
                setCol(getCol() - 2);
            }
            
            if(chaseMRow<0){
                setRow(getRow() + 2);
            }
            else{
                setRow(getRow() - 2);
            }
            chaseMode=false;
        }
    }
    
    public void interactWith(Animal other, World world) { 
        if(other instanceof Mouse){
            if(Math.abs(getCol()-other.getCol()) <= 1 && getRow()==other.getRow() || Math.abs(getRow()-other.getRow()) <= 1 && getCol()==other.getCol()){
                world.removeAnimal(other);
                return;
            }
            
            if(Math.abs(getCol()-other.getCol()) <= 5 && getRow()==other.getRow()){
                chaseMCol = getCol()-other.getCol();
                chaseMode=true;
                return;
            }
            else if(Math.abs(getRow()-other.getRow()) <= 5 && getCol()==other.getCol()){
                chaseMRow = getRow()-other.getRow();
                chaseMode=true;
                return;
            }
        }
    }

    public String toGridLetter() {
        return "ω";
    }
}
