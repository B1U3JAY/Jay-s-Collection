public class Animal {
    private int row;
    private int col;

    public Animal() {
        this(0, 0);
    }

    public Animal(int r, int c) {
        setRow(r);
        setCol(c);
    }

    public int getRow() { return row; }

    public int getCol() { return col; }

    public void setRow(int r) { row = r; }

    public void setCol(int c) { col = c; }

    /** Subclasses must implement this and update row and col
    for one "tick" of the clock. */
    public void move() {
        
    }

    /** Subclasses must implement this and return one character
    specific to the animal which will appear in the grid. */
    public String toGridLetter() {
        return "";
    }

    /** Subclasses may override this and return a new Animal
    that this instance evolves into. If the Animal should not
    change, then write `return this`. */
    public Animal evolve() {
        return this;
    }

    /** Subclasses may override this and update the World's
    state depending on the interaction with the other animal.
    You should not update Animal positions in this method. */
    public void interactWith(Animal other, World world) { 
    }
}
