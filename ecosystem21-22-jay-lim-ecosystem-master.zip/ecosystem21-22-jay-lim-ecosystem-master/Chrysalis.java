import java.util.Random;

public class Chrysalis extends Caterpillar {
    private int move = 1;
    
    public Chrysalis(int r, int c) {
        super(r, c);
    }
    
    public void move() {
        move++;
        return;
    }
    
    public Animal evolve() {
        if(move==10){
            return new Butterfly(getRow(), getCol());
        }
        return this;
    }

    public String toGridLetter() {
        return "0";
    }
}
