import java.util.Random;

public class Deer extends Animal {
    private int move = 1;
    private boolean RunAway = false;
    private int runMCol;
    private int runMRow;
    Random r = new Random();
    private int rn;
    
    public Deer(int r, int c) {
        super(r, c);
    }
    
    public void move() { // I made it move randomly in any direction by 1 because a deer kind of wanders around in life. When it needs to run it will go faster.
        if(RunAway==false){
            rn = r.nextInt(4);
            if(rn==0){
                setRow(getRow() - 1);
            }
            else if(rn==1){
                setRow(getRow() + 1);
            }
            else if(rn==2){
                setCol(getCol() + 1);
            }
            else if(rn==3){
                setCol(getCol() - 1);
            }
        }
        else {
            if(runMCol<0){
                setCol(getCol() - 2);
            }
            else{
                setCol(getCol() + 2);
            }
            
            if(runMRow<0){
                setCol(getCol() - 2);
            }
            else{
                setCol(getCol() + 2);
            }
            RunAway=false;
        }
    }
    
    public void interactWith(Animal other, World world) { // The idea of the Deer is that when it is in a certain range with the Dragon it will run (away) faster (like in real life). If two deer come in contact, they will reproduce another pair of deer.
        if(other instanceof Dragon){
            if(Math.abs(getCol()-other.getCol()) <= 3 && getRow()==other.getRow()){
                runMCol = getCol()-other.getCol();
                RunAway=true;
                return;
            }
            else if(Math.abs(getRow()-other.getRow()) <= 3 && getCol()==other.getCol()){
                runMRow = getRow()-other.getRow();
                RunAway=true;
                return;
            }
        }
        
        if(other instanceof Deer){
            if(Math.abs(getCol()-other.getCol()) <= 1 && getRow()==other.getRow() || Math.abs(getRow()-other.getRow()) <= 1 && getCol()==other.getCol()){
                world.addAnimal(new Deer(getRow()+1, getCol())); // Moves 3 spaces down, but when you hit 'Enter' it also calls 'move()' so it moves the new reproduced Rabbits as well.
                return;
            }
        }
    }

    public String toGridLetter() {
        return "D";
    }
}
