import java.util.Random;

public class Rabbit extends Animal {
    private int move = 0;
    Random r = new Random();
    
    public Rabbit(int r, int c) {
        super(r, c);
    }
    
    public void move() {
        move++;
        if(move==1){
            setRow(getRow() - 1);
        }
        else if(move==2){
            setCol(getCol() + r.nextInt(3)+1);
        }
        else if(move==3){
            setRow(getRow() + 1);
            move = 0;
        }
    }
    
    public void interactWith(Animal other, World world) { 
        if(other instanceof Rabbit){
            if(Math.abs(getCol()-other.getCol()) <= 1 && getRow()==other.getRow() || Math.abs(getRow()-other.getRow()) <= 1 && getCol()==other.getCol()){
                world.addAnimal(new Rabbit(getRow()+3, getCol())); // Moves 3 spaces down, but when you hit 'Enter' it also calls 'move()' so it moves the new reproduced Rabbits as well.
                return;
            }
        }
    }

    public String toGridLetter() {
        return "v";
    }
}
