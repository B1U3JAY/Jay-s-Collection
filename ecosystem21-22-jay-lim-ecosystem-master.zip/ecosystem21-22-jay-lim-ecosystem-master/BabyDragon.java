import java.util.Random;

public class BabyDragon extends Dragon {
    private int move = 1;
    private boolean chaseMode = false;
    private int chaseMCol;
    private int chaseMRow;
    Random r = new Random();
    private int rn;
    
    public BabyDragon(int r, int c) {
        super(r, c);
    }
    
    public void move() { // I made it move by 2 in any direction because it can fly pretty quickly. When it chases, it will move an additional space closer to its target.
        if(chaseMode==false){
            rn = r.nextInt(8);
            switch(rn){
                case 0: setRow(getRow() - 2);
                        break;
                case 1: setRow(getRow() + 2);
                        break;
                case 2: setCol(getCol() + 2);
                        break;
                case 3: setCol(getCol() - 2);
                        break;
            }
        }
        else {
            if(chaseMCol<0){
                setCol(getCol() + 1);
            }
            else{
                setCol(getCol() - 1);
            }
            
            if(chaseMRow<0){
                setCol(getCol() + 1);
            }
            else{
                setCol(getCol() - 1);
            }
            chaseMode=false;
        }
        move++;
        return;
    }
    
    public Animal evolve() { // Kind of like how a baby becomes an adult, the BabyDragon will eventually evolve into a bigger Dragon (that can do things better).
        if(move==25){
            return new Dragon(getRow(), getCol());
        }
        return this;
    }
    
    public void interactWith(Animal other, World world) { // As a BabyDragon, it will eat Deer only and enter 'chaseMode' if it is within a certain range of the Deer.
        if(other instanceof Deer){
            if(Math.abs(getCol()-other.getCol()) <= 1 && getRow()==other.getRow() || Math.abs(getRow()-other.getRow()) <= 1 && getCol()==other.getCol()){
                world.removeAnimal(other);
            }
                
            if(Math.abs(getCol()-other.getCol()) <= 3 && getRow()==other.getRow()){
                chaseMCol = getCol()-other.getCol();
                chaseMode=true;
            }
            else if(Math.abs(getRow()-other.getRow()) <= 3 && getCol()==other.getCol()){
                 chaseMRow = getRow()-other.getRow();
                  chaseMode=true;
            }
        }
    }

    public String toGridLetter() {
        return ")";
    }
}
