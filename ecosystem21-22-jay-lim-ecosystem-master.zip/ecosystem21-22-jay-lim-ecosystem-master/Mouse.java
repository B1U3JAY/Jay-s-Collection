import java.util.Random;

public class Mouse extends Animal {
    Random r = new Random();
    private int rn;
    
    public Mouse(int r, int c) {
        super(r, c);
    }
    
    public void move() {
        rn = r.nextInt(4);
        if(rn==0){
            setRow(getRow() - 1);
        }
        else if(rn==1){
            setRow(getRow() + 1);
        }
        else if(rn==2){
            setCol(getCol() + 1);
        }
        else if(rn==3){
            setCol(getCol() - 1);
        }
    }

    public String toGridLetter() {
        return "!";
    }
}
