package jrJava.flowControl_2_loop;

public class UsingForLoop {

	public static void main(String[] args) {
		
		int i;
		for (i=1; i<=5; i++) {
			
			System.out.println("i= " + i);
			System.out.println("I am so good looking!");
			System.out.println("I have a wonderful voice!");
			System.out.println("I have a charming personality!");
		}
		
		System.out.println("Outside loop: i= " + i);
		
	}
}
