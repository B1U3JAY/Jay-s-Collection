package jrJava.flowControl_2_loop;

import java.util.Scanner;

public class FunWithPrintf3 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int i;
		int j;
		int a = 10;
		int b = 0;
		
		for(i=1; i<10; i++) {
			j = 10 - i;
			while (j > 0) {
				if (i%2 != 0) { 
					System.out.printf("%" + (a - j) + "d\n", 0);
				}
				else { // if is even
					System.out.printf("%" + (j + b) + "d\n", 0);
				}
				j = j-1;
				
			}
			if (i%2 != 0) { 
				a--;
			}
			else {
				b++;
			}
		}
	}
}