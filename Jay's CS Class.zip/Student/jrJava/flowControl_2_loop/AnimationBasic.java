package jrJava.flowControl_2_loop;

import java.awt.Color;
import java.awt.Graphics;
import resources.DrawingBoard;
import resources.Timer;

public class AnimationBasic {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(100, 50, 800, 600);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		int x  = 100;
		int change = 5;
		int i;
		for (i=1; i<=100; i++) {
			
			x += change;
			
			// if(x<=0) change = -change;
			// if(x>=700) change = -change;
			if(x<=0 || x>=700) change = -change;
			
 			board.clear();
			g.setColor(Color.RED);
			g.fillOval(x, 250, 100, 100); // At (800-radius, 250) it should stop.
			board.repaint();
			timer.pause(30);
		}
		/*
		board.clear();
		g.setColor(Color.RED);
		g.fillOval(100, 250, 100, 100);
		board.repaint();
		timer.pause(30);
		
		board.clear();
		g.setColor(Color.RED);
		g.fillOval(120, 250, 100, 100);
		board.repaint();
		timer.pause(30);
		
		board.clear();
		g.setColor(Color.RED);
		g.fillOval(130, 250, 100, 100);
		board.repaint();
		timer.pause(30);
		
		board.clear();
		g.setColor(Color.RED);
		g.fillOval(140, 250, 100, 100);
		board.repaint();
		timer.pause(30);
		
		board.clear();
		g.setColor(Color.RED);
		g.fillOval(150, 250, 100, 100);
		board.repaint();
		timer.pause(30);
		
		board.clear();
		g.setColor(Color.RED);
		g.fillOval(160, 250, 100, 100);
		board.repaint();
		timer.pause(30);
		*/
		
	}
}
