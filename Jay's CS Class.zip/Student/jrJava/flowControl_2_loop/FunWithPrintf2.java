package jrJava.flowControl_2_loop;

import java.util.Scanner;

public class FunWithPrintf2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int i;
		
		for(i=1; i<10; i++) {
			System.out.printf("%" + i + "d\n", i);
		 for(i=9; i>0; i--) {
			 System.out.printf("%" + i + "d\n", i);
		}
	}
}
		
/*	int data = 0;
	int i = 1;
	int i = i+1;
	System.out.printf("%" + i + "d", i);
	}
}
		*/