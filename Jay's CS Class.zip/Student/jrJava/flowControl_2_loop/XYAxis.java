package jrJava.flowControl_2_loop;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;
import resources.Timer;

public class XYAxis {

	public static void main(String[] args) {

		DrawingBoard board = new DrawingBoard(100, 100, 1000, 1000);
		Graphics g = board.getCanvas();
		
		board.clear();
		g.setColor(Color.BLACK);
		g.drawLine(100, 300, 700, 300);
		g.drawLine(400, 100, 400, 500);
		board.repaint();
	}
}