package jrJava.flowControl_2_loop;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class ArcsOnXYPlane {

	public static void main(String[] args) {
		DrawingBoard board = new DrawingBoard(100, 100, 1000, 1000);
		Graphics g = board.getCanvas();
		
		board.clear();
		g.setColor(Color.BLACK);
		g.drawLine(100, 300, 700, 300);
		g.drawLine(700, 300, 680, 280);
		g.drawLine(700, 300, 680, 320);
		
		g.drawLine(400, 100, 400, 500);
		g.drawLine(400, 100, 380, 120);
		g.drawLine(400, 100, 420, 120);
		
		
		g.setColor(Color.RED);
		g.drawArc(325, 225, 150, 150, 0, 90);
		g.setColor(Color.GREEN);
		g.drawArc(300, 200, 200, 200, 0, 180);
		g.setColor(Color.CYAN);
		g.drawArc(275, 180, 250, 250, 0, 270);
		
		g.setColor(Color.BLACK);
		g.drawString("x",  720,  300);;
		String message = "y";
		g.drawString(message, 420, 100);
		g.drawString("(0,0)", 370, 320);
		
		board.repaint();
	}
}