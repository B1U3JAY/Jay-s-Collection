package jrJava.flowControl_2_loop;

import java.awt.Color;

import java.awt.Graphics;

import java.util.Scanner;

import resources.DrawingBoard;

import resources.Timer;

public class ManualControl {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(100, 50, 800, 600);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		Scanner scanner = new Scanner(System.in);
		
		int x = 200;
		int y = 200;
		int radius = 70;
		
		board.clear();
		g.setColor(Color.GREEN);
		g.fillOval(x-radius, y-radius, 2*radius, 2*radius);
		board.repaint();
		
		int command;
		int i;
		for(i=1; i<=100; i++){
			System.out.println("Enter a command. 1(left), 2(right), 3(up), 4(down), 5(grow), 6(shrink)");
			command = scanner.nextInt();
			
			if(command==1) x-=5;
			else if(command==2) x+=5;
			else if(command==3) y-=5;
			else if(command==4) y+=5;	
			else if(command==5) radius+=2;
			else if(command==6) radius-=2;
			
			board.clear();
			g.setColor(Color.GREEN);;
			g.fillOval(x-radius,  y- radius,  2*radius,  2*radius);
			board.repaint();
		}
	}
}