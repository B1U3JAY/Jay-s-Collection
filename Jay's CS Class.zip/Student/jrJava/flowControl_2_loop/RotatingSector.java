package jrJava.flowControl_2_loop;

import java.awt.Color;

import java.awt.Graphics;

import resources.DrawingBoard;

import resources.Timer;

public class RotatingSector {

	public static void main(String[] args) {
		
		 DrawingBoard board = new DrawingBoard(100, 50, 800, 600);
		 Graphics g = board.getCanvas();
		 Timer timer = new Timer();
		 
		 int x = 400; // center of the circle
		 int y = 300; // center of the circle
		 int radius = 100;
		 int startAngle = 10;
		 
		 int i;
		 for(i=1; i<=500; i++) {
		 
		 startAngle += 10;
		 radius ++;
		 
		 board.clear();
		 g.setColor(Color.CYAN);
		 g.fillArc(x-radius, y-radius, 2*radius, 2*radius, startAngle, 30);
		 g.drawOval(x-radius, y-radius, 2*radius, 2*radius);
		 board.repaint();
		 timer.pause(20);
		 
		 }
	}
}
