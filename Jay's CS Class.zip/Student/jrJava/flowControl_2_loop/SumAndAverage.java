package jrJava.flowControl_2_loop;

import java.util.Scanner;
public class SumAndAverage {

	public static void main(String[] args) {
		
	Scanner sc = new Scanner(System.in);
	int i;
	int n1;
	int n2;
	double sum = 0;
	double average;
	
	System.out.println("Please type in an integer number: ");
	n1 = sc.nextInt();
	sum += n1;
		for(i=1; i<10; i++) {
			System.out.println("Please type in another integer number: ");
			n2 = sc.nextInt();
			sum += n2;
		}
	average = sum/10;
	System.out.println("Sum = " + sum);
	System.out.println(" Average = " + average) ;
	}
}
