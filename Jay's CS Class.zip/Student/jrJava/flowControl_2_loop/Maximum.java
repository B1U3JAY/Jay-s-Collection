package jrJava.flowControl_2_loop;

import java.util.Scanner;

public class Maximum {

	public static void main(String[] args) {
		
	Scanner sc = new Scanner(System.in);
	int i;
	int n1;
	int n2;
	double Max;
	
	System.out.println("Please type in a positive integer number: ");
	n1 = sc.nextInt();
	Max = n1;
		for(i=1; i<10; i++) {
			System.out.println("Please type in another positive integer number: ");
			n2 = sc.nextInt();
			if(n2>Max) {
				Max = n2;
			}
		}
	System.out.println("Maximum = " + Max);
	}
}