package jrJava.flowControl_2_loop;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;
import resources.Timer;

public class RepeatingCircle1 {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(0, 0, 1170, 1170);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		int x = 200;
		int y = 200;
		int r = 100;
		int i;
		for (i=1; i<=6; i++) {		
			g.setColor(Color.BLUE);
			g.drawOval(x, y, r, r);
			int change1 = 5;
			x -= change1;
			y -= change1;
			r += 10;
		}
	}
}
		/*
		DrawingBoard board = new DrawingBoard(0, 0, 1170, 1170);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		int r = 200;
		int change1 = 10;
		
		int i;
		for (i=1; i<=6; i++) {		
			g.setColor(Color.BLUE);
			g.drawOval(100, 100, r, r);
			r += change1;
		}
	}
}
*/
	
	/*
		DrawingBoard board = new DrawingBoard(0, 0, 1170, 1170);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		int x = 600;
		int y = 100;
		int change1 = 140;
		int change2 = 110;
		
		int i;
		for (i=1; i<=8; i++) {		
			g.setColor(Color.RED);
			g.fillOval(x, y, 140, 140);
			x -= change1;
			y += change2;
		}
	}
}
*/


/*DrawingBoard board = new DrawingBoard(100, 50, 800, 600);
Graphics g = board.getCanvas();
Timer timer = new Timer();

int x  = 50;
int change = 5;
int i;
for (i=1; i<=100; i++) {		
	x += change;
	if(x<=0 || x>=660) change = -change;
	board.clear();
	g.setColor(Color.RED);
	g.fillOval(x, 100, 140, 140);
	board.repaint();
	timer.pause(50);
}
}
}
*/