package jrJava.abstractType_stack;

// Opposite of Queue; "FILO" --> "LIFO" (FIRST IN LAST OUT/LAST IN FIRST OUT):

public class MyStack {
	
	private Object[] elements; // We created a "Cosmic Super Class" array which means any Java object reference can go in there (because its a Cosmic Super Class TYPE). The problem is when they try to retrieve the reference they must use the subtype (by using subtype casting operator and if its not that type it will cause a Class Exception Error). -----> Hence, the Generic Type was created.
	
	private int top;
	
	public MyStack(int size) {
		elements = new Object[size];
		top = -1;
	}
	
	public void push(Object ref) {
		if(top==elements.length-1) {
			throw new IndexOutOfBoundsException();
		}
		elements[++top] = ref;
	}
	
	public Object pop() {
		if(isEmpty()) {
			throw new IndexOutOfBoundsException();
		}
		return elements[top--];
	}
	
	public Object peek() {
		if(isEmpty()) {
			throw new IndexOutOfBoundsException();
		}
		return elements[top]; // No Shifting involved unlike 'pop' or 'push' (so no '++' or '--').
	}
	
	public boolean isEmpty() {
		return top==-1;
	}

}
