package jrJava.abstractType_stack;

public class Test {
	
	public static void main(String args[]) {
		
		MyStack stack = new MyStack(6);
		
		stack.push("AAAAA");
		stack.push("BBBBB");
		stack.push("CCCCC");
		stack.push("DDDDD");
		stack.push("EEEEE");
		
		/*
		while(!stack.isEmpty()) {
			System.out.println(stack.pop()); // We will be seeing "EEEEE" first so we must reverse it.
		}
		*/
		
		retrieveAll(stack);
		
	}
	
	public static void retrieveAll(MyStack stack) { // We will "retrieve" it so that the "bottom" one first isntead of the "top" one:
		
		MyStack s = new MyStack(10);
		while(!s.isEmpty()) {
			s.push(stack.pop()); // Whatever we 'pop' out which we go from bottom to top, we will "push" it back into the 'MyStack s' so that its reveresed when we print it out (which is what a stack does).
		}
		
		while(!stack.isEmpty()) {
			System.out.println(s.pop());
		}
		
	}

}
