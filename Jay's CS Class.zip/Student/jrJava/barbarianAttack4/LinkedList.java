  package jrJava.barbarianAttack4;

import java.util.Iterator;

public class LinkedList<E> { 
	
	private Link<E> first;
	private Pool<E> pool;
	
	public LinkedList() {
		pool = new Pool<E>();
	}
	
	public E recycle() {
		if(pool.isEmpty()) {
			return null;
		}
		Link<E> link = pool.remove();
		link.next = first;
		first = link;
		return link.obj;
	}
	
	// if only this insert(.....) method is used, then the linkedList  will be a sorted-linkedList:
	public void insert(E obj) {
		
		Link<E> link = new Link<E>(obj);
		
		// Link<E> current = first;
		// Link<E> previous = null;
		
		link.next = first;
		first = link;
		
		/*
		while(current!=null && current.obj.compareTo(obj)<0) { // If its less than the inputted 'id', it will keep moving up until it is in the right position. (We must be careful of the NPE - Null Pointer Exception! - by using short circuit evaluation - '&&').
			previous = current;
			current = current.next;
		}
		
		// if(current==null) // One of the three 'Null Pointer Exception' cases (which is taken care of the 'if & else' statement below):
		
		if(previous==null) {
			link.next = first;
			first = link;
		}
		else { 
			previous.next = link; // We must be careful of the NPE - Null Pointer Exception!.
			link.next = current;
		}
		*/
		
	}
	
	public void printAll() {
		Link<E> current = first;
		while(current!=null) {
			System.out.println(current + " ");
			current = current.next;
		}
		System.out.println(" ----- "); // Separator
		pool.printAll(); // Inner pool's 'printAll()'.
	}
	
	public Iterator<E> iterator() { // In order to keep the 'MyIterator' as 'private' we have to use the return type as the generic Iterator type.
		return new MyIterator();
	}
	
	private class MyIterator implements Iterator<E> { // By making it go by the outer class' generic type we remove the erros within this inner class. 
		
		// Iterator (ex. Scanner(s)):
		
		// private LinkedList<A> list; // It has direct access so we don't need this.
		private Link<E> current; // Null; Should point to one before the 'first'
		private Link<E> previous;
		
		public boolean hasNext() {
			if(current==null) { // Special Case
				return first!=null; 
			}
			
			return current.next!=null;
		}
		
		public E next() {
			if(current==null) { // Special Case
				current = first; // Jump to 'first'
				return first.obj;
			}
			
			previous = current;
			current = current.next;
			return current.obj;
		}
		
		public void remove() {
			if(current==null) { // Special Case
				throw new UnsupportedOperationException("remove-operation");
			}
			
			if(previous==null) {
				Link<E> temp = first;
				first = first.next;
				current = null;
				pool.insert(temp);
				return;
			}
			
			Link<E> temp = current;
			previous.next = current.next;
			current = previous;
			pool.insert(temp);
		}
	}
	
	// "Inner class 'Linked List'":
	private class Pool<A> { // This can have its own generic type since it doesn't need to access anythign outside.
		
		private Link<A> first;
		
		public boolean isEmpty() {
			return first==null;
		}
		
		public void insert(Link<A> link) {
			link.next = first;
			first = link;
		}
		
		public Link<A> remove(){
			Link<A> temp = first;
			if(first!=null) {
				first = first.next;
			}
			
			return temp;
		}
		
		public void printAll() {
			Link<A> current = first;
			while(current!=null) {
				System.out.println(current + " ");
				current = current.next;
			}
			System.out.println();
		}
	}
	
	private static class Link<T> { // We don't want to use the same letter for the generic type since it is overriding itself (hiding its own 'E' type)
		
		// For learning purposes we will make everything public:
		public Link<T> next; // Next 'Link's' address
		public T obj; // Any Java data object can come through here
		
		public Link(T obj) {
			this.obj = obj;
		}
		
		public String toString() {
			return '[' + obj.toString() + ']';
		}
		
		public boolean equals(Object o) {
			if(!(o instanceof Link)) {
				return false;
			}
			Link<T> other = (Link<T>) o;
			return obj.equals(other.obj);
		}
		
	}

}
