package jrJava.barbarianAttack4;

import java.awt.Graphics2D;
import java.util.Iterator;

public class ArrowManager {
	
	public static int arrowId = 0;
	
	// private static MyArrayList<Arrow> arrows = new MyArrayList<Arrow>();
	private static LinkedList<Arrow> arrows = new LinkedList<Arrow>();
	
	public static void create(double x, double y, double vx, double vy, double length) {
		Arrow recycled = arrows.recycle();
		if(recycled!=null) {
			recycled.reset(x, y, vx, vy, length);
		}
		else {
			arrows.insert(new Arrow(x, y, vx, vy, length));
		}
	}
	
	/* // We don't need to call this because everytime we call the move method we also call the remove method.
	public static void remove(Arrow arrow) {
		arrows.remove(arrow);
	}
	*/
	
	public static void move() {
		Iterator<Arrow> iter = arrows.iterator();
		Arrow each;
		while(iter.hasNext()) {
			each = iter.next();
			each.move();
			if(each.getX()<0 || each.getY()>650) {
				iter.remove();
			}
			arrows.printAll();
		}
		
		/*
		Arrow each;
		for(int i=arrows.size()-1; i>=0; i--) {
			each = arrows.get(i);
			each.move();
			
			if(each.getX()<0 || each.getY()>650) {
				arrows.remove(i);
			}
		}
		*/
	}
	
	public static void draw(Graphics2D g) {
		Iterator<Arrow> iter = arrows.iterator();
		Arrow each;
		while(iter.hasNext()) {
			each = iter.next();
			each.draw(g);
			if(each.isCollided()) {
				iter.remove();
			}
		}
	}

}
