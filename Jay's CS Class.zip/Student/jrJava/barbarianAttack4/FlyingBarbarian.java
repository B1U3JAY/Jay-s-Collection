package jrJava.barbarianAttack4;

import java.awt.Image;

public class FlyingBarbarian extends Barbarian {
	
	protected int upperLimit, lowerLimit; // Not only will this 'FlyingBarbarian' inherit the 'vx' from the 'Barbarian' class, it will also have its own 'vy' -> 'upperLimit' & 'lowerLimit' with its 'flySpan':
	protected int direction;
	
	public FlyingBarbarian(Image[] images, int x, int y, int vx, int flySpan) { // While the 'RunningBarbarian' will be on the ground, the 'FlyingBarbarian' will fly in a certain zone:
		super(images, x, y, vx);
		
		upperLimit = y + flySpan;
		lowerLimit = y - flySpan;
		direction = 1;
	}
	
	public void move() {
		x += vx;
		
		if(x>1100) { // Passes Tower
			Coordinator.gameOver = true;
		}
		
		
		y += direction*Math.random()*5; // 'direction' makes it go up and down
		if(y>=upperLimit) {
			y = upperLimit; // Limit it
			direction *= -1; // Change the 'direction'
		}
		if(y<=lowerLimit) {
			y = lowerLimit; // Limit it
			direction *= -1; // Change the 'direction'
		}
	}

}
