package jrJava.barbarianAttack4;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.GeneralPath;
import java.awt.*;

import java.awt.event.*;

public class Bow implements MouseListener, MouseMotionListener{
	
	// Keep this as a "template" (so we can always use it as a standard position):
	private static Point[] bowGrip_template = new Point[] {
		new Point(-2, -15),
		new Point(-2, 15),
		new Point(3, 15),
		new Point(3, -15),
		new Point(-2, -15)
	};
	
	public static Point[] bow_0_template = new Point[] {
		new Point(-1, -15),
		new Point(0, -55),
		new Point(15, -45),
		new Point(16, -64),
		new Point(17, -74), // Furthest Point = Point Where Bow String Ends
		new Point(15, -45),
		new Point(1, -53),
		new Point(2, -15),
		new Point(-2, -15),
		
		
		// Change 'y' values to be positive instead of negative (since the bow is symmetrical top and bottom):
		new Point(-1, 15),
		new Point(0, 55),
		new Point(15, 45),
		new Point(16, 64),
		new Point(17, 74), // Furthest Point = Point Where Bow String Ends
		new Point(15, 45),
		new Point(1, 53),
		new Point(2, 15),
		new Point(-2, 15)
	};
	
	private static Point[] bow_100_template =  new Point[]{   
			new Point(-1, -15),
			new Point(10, -54),
			new Point(45, -35),
			new Point(56, -54),
			new Point(57, -54),
			new Point(45, -34),
			new Point(4, -49),
			new Point(2, -15),
			new Point(-2, -15),
			new Point(-1, 15),
			new Point(10, 54),
			new Point(45, 35),
			new Point(56, 54),
			new Point(57, 54),
			new Point(45, 34),
			new Point(4, 49),
			new Point(2, 15),
			new Point(-2, 15),
			new Point(0, 0)
	};
	
	private static Point[] bowGrip = new Point[bowGrip_template.length];
	private static Point[] bow = new Point[bow_0_template.length];
	
	private static Point refPoint;
	private static double scaleFactor;
	private static double stretchFactor;
	private static double angleInRadian;
	private static Stroke stroke; // Thickness of line(s)
	
	private static int mx0, my0;  // Mouse press point.
	private static int mx, my;    // Mouse drag point.
	private static double maxDragDistance;
	private static double arrowLength, stretchLength;
	private static double arrowHeadX, arrowHeadY, arrowTailX, arrowTailY;
	private static boolean arrowLoaded;
	
	static {
		for(int i=0; i<bowGrip.length; i++) {
			bowGrip[i] = new Point(0, 0); // Create a temporary template so that there isn't a null pointer exception.
		}
		
		for(int i=0; i<bow.length; i++) {
			bow[i] = new Point(0, 0); // Create a temporary template so that there isn't a null pointer exception.
		}
	}
	
	// Allow 'Bow' position and angle to change:
	
	public Bow(int x, int y, double scale) {
		
		refPoint = new Point(x, y);
		scaleFactor = scale;
		stroke = new BasicStroke(0.5f); // (float)scale/2
		
		// angleInRadian = angle*Math.PI/180;
		// stretchFactor = stretch;
		
		arrowLength = 150*scaleFactor;
		maxDragDistance = 200*scaleFactor;
		 
		// Translation: 
		MathUtility.translate(bowGrip_template, refPoint);
		MathUtility.translate(bow_0_template, refPoint);
		MathUtility.translate(bow_100_template, refPoint);
		
		// Rotate & Scale:
		
		stretchScaleAndRotatePoints();
		
		// However, this wastes a lot of CPU time
		
		// So this is way better:
	}
	

	private static void stretchScaleAndRotatePoints() {
		// Cloning Process:
		
		for(int i=0; i<bowGrip_template.length; i++) {
			bowGrip[i].x = bowGrip_template[i].x;
			bowGrip[i].y = bowGrip_template[i].y;
			MathUtility.scaleAndRotate(bowGrip[i], refPoint, scaleFactor, angleInRadian);
		}
		
		for(int i=0; i<bow_0_template.length; i++) {
			bow[i].x = bow_0_template[i].x*(1-stretchFactor) + bow_100_template[i].x*stretchFactor; // If 'stretchFactor' is 0, then the right side of the addition sign will be 0 making only one side bent. (Vice Versa for a value of 1). Now if we go somewhere in th middle (0.5) then it will stretch the bow on both sides.
			bow[i].y = bow_0_template[i].y*(1-stretchFactor) + bow_100_template[i].y*stretchFactor;
			MathUtility.scaleAndRotate(bow[i], refPoint, scaleFactor, angleInRadian);
		}
	}
	
	/*
	public void setStretchFactor(double stretch) {
		stretchFactor = stretch;
		
		rotateAndScale(); // Call this so that it can "transform".
	}
	
	public void setAngle(double angle) {
		angleInRadian = angle*Math.PI/180;
		
		rotateAndScale(); // Call this so that it can "transform".
	}
	*/
	
	public void draw(Graphics2D g) {
		
		stretchScaleAndRotatePoints();
		
		// show loaded arrow.
		arrowTailX = (bow[4].x + bow[13].x)/2 + stretchLength*Math.cos(angleInRadian);
		arrowTailY = (bow[4].y + bow[13].y)/2 + stretchLength*Math.sin(angleInRadian);
		arrowHeadX = arrowTailX - arrowLength*Math.cos(angleInRadian);
		arrowHeadY = arrowTailY - arrowLength*Math.sin(angleInRadian);
		
		if(arrowLoaded) {
			g.setColor(Color.BLACK);
			g.drawLine((int)arrowHeadX, (int)arrowHeadY, (int)arrowTailX, (int)arrowTailY);
		}
		
		// Bow Grip:
		g.setColor(new Color(150, 0, 0));
		GeneralPath bowGripPath = new GeneralPath();
		bowGripPath.moveTo(bowGrip[0].x, bowGrip[0].y);
		for(int i=1; i<bowGrip.length; i++) {
			bowGripPath.lineTo(bowGrip[i].x, bowGrip[i].y);
		}
		g.fill(bowGripPath);
		
		// Bow:
		/*
		g.setColor(new Color(180, 0, 0));
		GeneralPath bowPath = new GeneralPath();
		bowPath.moveTo(bow[0].x, bow[0].y);
		bowPath.curveTo(bow[1].x, bow[1].y,
				        bow[2].x, bow[2].y,
				        bow[3].x, bow[3].y);
		bowPath.lineTo(bow[4].x, bow[4].y);
		bowPath.curveTo(bow[5].x, bow[5].y,
		               bow[6].x, bow[6].y,
		               bow[7].x, bow[7].y);
		bowPath.lineTo(bow[8].x, bow[8].y);
		
		bowPath.moveTo(bow[9].x, bow[9].y);
		bowPath.curveTo(bow[10].x, bow[10].y,
				        bow[11].x, bow[11].y,
				        bow[12].x, bow[12].y);
		bowPath.lineTo(bow[13].x, bow[13].y);
		bowPath.curveTo(bow[14].x, bow[14].y,
		               bow[15].x, bow[15].y,
		               bow[16].x, bow[16].y);
		bowPath.lineTo(bow[17].x, bow[17].y);
		g.fill(bowPath);
		*/
		
		// Note that what we just did above is quite wasteful and continously create new 'Point' objects. Instead we should do this:
		
		GeneralPath bowStringPath = new GeneralPath();
		g.setColor(Color.DARK_GRAY);
		g.setStroke(stroke);
		bowStringPath.moveTo(bow[4].x, bow[4].y); // Furthest Bow String Point (x, y).
		bowStringPath.lineTo(arrowTailX, arrowTailY);
		bowStringPath.moveTo(bow[13].x, bow[13].y); // Furthest Bow String Point (x, y).
		bowStringPath.lineTo(arrowTailX, arrowTailY);
		g.draw(bowStringPath);
	}
	

	public void mousePressed(MouseEvent e) {
		mx0 = e.getX();
		my0 = e.getY();
		arrowLoaded = true;
	}
	
	public void mouseDragged(MouseEvent e) { 
		mx = e.getX();
		my = e.getY();
		
		if(mx<=mx0) {
			mx = mx0 + 1;
		}
		angleInRadian = Math.atan( ((double)my-my0)/(mx-mx0) );
		/*
		double tan = ((double)my-my0)/(mx-mx0);
		angleInRadian = Math.atan(tan);
		*/
		
		double dragDistance = Math.sqrt((mx-mx0)*(mx-mx0) + (my-my0)*(my-my0));
		if(dragDistance>maxDragDistance) {
			dragDistance = maxDragDistance;
		}
		
		stretchFactor = dragDistance/maxDragDistance;
		stretchLength = 80*scaleFactor*stretchFactor;
	}
	
	
	public void mouseReleased(MouseEvent e) { 
		double vx = -0.7*arrowLength*stretchFactor*Math.cos(angleInRadian);
		double vy = -0.7*arrowLength*stretchFactor*Math.sin(angleInRadian); 
		ArrowManager.create(arrowHeadX, arrowHeadY, vx, vy, arrowLength); 
		
		stretchFactor = 0;
		stretchLength = 0;
		arrowLoaded = false;
	}
	
	
	public void mouseClicked(MouseEvent e) { 
		
	}
	
	public void mouseEntered(MouseEvent e) { 
		
	}
	
	public void mouseExited(MouseEvent e) { 
		
	}
	
	public void mouseMoved(MouseEvent e) { 
		
	}

}
