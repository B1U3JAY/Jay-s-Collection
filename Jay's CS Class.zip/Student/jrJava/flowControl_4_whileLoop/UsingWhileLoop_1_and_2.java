package jrJava.flowControl_4_whileLoop;

public class UsingWhileLoop_1_and_2 {

	public static void main(String[] args) {
		
		// 1*1 + 2*2 + 3*3 + ... + 10*10
		/*
		int sum = 0;
		int i;
		for(i=1; i<=10; i++){
			sum += i*i;
		}
		System.out.println(sum);
		*/
		
		// Convert to While
		int sum = 0;
		int i;
		i = 1;
		while(i<=10) {
			sum+= i*i;
			i++;
		}
		System.out.println(sum);
	}
}
