package jrJava.flowControl_4_whileLoop;

public class UsingWhileLoop_3 {

	public static void main(String[] args) {
		
		int i;
		int j;
		
		// Nesting for-loops:
		for(i=1; i<=4; i++) {
			
			for(j=1; j<=i; j++) {
				
				System.out.println(i + ", " + j);
				
			}
		}
		
		//Nesting while-loops:
		
		i = 1;
		
		while(i<=4) {
			j=1;
			while(j<=i) {
				
				System.out.println(i + ", " + j);
				j++;
				
			}
			i++;
		}
	}
}
