package jrJava.LinkedList5;

import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		
		LinkedList list = new LinkedList();
		list.insertAtEnd("aaa");
		list.insertAtEnd("bbb"); 
		list.insertAtEnd("ccc");
		/*
		list.insert("ccc");
		list.insert("bbb");
		list.insert("aaa");
		*/
		
		Iterator iter = new MyIterator(list);
		while(iter.hasNext()) {
			// Object each = iter.next(); // String objects have a sense of order 
			// String each = (String) iter.next(); // Downcast because it results in a 'Cosmic Super Class' type
			String each = (String) iter.next();
			System.out.println(each);
		}
		

	}

}
