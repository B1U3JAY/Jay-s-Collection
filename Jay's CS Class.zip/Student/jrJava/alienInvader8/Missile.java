package jrJava.alienInvader8;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

public class Missile {
	
	public static final int WIDTH, HEIGHT;
	//private static Color color;
	private int x, y; // Bottom center of missile
	private static Image image;
	private int vy;
	private Alien owningAlien;
	private BattleShip target; // BattleShip will send its reference through here so that the Missile class can use it in its structure.
	
	private boolean collided;
	public static final Color EXPLOSION_COLOR;
	public static final int EXPLOSION_RADIUS;
	
	static {
		image = new ImageIcon("jrJava/alienInvader8_Images_and_Sounds/missile.png").getImage();
		WIDTH = image.getWidth(null);
		HEIGHT = image.getHeight(null);
		// color = Color.RED;
		
		EXPLOSION_COLOR = Color.PINK;
		EXPLOSION_RADIUS = 70;
	}
	
	public Missile(int x, int y, int vy, Alien owningAlien, BattleShip target) { // Missile constructor method
		this.x = x;
		this.y = y;
		this.vy = vy;
		this.owningAlien = owningAlien; // the Alien owningAlien code is so that it can store the individual address of the Alien object.
		this.target = target; 
	}
	
	public boolean isHit(Torpedo torpedo) {
		
		if(torpedo.getX() >= x-WIDTH/2-Torpedo.WIDTH/2 && torpedo.getX() <= x+WIDTH/2+Torpedo.WIDTH/2 && torpedo.getY() >= y-HEIGHT-Torpedo.HEIGHT && torpedo.getY() <= y) {
			owningAlien.remove(this);
			return true;
		} // This method knows right away whether or not the if(boolean){} is true or false (short-circuit evaluation).
		
		return false;
	}
	
	public int getX() {
		
		return x;
	}
	
	public int getY() {
		
		return y;
	}
	
	public void move() {
		y += vy;
		
		if(y>750) {
			owningAlien.remove(this); // IMPORTANT: 'this' is the specific Missile object's address (needs to pass its address) so that it can be destroyed.
		}
		
		collided = target.isHit(this);
		
	}
	
	public void draw(Graphics g) {
		// g.setColor(color);
		// g.drawRect(x-WIDTH/2, y-HEIGHT, WIDTH, HEIGHT); // To get the (x,y) coordinate of the rectangular missile, we x is x-w/2 and y is y-h
		
		g.drawImage(image, x-WIDTH/2, y, null);

		if(collided) {
			g.setColor(EXPLOSION_COLOR);
			g.drawOval(x-EXPLOSION_RADIUS, y-EXPLOSION_RADIUS, 2*EXPLOSION_RADIUS, 2*EXPLOSION_RADIUS);
			// owningALien.remove(this); <----- GAME OVER CONDITION
		}
	}

}

