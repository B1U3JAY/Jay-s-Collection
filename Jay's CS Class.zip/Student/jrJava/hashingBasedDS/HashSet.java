package jrJava.hashingBasedDS;

import java.util.Iterator;

public class HashSet<E> {
	
	private Entry<E>[] entries;
	
	public HashSet(int size) {
		entries = new Entry[size];
	}
	
	public HashSet() {
		this(100);
	}
	
	public E add(E obj) {
		
		// 1. Create a new entry that contains the 'obj':
		
		Entry<E> entry = new Entry(obj);
		
		// 2. Make it arrive at the hashBucket:
		int index = obj.hashCode()%entries.length;
		Entry<E> p = entries[index];
		
		// 3. Traverse to the end of the hashBucket (linked list) while checking for any duplicate entry:
		
		if(p==null) {
			entries[index] = entry;
			return null;
		}
		else if(p.obj.equals(obj)) { // Replace the identical object reference:
			entry.next = p.next; 
			entries[index] = entry;
			return p.obj;
		}
		
		Entry<E> c = p.next; // Current (c) Entry is the next Previous (p) entry
		
		while(c!=null) { // Traverse:
			if(c.obj.equals(obj)) {
				// 'entry.next' is the duplicated as 'c' so we are trying to remove it by assigning the 'entry.next' as the next reference of 'c' and making 'p.next's' reference become the 'entry' (while severing the link to the current obj):
				p.next = entry;
				entry.next = c.next; 
				return c.obj;
			}
			
			p = c;
			c = c.next;
		}
		
		p.next = entry; // We traverse until c is null which means the previous's next is not null.
		
		return null;
	}
	
	public E get(E searchKey) {
		int index = searchKey.hashCode()%entries.length;
		Entry<E> c = entries[index];
		
		while(c!=null) {
			if(c.obj.equals(searchKey)) {
				return c.obj;
			}
			c = c.next;
		}
		
		return null;
	}
	
	public void display(){
		Entry<E> c;
		
		for(int i=0; i<entries.length; i++) {
			System.out.print(i + ": ");
			c = entries[i];
			
			while(c!=null) {
				System.out.print(c.obj + " -> ");
				c = c.next;
			}
			System.out.println();
		}
		
	}
	
	public Iterator<E> iterator(){
		return new IterImpl();
	}
	
	private class IterImpl implements Iterator<E>{
		
		private int index = 0;
		private Entry<E> next = entries[index];
		
		public boolean hasNext() {
			while(next==null) {
				index++;
				if(index>=entries.length) {
					break;
				}
				next = entries[index];
			}
			
			return next!=null;
		}
		
		public E next() {
			E toReturn = next.obj;
			next = next.next;
			return toReturn;
		}
		
	}
	
	private static class Entry<E> { // Similar to a link node
		
		public E obj;
		public Entry<E> next;
		
		public Entry(E obj) {
			this.obj = obj;
		}
		
		public String toString() {
			return "{" + obj + "}";
		}
		
	}

}
