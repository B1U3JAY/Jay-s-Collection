package jrJava.hashingBasedDS;

public class Thing {
	
	private int id;
	private int b;
	private int c;
	
	public Thing(int id, int b, int c) {
		this.id = id;
		this.b = b;
		this.c = c;
	}
	
	public int hashCode() {
		return id;
	}
	
	public boolean equals(Object other) {
		Thing o = (Thing) other;
		return id==o.id;
	}
	
	public String toString() {
		return "[" + id + ", " + b + ", " + c + "]";
	}

}
