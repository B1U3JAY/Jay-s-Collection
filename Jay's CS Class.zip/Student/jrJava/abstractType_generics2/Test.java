package jrJava.abstractType_generics2;

public class Test {
	
	// The point is that by using generics it will tell us during the compile time if certain objects can work together or not:

	public static void main(String[] args) {
		
		// Let's create a type for 'String' Objects:
		
		MyArrayList<String> list = new MyArrayList<String>();
		
		list.add("123"); // This will be accepted, but .....
		// list.add(123); // This will not
		
		String data = list.get(0); // We can get the 'data' as a String type
		
		// Now let's create a type for 'Ball' Objects:
		
		MyArrayList<Ball> ballList = new MyArrayList<Ball> (10);
		// ballList.add("abc"); // This willl be rejected during compile time (before run-time)
		ballList.add(new Ball(5, 7)); // This will be accepted during compile time (before run-time)
		// String data2 = ballList.get(0); // Type mismatch
		Ball data2 = ballList.get(0); // Will nto be a problem if we use the ball type
	}

}
