package jrJava.flowControl6_methodPractice;

public class BBB {
	
	
	public static void saySomething() {
		
		System.out.println("Hello!");
		System.out.println("I had a great lunch!");
	}
	
	
	public static void saySomethingElse() {
		System.out.println("Hi there!");
	}
}
