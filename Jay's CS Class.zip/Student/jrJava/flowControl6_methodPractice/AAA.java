package jrJava.flowControl6_methodPractice;

public class AAA {

	public static void main(String[] args) {
		
		BBB.saySomething();
		BBB.saySomething();
		doSomething(); // AAA.doSomething();
		BBB.saySomethingElse();
		
	}
	
	public static void doSomething() {
		System.out.println("I did something.");
	}
}
