package jrJava.flowControl6_methodPractice;

import java.util.Scanner;

public class HW_PRACTICE {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println(maximumAndCount(sc)); 
		// System.out.println(sum(5, 7, 10));
		// System.out.println(sum(100, 200, 123));
	  
	  }
	
	public static double maximumAndCount(Scanner scanner) {
		double sum = 0.0;
		double num = 0.0;
		double max = 0.0;
		int n = 0;
		while (true) {	
			System.out.println("Please input a positive number:");
			num = scanner.nextDouble();
			if (num>max) {
				max = num;
			}
			n++;
			if (num<0.0) {
				break;
			}
		}
		System.out.println("Count: " + n);
		return max;
	}
}
