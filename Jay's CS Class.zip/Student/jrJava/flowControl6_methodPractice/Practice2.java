package jrJava.flowControl6_methodPractice;

public class Practice2 {

	public static void main(String[] args) {
		
		System.out.println(sum(1, 1000, 1));
		System.out.println(sum(11, 251, 2));
		System.out.println(sum(5, 255, 5));
		
	}
	
	public static int sum(int begin, int end, int increment) {
		
		int sum = 0;
		int i;
		for(i=begin; i<=end; i+=increment) {
			sum +=i;
		}
		return sum;
	}
}
