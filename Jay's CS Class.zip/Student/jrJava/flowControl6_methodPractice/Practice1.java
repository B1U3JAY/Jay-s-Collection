package jrJava.flowControl6_methodPractice;

public class Practice1 {

	public static void main(String[] args) {
		
		System.out.println(findMax(11, 3, 17));
		
		int biggest = findMax(123, 341, 99);
		System.out.println(biggest);
	}
	
	
	public static int findMax(int value1, int value2, int value3){
		int max = value1;
		
		if(value2>max) {
			max = value2;
		}
		
		if(value3>max) {
			max = value3;
		}
		
		return max;
	}
	
}
