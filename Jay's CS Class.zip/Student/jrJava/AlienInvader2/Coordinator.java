package jrJava.AlienInvader2;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;
import resources.Timer;

public class Coordinator {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard (200, 0, 600, 600);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		Alien alien1 = new Alien(300, 200, Color.BLUE, Color.GRAY, 2, 4);
		Alien alien2 = new Alien(500, 300, Color.GREEN, Color.BLACK, -3, 5);
		
		for(int i=0; i<=200; i++) {
			alien1.move();
			alien2.move();
			
			
			board.clear();
			
			alien1.draw(g);
			alien2.draw(g);
			board.repaint();
			timer.pause(50);
		}
	}

}
