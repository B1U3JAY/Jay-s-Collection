package jrJava.AlienInvader1;

import java.awt.Color;
import java.awt.Graphics;

public class Missile {
	
	static int width, height;
	static Color color;
	int x, y; // Bottom center of missile
	int vy;
	
	static {
		width = 4;
		height = 12;
		color = Color.RED;
	}
	
	public Missile(int x, int y, int vy) {
		this.x = x;
		this.y = y;
		this.vy = vy;
	}
	
	public void move() {
		y += vy;
	}
	
	void draw(Graphics g) {
		g.setColor(color);
		g.drawRect(x-width/2, y-height, width, height); // To get the (x,y) coordinate of the rectangular missile, we x is x-w/2 and y is y-h
		
	}
	
	

}

