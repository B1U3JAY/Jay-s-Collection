package jrJava.alienInvader4;

import java.awt.Color;
import java.awt.Graphics;

public class Missile {
	
	static int width, height;
	static Color color;
	int x, y; // Bottom center of missile
	int vy;
	Alien owningAlien;
	
	static {
		width = 4;
		height = 12;
		color = Color.RED;
	}
	
	public Missile(int x, int y, int vy, Alien owningAlien) { // Missile constructor method
		this.x = x;
		this.y = y;
		this.vy = vy;
		this.owningAlien = owningAlien; // the Alien owningAlien code is so that it can store the individual address of the Alien object.
	}
	
	public void move() {
		y += vy;
		
		if(y>600) {
			owningAlien.remove(this); // IMPORTANT: 'this' is the specific Missile object's address (needs to pass its address) so that it can be destroyed.
		}
		
	}
	
	void draw(Graphics g) {
		g.setColor(color);
		g.drawRect(x-width/2, y-height, width, height); // To get the (x,y) coordinate of the rectangular missile, we x is x-w/2 and y is y-h
		
	}
	
	

}

