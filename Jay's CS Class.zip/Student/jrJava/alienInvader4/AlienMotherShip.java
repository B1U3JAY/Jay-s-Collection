package jrJava.alienInvader4;

import java.awt.Graphics;

import java.awt.Color;

public class AlienMotherShip {
	
	static Color[] bodyColors; // Color[] bodyColors = {Color.RED, Color.GREEN, Color.BLUE, Color.ORANGE, Color.MAGENTA, Color.YELLOW, Color.CYAN, Color.PINK};
	static Color[] eyeColors; // Same concept as above. But we want a "Gray Scale".
	static Alien[] aliens;
	// Static' will make the fields in the class/static structure

	static {
		aliens = new Alien[30];
		bodyColors = new Color[]{Color.RED, Color.GREEN, Color.BLUE, Color.ORANGE, Color.MAGENTA, Color.YELLOW, Color.CYAN, Color.PINK}; // 7 colors
		eyeColors = new Color[] {Color.LIGHT_GRAY, Color.GRAY, Color.DARK_GRAY, Color.BLACK}; // 4 colors
	}
	
	static void createAlien() {
		
		for(int i=0; i<aliens.length; i++) {
			if(aliens[i]==null) {
				int x = (int) (Math.random()*801); // So that the maximum is 800 not 799 (It is 799 if it is multiplied by 800)
				int y = 0;
				Color bodyColor = bodyColors[(int) (Math.random()*bodyColors.length)]; // Chooses a random index from bodyColors array
				Color eyeColor = eyeColors[(int)(Math.random()*eyeColors.length)]; // Chooses a random index from the eyeColors array
				int vx = (int) (Math.random()*9)-4; // To get the numbers -4, -3, -2, -1, 0, 1, 2, 3, and 4 (A total of 9 numbers, hence, *9).
				int vy = (int) (Math.random()*6)+2; // Same logic except we want numbers 2, 3, 4, 5, 6, and 7 (Hence, we add 2 since Math.random()*6 will go from 0 to 6 where it will stop at 5.99999...).
				aliens[i] = new Alien(x, y, bodyColor, eyeColor, vx, vy);
				break; // Or call return;
			}
		}
	}
	
	
	
	static void move() {
		
		// It will create a new Alien object.
		// It will randomly move with a 10% probability (by calling this method).
		
		if(Math.random()<0.1) {
			createAlien();
		}
		
		// It needs to make all the aliens move.
		
		for(int i=0; i<aliens.length; i++) {
			if(aliens[i]!=null) {
				aliens[i].move();
			}
		}
		
	}
	
	static void draw(Graphics g) {
		// Make all aliens draw
		for(int i=0; i<aliens.length; i++) {
			if(aliens[i]!=null) {
				aliens[i].draw(g);
			}
		}
	}
		
	static void remove(Alien alien) {
		for(int i=0; i<aliens.length; i++) {
			if(aliens[i]==alien){
				aliens[i] = null;
				break;
			}
		}
				
	}
}
