package jrJava.bezierCurves;

import java.awt.*;
import java.awt.geom.GeneralPath;

import resources.DrawingBoard;

public class BezierInJava {
	
	// Getting familiar with Bezier Curves:

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(200, 0, 800, 750);
		Graphics2D g = (Graphics2D) board.getCanvas();
		
		GeneralPath path = new GeneralPath();
		
		path.moveTo(400, 300);
		path.lineTo(600, 200);
		path.quadTo(800, 400, 600 ,500); // "2nd Order" Bezier Curve
		path.lineTo(400, 600);
		path.curveTo(700, 350, 200, 350, 400, 300); // "3rd Order" Bezier Curve
		
		g.setColor(Color.CYAN);
		// g.draw(path);
		g.fill(path);
		
		board.repaint();

	}

}
