package jrJava.flowControl_5_methodCallAndReturn_1;

import java.awt.Color;
import java.awt.Graphics;

public class ExampleLooksOfMethod {
	
	void anyName() {
		// any code
	}
	
	void doSomething(int value1, int value2, int value3) {
		// any code
	}
	
	int doAnotherThing(int v1, int v2, int v3) {
		// any code
		return 5; // <--- Must return an int when type is "int"
	}
	
	double myOwnMethod() {
		// any code
		return 3.1415; // <--- Must return a double when type is "double"
	}
	
	public void drawSomething(Graphics g, Color color, int x, int y) {
		// any code
	}
	
	private Color createColor(int r, int g, int b){
		Color color = new Color(r, g, b);
		return color;
	}
	
	
}
