package jrJava.flowControl_5_methodCallAndReturn_1;

import java.awt.Color;

import java.awt.Graphics;

import resources.DrawingBoard;

import resources.Timer;

public class ColorPalette {

	public static void main(String[] args) {
				
		int tileSize = 20;
		int numberOfTiles = 10;
		int margin = 10;
		
		DrawingBoard board = new DrawingBoard(100, 10, tileSize*numberOfTiles + 2*margin, tileSize*numberOfTiles + 2*margin);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		board.clear();
		
		int i;
		int j;
		for(i=1; i<=numberOfTiles; i++) {
			 
			for(j=1; j<=numberOfTiles; j++) {
				
				Color tileColor = new Color(255-255/(numberOfTiles*2)*(i+j), 255/(numberOfTiles*2)*(i+j), 0);
				
				g.setColor(tileColor);
				g.fillRect(margin + (i-1)*tileSize, margin + (j-1)*tileSize, tileSize, tileSize);
				
				g.setColor(Color.BLACK);
				g.drawRect(margin + (i-1)*tileSize, margin + (j-1)*tileSize, tileSize, tileSize);
				
				board.repaint();
				timer.pause(10);
				
			}
		}
	}
}

/*	
	public static void myAnotherMethod() {
		int i;
		int j;
		
		for(i=1; i<=10; i++) {
			for (j=1; j<=10; j++) {
				System.out.println(i + ", " + j);
			}
		}
		System.out.println();
	}
	
	private int myOneMoreMethod(int a, int b) {
		int sum = 0;
		int i;
		int j;
		
		for(i=a; i<=b; i++) {
			for (j=i; j<=10; j++) {
				System.out.println(i + ", " + j);
			}
		}
		return sum;
	}
}
*/
