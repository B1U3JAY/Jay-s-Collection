package jrJava.flowControl9_method_overloading;

public class Practice1 {
	
	public static void main(String[] args) {
		
		sum(1, 2); // Goes to sum_int_int
		sum(1, 0.5); // Goes to sum_int_double
		sum(1.9, -5.9); // Goes to sum_double_double
		
	}
	
	// Method Overloading
	// We can use same method name as long as the parameter signatures are different,
	// the number of the parameters, types of the parameters, or the order of the parameter types are different. --> We can overload
	public static int sum(int v1, int v2) {
		return v1 + v2;
	}
	
	public static int sum(int v1, int v2, int v3) {
		return v1 + v2 + v3;
	}
	
	public static int sum(int v1, int v2, int v3, int v4) {
		return v1 + v2 + v3 + v4;
	}
	
	public static double sum(double v1, int v2) {
		return v1 + v2;
	}
	
	public static double sum(int v1, double v2) {
		return v1 + v2;
	}
	
	public static double sum(double v1, double v2) {
		return v1 + v2;
	}
	
	public static double sum(double v1, double v2, double v3) {
		return v1 + v2 + v3;
	}
}
