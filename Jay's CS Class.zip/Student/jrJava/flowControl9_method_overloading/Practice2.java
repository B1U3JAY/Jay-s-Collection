package jrJava.flowControl9_method_overloading;

public class Practice2 {

	public static void main(String[] args) {
		
		System.out.println(sum(4, 7.0));

	}
	
	public static int sum(int v1, int v2) {
		System.out.println("int int");
		return v1 + v2;
	}
	
	public static double sum(int v1, double v2) {
		System.out.println("int double");
		return v1 + v2;
	}
	
	public static double sum(double v1, double v2) {
		System.out.println("double double");
		return v1 + v2;
	}
	
}
