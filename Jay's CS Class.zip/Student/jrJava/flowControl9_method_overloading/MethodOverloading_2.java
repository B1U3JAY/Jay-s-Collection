package jrJava.flowControl9_method_overloading;

import java.awt.Color;
import java.awt.Graphics;

public class MethodOverloading_2 {

	public static void main(String[] args) {
		
		System.out.println(min(10, 100));
		System.out.println(min(10, 100, 1000));
		System.out.println(min(10, 100, 1000, 200));
		System.out.println(min(10, 100, 1000, 200, 20));

	}
	
	public static int min(int data1, int data2) { 
		return min(data1, data2, data1, data1, data1);
	}
	
	public static int min(int data1, int data2, int data3) { 
		return min(data1, data2, data3, data1, data1);

	}
	
	public static int min(int data1, int data2, int data3, int data4) { 
		return min(data1, data2, data3, data4, data1);
	
	}
	
	public static int min(int data1, int data2, int data3, int data4, int data5) { 
		int min = data1;
		
		if (data2<min){
			min = data2;
		}
		
		if (data3<min){
			min = data3;
		}
		
		if (data4<min){
			min = data4;
		}
		
		if (data5<min){
			min = data5;
		}
		
		return min; 
	}
}

