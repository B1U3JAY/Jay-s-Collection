package jrJava.flowControl9_method_overloading;

public class Practice3 {

	public static void main(String[] args) {
		
		
		
	}
	
	public static int sum(int end) {
		
		return sum(1, end, 1);
		
	}
	
	public static int sum(int begin, int end) {
		
		return sum(begin, end, 1);
		
	}
	
	public static int sum(int begin, int end, int increment) {
		
		int sum = 0;
		int i;
		for(i=begin; i<=end; i+=increment) {
			sum += i*i*i;
		}
		return sum;
	}
}
