package jrJava.flowControl9_method_overloading;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class MethodOverloading_1 {

	public static void main(String[] args) {
		DrawingBoard board = new DrawingBoard(0, 0, 800, 800);
		Graphics g = board.getCanvas();
		/*
		// This one will receive all parameters.
		drawBlackHole(g, red, green, blue, xC, yC, radius);
		// This one will use radius=100.
		drawBlackHole(g, red, green, blue, xC, yC);
		// This one will use xC=200, yC=200, and radius=100. 
		drawBlackHole(g, red, green, blue);
		// This one will use red=0, green=0, blue=0, xC=200, and yC=200. 
		drawBlackHole(g, radius);
		// This one will use red=0, green=0, blue=0, xC=200, yC=200, and radius=100. 
		drawBlackHole(g);
		*/

	}
	
	public static void drawBlackHole(Graphics g, int red, int green, int blue, int xC, int yC, int radius) { 
		int i; // changing radius
		Color color; // the color each circle will use
		
		for(i=radius; i>=0; i--) {
			color = new Color(red*i/radius, green*i/radius, blue*i/radius); 
			g.setColor(color);
			g.fillOval(xC-i, yC-i, 2*i, 2*i);
		}
	
		return; 
	
	}
	
	public static void drawBlackHole(Graphics g, int red, int green, int blue, int xC, int yC) { 
		drawBlackHole(g, red, green, blue, xC, yC, 100);
		return; 
	
	}
	
	public static void drawBlackHole(Graphics g, int red, int green, int blue) { 
		drawBlackHole(g, red, green, blue, 200, 200, 100);
		return; 
	
	}
	
	public static void drawBlackHole(Graphics g, int radius) { 
		drawBlackHole(g, 0, 0, 0, 200, 200, radius);
		return; 
	
	}
	
	public static void drawBlackHole(Graphics g) { 
		drawBlackHole(g, 0, 0, 0, 200, 200, 100);
		return; 
	
	}
	
}
