package jrJava.aboutArray5;

import java.awt.Color;

public class Practice2 {

	public static void main(String[] args) {
		
		Color[] colors = {Color.RED, Color.GREEN, Color.BLUE, Color.ORANGE, Color.MAGENTA, Color.YELLOW, Color.PINK, Color.CYAN};
		
		//int random = (int)(Math.random()*colors.length); 
		// The casting operator (int) will make the value integer even if it calculates a double.
		
		Color chosen = colors[(int)(Math.random()*colors.length)];
		
	}

}
