package jrJava.aboutArray5;

public class Practice1 {

	public static void main(String[] args) {
		
		// Inside the brackets, we can use any math expression
		// as long as it evaluates to be an integer and also
		// stays within the valid index range.

		// int[] aaa = {3, 2, 4, 7, 9};
		// int k = 2;
		// System.out.println(aaa[k*k-k-1]);
		
		int[] bbb = {2, 0, 1, 3, 4, 2, 5, 6};
		bbb[bbb[0]+3] = bbb[bbb[2]+1];
		// The initialization above evaluates to bbb[5] <= bbb [2];
		
		
	}

}
