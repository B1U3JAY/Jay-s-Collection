package jrJava.alienInvader7;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

//import jrJava.alienInvader6.Torpedo;

public class BattleShip implements KeyListener, MouseListener, MouseMotionListener{
	
	private int x;
	private int y;// top center of the BattleShip
	private Color color = Color.RED;
	private int height = 20;
	private int topWidth = 4;
	private int middleWidth = 20;
	private int bottomWidth = 60;
	
	private Torpedo[] torpedoes;
	private boolean alive;
	
	public BattleShip(int x, int y) {
		this.x = x;
		this.y = y;
		torpedoes = new Torpedo[10];
		alive = true;
	}
	
	public boolean isAlive() { // We made this since we can't make a 'public boolean alive;' or 'public final boolean alive;'. This is how we will bypass it.
		return alive;
	}

	public void respondToMouseDraggingByRepositioning() {
		
	}
	
	private void shootTorpedo() {
		for(int i=0; i<torpedoes.length; i++) {
			if(torpedoes[i]==null) {
				torpedoes[i] = new Torpedo(x, y, -10, this);
				break;
			}
		}
	}
	 
	public boolean isHit(Alien alien) {
		
		// double collisionWithTopRectangle = alien.getX() >= x-topWidth/2-Alien.WIDTH/2 && alien.getX() <= x+topWidth/2+Alien.WIDTH/2 && alien.getY() >= y && alien.getY() <= y+height+Alien.HEIGHT;
		// double collisionWithMiddleRectangle = alien.getX() >= x-middleWidth/2-Alien.WIDTH/2 && alien.getX() <= x+middleWidth/2+Alien.WIDTH/2 && alien.getY() >= y+height && alien.getY() <= y+2*height+Alien.HEIGHT;
		// double collisionWithBottomRectangle =  alien.getX() >= x-bottomWidth/2-Alien.WIDTH/2 && alien.getX() <= x+bottomWidth/2+Alien.WIDTH/2 && alien.getY() >= y+2*height && alien.getY() <= y+3*height+Alien.HEIGHT;
				
		if(alien.getX() >= x-topWidth/2-Alien.WIDTH/2 && alien.getX() <= x+topWidth/2+Alien.WIDTH/2 && alien.getY() >= y && alien.getY() <= y+height+Alien.HEIGHT 
				|| 
		   alien.getX() >= x-middleWidth/2-Alien.WIDTH/2 && alien.getX() <= x+middleWidth/2+Alien.WIDTH/2 && alien.getY() >= y+height && alien.getY() <= y+2*height+Alien.HEIGHT 
				|| 
		   alien.getX() >= x-bottomWidth/2-Alien.WIDTH/2 && alien.getX() <= x+bottomWidth/2+Alien.WIDTH/2 && alien.getY() >= y+2*height && alien.getY() <= y+3*height+Alien.HEIGHT) {
					
		   alive = false;
		   return true;
		}
		
		return false;
	}
	
	public boolean isHit(Missile missile) {
		
		// double collisionWithTopRectangle = missile.getX() >= x-topWidth/2-Missile.WIDTH/2 && missile.getX() <= x+topWidth/2+Missile.WIDTH/2 && missile.getY() >= y && missile.getY() <= y+height+Missile.HEIGHT;
		// double collisionWithMiddleRectangle = missile.getX() >= x-middleWidth/2-Missile.WIDTH/2 && missile.getX() <= x+middleWidth/2+Missile.WIDTH/2 && missile.getY() >= y+height && missile.getY() <= y+height+height+Missile.HEIGHT;
		// double collisionWithBottomRectangle = missile.getX() >= x-bottomWidth/2-Missile.WIDTH/2 && missile.getX() <= x+bottomWidth/2+Missile.WIDTH/2 && missile.getY() >= y+2*height && missile.getY() <= y+2*height+height+Missile.HEIGHT;
		
		if(missile.getX() >= x-topWidth/2-Missile.WIDTH/2 && missile.getX() <= x+topWidth/2+Missile.WIDTH/2 && missile.getY() >= y && missile.getY() <= y+height+Missile.HEIGHT 
				|| 
		   missile.getX() >= x-middleWidth/2-Missile.WIDTH/2 && missile.getX() <= x+middleWidth/2+Missile.WIDTH/2 && missile.getY() >= y+height && missile.getY() <= y+2*height+Missile.HEIGHT 
		   		|| 
		   missile.getX() >= x-bottomWidth/2-Missile.WIDTH/2 && missile.getX() <= x+bottomWidth/2+Missile.WIDTH/2 && missile.getY() >= y+2*height && missile.getY() <= y+3*height+Missile.HEIGHT) {
			
			alive = false;
			return true;
		}
		
		return false;
	}
	
	public void draw(Graphics g) {
		g.setColor(color);
		g.drawRect(x-topWidth/2, y, topWidth, height); // (x-topWidth/2, y) is the left hand corner point of the top rectangle on the Battle Ship.
		g.drawRect(x-middleWidth/2, y+height, middleWidth, height);
		g.drawRect(x-bottomWidth/2, y+2*height, bottomWidth, height);
		
		for(int i=0; i<torpedoes.length; i++) {
			
			if(torpedoes[i]!=null) {
				torpedoes[i].draw(g);
			}
			
			if(torpedoes[i]!=null) {
				torpedoes[i].move();
			}
		}	
	}
	
	public void remove(Torpedo torpedo) {
		for(int i=0; i<torpedoes.length; i++) {
			if(torpedoes[i]==torpedo) {
				torpedoes[i] = null;
				break;
			}
		}
	}
	
	public void keyPressed(KeyEvent e){
		// Every key has a unique 'keycode'.
		
		/*
		char key = e.getKeyChar();
		System.out.println(key);
		*/
		
		int code = e.getKeyCode();
		// System.out.println(code);
		
		// You can also use the arrow keys by using the VIRTUAL KEYBOARD (VK).
		
		if(code==KeyEvent.VK_SPACE) {
			shootTorpedo();
		}
		
		else if(code==KeyEvent.VK_LEFT) {
			x -= 10;
		}
		
		else if(code==KeyEvent.VK_RIGHT) {
			x +=10;
		}
		
		else if(code==KeyEvent.VK_UP) {
			y -=10;
		}
		
		else if(code==KeyEvent.VK_DOWN) {
			y +=10;
		}
		
		/*
		if(key==' ') {
			shootTorpedo();
		}
		
		else if(key=='a') { // Moves ship to the left
			x -= 10;
		}
		
		else if(key=='d') { // Moves ship to the right
			x += 10;
		}
		
		else if(key=='w') { // Moves ship forwards
			y -= 10;
		}
		
		else if(key=='s') { // Moves ship backwards
			y += 10;
		}
		*/
		
		// Each key has its own code (ex. space bar is '32')
		
		if(code==32) {
			shootTorpedo();
		}
		
		else if(code==65) {
			x -= 10;
		}
		
		else if(code==68) {
			x += 10;
		}
		
		else if(code==87) {
			y -= 10;
		}
		
		else if(code==83) {
			y += 10;
		}
		
	}
	
	public void keyReleased(KeyEvent e){
		
	}

	public void keyTyped(KeyEvent e){
	
	}
	
	
	
	public void mouseClicked(MouseEvent e) {
		
	}

	public void mousePressed(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		// System.out.println(x + ", " + y);
		this.x = x;
	}
	
	public void mouseReleased(MouseEvent e) {
		
	}

	public void mouseEntered(MouseEvent e) {
		
	}
	
	public void mouseExited(MouseEvent e) {
		
	}

	
	
	public void mouseDragged(MouseEvent e) {
		int x = e.getX();
		this.x = x;
		int y = e.getY();
		this.y = y;
	}

	public void mouseMoved(MouseEvent e) {
		
	}
}
