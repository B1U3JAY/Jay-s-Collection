package jrJava.aboutArray1;

public class Practice4 {

	public static void main(String[] args) {
		
		boolean[] data = new boolean[4]; // Like other types such as object types that hold null or int/double types that hold 0/0.0, boolean or (true/false types) will hold a false statement at first

		data[3] = !data[0];
		
		for(int i=0; i<4; i++) {
			System.out.println(data[i]);
		}
		
	}

}
