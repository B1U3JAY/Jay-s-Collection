package jrJava.aboutArray1;

public class Practice2 {

	public static void main(String[] args) {
		
		//object type (array of integer type)
		int[] data = new int[5];
		
		// int aaa; // primitive type(int value will go in.)
		// int[] aaa; // object type (the reference of the int-array will go in)
		
		// array's address followed by bracket notation
		data[0] = 100;
		data[1] = 200;
		data[3] = 250;
		
		data[4] = data[0] + data[1]/2; // First adds the right hand side and then stores it into the data's 4th array
		
		System.out.println(data[4]);

	}

}
