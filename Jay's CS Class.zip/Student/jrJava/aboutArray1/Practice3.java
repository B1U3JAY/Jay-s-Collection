package jrJava.aboutArray1;

public class Practice3 {

	public static void main(String[] args) {
		
		// We need to create a double array type (array of doubles) where we can store the information
		double[] data = new double [20];
		
		//data[0] = 0.0;
		//data[1] = 0.1;
		//data[2] = 0.2;
		// .....
		
		for(int i=0; i<20; i++) {
			data[i] = 0.1*i;
		}
		
		System.out.println(data[19]);

	}

}
