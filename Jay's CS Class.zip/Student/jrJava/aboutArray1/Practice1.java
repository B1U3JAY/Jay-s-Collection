package jrJava.aboutArray1;

import jrJava.AlienInvader1.Missile;

public class Practice1 {

	public static void main(String[] args) {
		
		Missile[] missiles = new Missile[10]; // (What kind of array will go in there ([]) ex. Missile object array) (storage space) = *new (object is created)* Array (of what type ex. Missile object type) [Number of arrays starting from 0]
		
		System.out.println(missiles[0]);
		System.out.println(missiles[4]);
		
		missiles[0] = new Missile(100, 200, 5); // Create an object, reference is obtained, puts the reference into the array of the address (missiles) and target the index (number).
		missiles[4] = new Missile(250, 175, 7);
		
		System.out.println(missiles[0]);
		System.out.println(missiles[4]);
		
		missiles[0].move();
		missiles[4].move();
	}

}
