package jrJava.inheritance8_usingProtected2;

import jrJava.inheritance8_usingProtected.A;
import jrJava.inheritance8_usingProtected.B;

public class OutsideFamily {

	public static void main(String[] args) {

		A ref = new B();
		// System.out.println(ref.f1);
		// System.out.println(ref.f2);
		System.out.println(ref.f3);
		
		// ref.m1();
		// ref.m2();
		ref.m3();
		

	}

}
