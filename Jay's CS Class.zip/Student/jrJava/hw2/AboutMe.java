package jrJava.hw2;

public class AboutMe {

	public static void main(String[] args) {
		System.out.println("I am Jay.");
		System.out.println("I attend Redwood Middle School.");
		System.out.println("I did well this semester and I got all 'A'.");
	}
}