package jrJava.inheritance4_polymorphism2;

public class Husky extends Dog{
	
	public void pullSled() {
		System.out.println("I can pull a sled.");
	}
	
	public void move() { 
		System.out.println("I can run in snow.");
	}

}
