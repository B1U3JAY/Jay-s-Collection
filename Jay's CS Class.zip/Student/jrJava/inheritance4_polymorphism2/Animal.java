package jrJava.inheritance4_polymorphism2;

public class Animal {
	
	public void move() {
		System.out.println("I can move.");
	}

}
