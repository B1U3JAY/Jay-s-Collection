package jrJava.inheritance4_polymorphism2;

public class Human extends Mammal{
	
	public void think() {
		System.out.println("I can think.");
	}
	
	public void move() { 
		System.out.println("I can run with 2 legs.");
	}

}
