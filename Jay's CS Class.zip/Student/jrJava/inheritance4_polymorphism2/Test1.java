package jrJava.inheritance4_polymorphism2;

public class Test1 {

	public static void main(String[] args) {
		
		AnimalHospital hospital = new AnimalHospital();
		
		Animal obj = new Chicken();
		hospital.performTreatment(obj);
		hospital.performTreatment(new Husky());
		
		Animal[] animals = new Animal[7];
		animals[0] = new Animal();
		animals[1] = new Bird();
		animals[2] = new Fish();
		animals[3] = new Dog();
		animals[4] = new Human();
		animals[5] = new Chicken();
		animals[6] = new Shepherd();
		
		hospital.performTreatment(animals);
		
	}

}
