package jrJava.inheritance4_polymorphism2;

public class Test2 {
	
	public static void main(String[] args) {
		
		BirdTrainer trainer = new BirdTrainer();
		
		Bird[] birds = new Bird[5];
		birds[0] = new Bird();
		birds[1] = new Chicken();
		birds[2] = new Chicken();
		birds[3] = new Parrot();
		birds[4] = new Parrot();
		
		trainer.train(birds);
		
	}

}
