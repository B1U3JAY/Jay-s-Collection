package jrJava.inheritance4_polymorphism2;

public class Dog extends Mammal{
	
	public void bark() {
		System.out.println("I can bark.");
	}
	
	public void move() { 
		System.out.println("I can chase after a mailman.");
	}

}
