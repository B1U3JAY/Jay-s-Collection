package jrJava.inheritance4_polymorphism2;

public class BirdTrainer {
	
	public void train(Bird trainee) {
		// .....
		trainee.move();
		trainee.peck();
		// .....
	}
	
	public void train(Bird[] trainees) {
		// .....
		for(int i=0; i<trainees.length; i++) {
			trainees[i].move();
			trainees[i].peck();
		}
		// .....
	}

}
