package jrJava.inheritance4_polymorphism2;

public class Parrot extends Bird{
	
	public void imitateSound() {
		System.out.println("I can imitate a sound.");
	}
	
	public void peck() {
		System.out.println("I can peck with rhythm");
	}

}
