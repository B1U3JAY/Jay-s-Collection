package jrJava.inheritance4_polymorphism2;

public class Shepherd extends Dog{
	
	public void watchSheep() {
		System.out.println("I can watch sheep.");
	}

}
