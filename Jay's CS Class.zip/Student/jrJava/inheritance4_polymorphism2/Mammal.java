package jrJava.inheritance4_polymorphism2;

public class Mammal extends Animal{
	
	public void lactate() {
		System.out.println("I can lactate.");
	}

}
