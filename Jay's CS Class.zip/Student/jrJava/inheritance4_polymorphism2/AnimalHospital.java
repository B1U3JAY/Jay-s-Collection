package jrJava.inheritance4_polymorphism2;

public class AnimalHospital {
	
	public void performTreatment(Animal animal) {
		// .....
		animal.move();
		// .....
	}
	
	public void performTreatment(Animal[] animals) {
		// .....
		for(int i=0; i<animals.length; i++) {
			animals[i].move();
		}
		// .....
	}


}
