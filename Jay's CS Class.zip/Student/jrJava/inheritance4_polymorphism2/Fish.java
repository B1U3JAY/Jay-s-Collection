package jrJava.inheritance4_polymorphism2;

public class Fish extends Animal{
	
	public void breatheInWater() {
		System.out.println("I can breathe in water.");
	}
	
	public void move() { 
		System.out.println("I can swim.");
	}


}
