package jrJava.memoryCard_3_usingInterface;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class GameBoard extends JPanel implements MouseListener{ // JPanel then extends to JFrame.
	
	public static final int NUM_OF_COLUMNS = 7; // We will have 6 rows then (6x7=42)
	public static final int MARGIN = 20;
	
	private Card[] cards;
	
	public GameBoard(Card[] cards) { 
		
		this.cards = cards;
		
		JFrame frame = new JFrame("Memory Card Game");
		frame.setBounds(200, 0, 800, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(this); // Creates the container and then put itself into the frame.
		
		arrangeCards(cards);
		
		this.addMouseListener(this); // 'this' is obviously THIS Class' reference. We are passing this guy's reference as a mouseListener in the 'addMouseListener()' method because the class (GameBoard is a specialized JPanel) is a mouseListener type; we are giving the GameBoard AS THE MOUSELISTENER to the Gameboard's method 'addMouseListener' AS THE SOURCE COMPONENT. If the CLASS notices any activity, it will notify the abstract method(s) ('mousePressed' in this case).
		
		frame.setVisible(true);
		
	}
	
	private void arrangeCards(Card[] cards) { // Because we will use this method internally only, we can make it private
		// This will tell the Gameboard how many column numbers we want. Then it will consecutively put the card[] array in each column row by row. 
		for(int i=0; i<cards.length; i++) {
			cards[i].setXY(MARGIN + i%NUM_OF_COLUMNS*Card.SIZE, MARGIN + i/NUM_OF_COLUMNS*Card.SIZE); // <----- Expression that will calculate (x, y) based on the index number i.
			/*
					COLUMN ----->
				R	 	  0   1   2   3   4   5   6
				O	   | ----------------------------
				W	 0 |  0,  1,  2,  3,  4,  5,  6,
				|	 1 |  7,  8,  9, 10, 11, 12, 13,
				|	 2 | 14, 15, 16, 17, 18, 19, 20,
				|	 3 | 21, 22, 23, 24, 25, 26, 27,
				|	 4 | 28, 29, 30, 31, 31, 33, 34, 
				|    5 | 35, .....
				V  ... | .....
					
					If we look at column 0, we can see that they are multiples of 7. So, if we do i/7 we can get the y values. 
					* Note: i is 0, 7, 14, 21, 28, 35 (going down), so dividing by 7 or the NUMBER_OF_COLUMNS, we get the # in each column (going down) which allows us to calculate the y-value*
						
					If we look at row 0, we can see that they are remainders of the index i divided by 7. 0/7, 1/7, 2/7 3/7, 4/7, 5/7, .....
					* Note: So, we can use i%7 or i%NUM_OF_COLUMNS to get each # in each row (going left to right) which allows us to calculate the x value*
				
			*/
		}
		
		// We also need to scramble the cards:
		
		
	}
	
	protected void paintComponent(Graphics g) {
		
		System.out.println("Calling paintComponent");
		
		((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); // Downcasting the Graphics g
		((Graphics2D) g).setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY); // Downcasting the Graphics g
		
		// Paints the background color
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, getWidth(), getHeight());
		
		// Paints all the cards in the Card[] array
		for(int i=0; i<cards.length; i++) {
			cards[i].paint(g);
		}
		
	}
	
	public void mousePressed(MouseEvent e) {
		// Note: The top left-corner of the JPanel is (0, 0)
		
		int x = e.getX(); // Exact x-coordinate
		int y = e.getY(); // Exact y-coordinate
		
		// System.out.println(x + ", " + y);
		
		
		for(int i=0; i<cards.length; i++) {
			if(cards[i].isSelected(e.getX(), e.getY())) { // We will go through each and every card. If the value it true, then we will show the card.
				System.out.println(x + ", " + y);
				cards[i].show();
			}
		}
		repaint(); // We must trigger the Card's 'paint(Graphics g){.....}' method because that every single card was able to paint itself; hence, we use 'repaint();' method. By polymorphism, each card will eventually be able to paint itself.
	}
	
	public void mouseReleased(MouseEvent e) {
		
	}
	
	public void mouseClicked(MouseEvent e) {
		
	}
	
	public void mouseEntered(MouseEvent e) {
		
		
	}
	
	public void mouseExited(MouseEvent e) {
		
		
	}

}
