package jrJava.memoryCard_3_usingInterface;

import java.awt.*;

import javax.swing.ImageIcon;

public abstract class Card {
	
	public static final int SIZE = 100;
	public static Image backSideImage;
	protected int x, y; // We want subclasses to see or use it, hence, it is 'protected'
	protected boolean shouldReveal; // We want subclasses to see or use it, hence, it is 'protected'                                                                                                                                  ;
	
	static {
		backSideImage = new ImageIcon("jrJava/memoryCard_imagesAndSounds/backside.png").getImage();
	}
	
	public void setXY(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public boolean isSelected(int mX, int mY) { // This method will allow EACH card to delegate/assign/give its own coordinate point when clicked/chosen. Note: 'mX' means 'mouseX' and 'mY' means 'mouseY'.
		// If (mX, mY) is in the range of the chosen card's coordinate point (which is a square shape), then the return value will be true. Otherwise it will be false.
		return mX>x && mX<x+SIZE && mY>y && mY<y+SIZE; // Calculating if (mX, mY) is within the given range
	}
	
	public void show() {
		shouldReveal = true;
	}
	
	public void hide() {
		shouldReveal = false;
	}
	
	public void paint(Graphics g) { // This method will become public since outside code needs to access this, however we don't want to give access to the paintContent and paintBorder completely (therefore, they are 'protected').
		if(shouldReveal) {
			paintContent(g);
			System.out.println("paint");
		}
		else {
			g.drawImage(backSideImage, x+SIZE/10, y+SIZE/10, SIZE*4/5, SIZE*4/5, null); // Backside of the card (backSideImage).
		}
		
		paintBorder(g);
	}
	
	// Polymorphism; Even though we call this method as a Card type reference (Card ref = new ImageCard(.....); / ref.paint(g);), when we actually call it, it will execute "What the object really is" which is the ImageCard.
	protected abstract void paintContent(Graphics g); // By making this method an abstract method, we are forcing them to override this method (have to provide method body if they want to have a 'complete design').
	
	protected void paintBorder(Graphics g) { // We want subclasses to see or use it, hence, it is 'protected'

		// ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY); // Downcasting!!!!! This will "erase" or clean up the jagged lines shown in each picture.
		// ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		g.setColor(Color.LIGHT_GRAY);
		g.drawRect(x+5, y+5, SIZE-10, SIZE-10); // Creating a center frame 5 pixels away from each inner side of the main square
		g.setColor(Color.BLACK);
		g.drawRect(x, y, SIZE, SIZE);
	}

}
