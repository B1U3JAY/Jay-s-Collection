package jrJava.aboutType1;

import java.awt.Color;
import java.io.Closeable;
import java.util.Iterator;
import java.util.Scanner;

import javax.swing.JComponent;
import javax.swing.JPanel;

import jrJava.alienInvader6.Alien;
import resources.DrawingBoard;

public class Practice1 {

	public static void main(String[] args) {
		
		Scanner ref11 = new Scanner(System.in);
		Iterator ref12 = new Scanner(System.in);
		Closeable ref13 = new Scanner(System.in);
		Object ref14 = new Scanner(System.in);
		
		DrawingBoard ref21 = new DrawingBoard(200, 0, 800, 600);
		JPanel ref22 = new DrawingBoard(200, 0, 800, 600);
		JComponent ref23 = new DrawingBoard(200, 0, 800, 600);
		
		String ref31 = "Hewwo";
		Comparable ref32 = "Hewwo";
		CharSequence ref33 = "Hewwo";
		
		Alien ref41 = new Alien(100, 200, Color.RED, Color.GREEN, 4, 5, null);
		Object ref42 = new Alien(100, 200, Color.RED, Color.GREEN, 4, 5, null);

	}

}
