package jrJava.inheritance_10_constructorInInheritance.copy;

public class C extends B{
	
	private int f3;
	
	public C(int f3) {
		super(f3*10);
		this.f3 = f3;
	}
	
	public void m3() {
		
	}

}
