package jrJava.inheritance_10_constructorInInheritance.copy;

public class A extends Object{
	
	private int f1;
	
	public A(int f1) {
		super();
		this.f1 = f1;
	}
	
	public void m1() {
		
	}

}
