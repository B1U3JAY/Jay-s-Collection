package jrJava.inheritance_10_constructorInInheritance.copy;

public class B extends A{
	
	private int f2;
	
	public B(int f2) {
		super(10);
		this.f2 = f2;
	}
	
	public void m2() {
		
	}

}
