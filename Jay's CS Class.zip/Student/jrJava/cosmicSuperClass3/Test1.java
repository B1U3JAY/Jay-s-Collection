package jrJava.cosmicSuperClass3;

public class Test1 {
	
	// NOTE: THIS IS THE "RIGHT" WAY
	
	public static void main(String[] args) {
		
		Thing t1 = new Thing(10, 20, null);
		Thing t2 = new Thing(10, 20, null);
		
		System.out.println(t1.equals(t2)); // Both we be printed false BECAUSE it will try to check if t1's address is the same as t2's address.
		System.out.println(t2.equals(t1)); // Both we be printed false BECAUSE it will try to check if t1's address is the same as t2's address.
		
		String description1 = t1.toString(); // The '.toString()' will give a description of the object/field.
		String description2 = t2.toString(); // The '.toString()' will give a description of the object/field.
		
		System.out.println(description1); // This will "describe" 't1' in this case (as a hexadecimal); right now, it gives us its address.
		System.out.println(description2); // This will "describe" 't2' in this case (as a hexadecimal); right now, it gives us its address.
		
		int hashcode1 = t1.hashCode();
		int hashcode2 = t2.hashCode();
		
		System.out.println(hashcode1); // This will return the address of 't1' in decimal notation; just like 't1.toString();' did in hexadecimal notation
		System.out.println(hashcode2); // This will return the address of 't2' in decimal notation; just like 't2.toString();' did in hexadecimal notation
		
		System.out.println(Integer.toHexString(hashcode1)); // Converting from decimal notation to hexadecimal notation and then printing the value; this will allow use to see that the address in decimal form '.hashCode()' printed is the same as the address in hexadecimal form '.toString()' printed.
		System.out.println(Integer.toHexString(hashcode1)); // Converting from decimal notation to hexadecimal notation and then printing the value; this will allow use to see that the address in decimal form '.hashCode()' printed is the same as the address in hexadecimal form '.toString()' printed.
		
	}
}
