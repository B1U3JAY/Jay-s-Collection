package jrJava.cosmicSuperClass3;

public class Thing extends Object { // You do not need to put 'extends Object' because it is already implied
	
	// NOTE: THIS IS THE "RIGHT" WAY
	
	private int id;
	private int age;
	private String name;
	
	public Thing(int id, int age, String name) {
		this.id = id;
		this.age = age;
		this.name = name;
	}
	
	public boolean equals(Object o) { // Overriding
		
		if(o == this) { // If the reference coming is has the same address as the object then it will return true (however it is a rare case); we do not need to compare if they both have the same reference, so we can just skip the process.
			return true;
		}
		
		if(!(o instanceof Thing)) { // If 'o' is not [an "instance of"] / [a 'Thing' type object], it will return false. If 'o' is [an "instance of"] / [a 'Thing' type object], then we will be downcast it and return the needed value(s) below:
			return false;
		}
		
		Thing thing = (Thing) o; // Downcasting in order to access 'Thing's fields', which in this case will be 'thing.id', 'thing.age', and 'thing.name'.
		return id == thing.id && age == thing.age && name.equals(thing.name); // By comparing all their current states (which hold values 'a' and 'b'), we can see 't1' and 't2' are "equal".
		// When comparing object types (like Strings), we need to use the '.equals' method so that it doesn't compare its own address to another; 'id' and 'age' are fine because they are values (since they are both an integer).
	}
	
	public String toString() {
		return "(ID: " + id + ", Age: " + age + ", Name:" + name.toString() + ")"; // If there is an object type it is best to call the '.toString()' method so that it can call its own description so that we can make it part of OUR OWN '.toString()' method (part of THIS method).
	}

}
