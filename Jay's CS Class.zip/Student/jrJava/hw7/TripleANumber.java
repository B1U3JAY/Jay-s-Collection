package jrJava.hw7;

import java.util.Scanner;

public class TripleANumber {

	public static void main(String[] args) {
		
		System.out.println("Type in a number.");
			int number;
			Scanner sc = new Scanner(System.in);
			number = sc.nextInt();
			int triple;
			triple = number*3;
		System.out.println(triple);
		
		
	}

}
