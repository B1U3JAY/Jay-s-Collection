package jrJava.hw7;

import java.util.Scanner;

public class SumOfTwoNumbers {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x;
		int y;
		int sum;
		System.out.println("Type in the first number");
		x = sc.nextInt();
		System.out.println("Type in the second number");
		y = sc.nextInt();
		sum = x + y;
		System.out.println("The sum is: " + sum);
		
		
		

	}

}
