package jrJava.hw7;

import java.util.Scanner;

public class FindingAverage {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x;
		int y;
		double average;
		System.out.println("Type in the first number");
		x = sc.nextInt();
		System.out.println("Type in the second number");
		y = sc.nextInt();
		average = (x + y) * 0.5;
		System.out.println("The average is: " + average);		
	}
}
