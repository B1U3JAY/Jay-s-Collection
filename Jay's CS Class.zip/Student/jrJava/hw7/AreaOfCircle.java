package jrJava.hw7;

import java.util.Scanner;

public class AreaOfCircle {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int r;
		System.out.println("Type in the first radius");
		r = sc.nextInt();
		double area;
		area = Math.PI*r*r;
		System.out.println("The area is " + area);
	}
}
