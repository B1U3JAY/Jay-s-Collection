package jrJava.hw7;

import java.util.Scanner;

public class PerimeterOfCircle {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int r;
		System.out.println("Type in the first radius");
		r = sc.nextInt();
		double perimeter;
		perimeter = 2*Math.PI*r;
		System.out.println("The perimeter is " + perimeter);
	}
}
