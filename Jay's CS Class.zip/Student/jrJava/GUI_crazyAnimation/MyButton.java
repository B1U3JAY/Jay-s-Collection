package jrJava.GUI_crazyAnimation;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JButton;

public class MyButton extends JButton{ // Override JButton/Specialized JButton
	
	private int[] x, y, vx, vy, radius;
	private Color[] color;
	private String text;
	
	public MyButton(String text) {
		this.text = text;
		
		x = new int[] {10, 11, 12, 13, 14, 15, 16, 17, 18, 19};
		y = new int[] {2, 3, 5, 7, 6, 2, 3, 5, 7, 6};
		vx = new int[] {1, 2, 3, 5, 1, 2, 3, 5, 1, 2};
		vy = new int[] {2, 3, 5, 2, 3, 5, 2, 3, 5, 7};
		radius = new int[] {2, 3, 5, 2, 3, 5, 2, 3, 5, 7};
		color = new Color[] {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.BLUE, Color.CYAN, Color.PINK, Color.MAGENTA, Color.GRAY, Color.BLACK};
		
		setRolloverEnabled(true); // Mac users only!
	}
	
	public void moveCircle() {
		for(int i=0; i<radius.length; i++) {
			x[i] += vx[i];
			y[i] += vy[i];
			
			if(x[i]<=0+radius[i] || x[i]>= getWidth()-1-radius[i]) { // We calculate when the circle hits the border. Which is when the circle is 'radius' units away from its (circle's) center.
				vx[i] *= -1; // vx = -vx;
			}
			
			if(y[i]<=0+radius[i] || y[i]>= getHeight()-1-radius[i]) {
				vy[i] *= -1; // vy = -vy;
			}
		}
	}
	
	protected void paintComponent(Graphics g) {
		
		// System.out.println("paintComponent(): TID = " + Thread.currentThread().getId());
		
		g.setColor(Color.WHITE);
		if(getModel().isRollover()) {
			g.setColor(Color.GREEN);
		}
		if(getModel().isPressed()) {
			g.setColor(Color.CYAN);
		}
		g.fillRect(1, 1, getWidth()-2, getHeight()-2); // -2 excludes the border; Height is one from the top and one from the bottom and Width is one from the left and one from the right.
		
		for(int i=0; i<radius.length; i++) {
			g.setColor(color[i]);
			g.fillOval(x[i]-radius[i], y[i]-radius[i], 2*radius[i], 2*radius[i]);
			
			g.setColor(Color.GRAY);
			g.drawString(text, 25, 14);
		}
	}
	
	protected void paintBorder(Graphics g) { // Mac users only! This is because the border of the button does not show, hence, we override it.
		g.setColor(Color.DARK_GRAY);
		g.drawRect(0, 0, getWidth()-1, getHeight()-1);
	}

}
