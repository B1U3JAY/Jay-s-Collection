//package jrJava.circles;
package jrJava.circles;

import java.awt.Color;
import java.awt.Graphics;
import resources.DrawingBoard;

public class MyCircles {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(150, 50, 800, 600);
		Graphics g = board.getCanvas();
		
		g.setColor(Color.RED);
		g.fillRect(100, 100, 250, 200);
		
		g.setColor(Color.GREEN);
		g.fillOval(400, 250, 300, 300);
		
		g.setColor(Color.BLUE);
		g.drawRect(50, 350, 250, 150);
		
		g.setColor(Color.CYAN);
		g.drawOval(370, 50, 400, 300);
		
		board.repaint();
	}

}