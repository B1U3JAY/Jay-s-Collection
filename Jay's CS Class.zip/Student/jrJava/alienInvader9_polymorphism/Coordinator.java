package jrJava.alienInvader9_polymorphism;

import java.awt.Graphics;

import resources.DrawingBoard;
import resources.SoundPlayer;
import resources.Timer;

public class Coordinator {

	public static void main(String[] args){
		
		DrawingBoard board = new DrawingBoard (200, 50, 800, 750);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		BattleShip ship = new BattleShip(400, 580);
		
		board.addKeyListener(ship);
		board.addMouseListener(ship);
		board.addMouseMotionListener(ship);
		
		AlienMotherShip.setTarget(ship);
		
		board.setBackgroundImage("jrJava/alienInvader8_Images_and_Sounds/bg.png");
		SoundPlayer bgSound = new SoundPlayer("jrJava/alienInvader8_Images_and_Sounds/bgMusic.wav");
		bgSound.playLoop(); 

		while(ship.isAlive()) {
			AlienMotherShip.move();
			
			board.clear();
			AlienMotherShip.draw(g);
			ship.draw(g);
			board.repaint();
			timer.pause(50);                         
		}
		bgSound.stop();
	}

}
