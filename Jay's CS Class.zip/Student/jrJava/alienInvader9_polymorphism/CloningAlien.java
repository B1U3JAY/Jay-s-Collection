package jrJava.alienInvader9_polymorphism;

import java.awt.Image;

public class CloningAlien extends MultiShootAlien{
	
	protected int distance;
	protected int requiredDistance;
	
	public CloningAlien(int x, int y, Image image1, Image image2, int vx, int vy, BattleShip target) {
		super(x, y, image1, image2, vx, vy, target);
		requiredDistance = 100 + (int)(Math.random()*200);
	}
	
	public void move() {
		
		super.move();
		
		/* This move method is basically Super's Move Method which is Simple Alien), so we can just say 'super.move();'
		x += vx;
		y += vy;
		
		if(y>750) {
			AlienMotherShip.remove(this); // IMPORTANT: 'this' is the specific Alien object's address (needs to pass its address) so that it can be destroyed.
		}
		
		if(target.isHit(this)) {
			collided = true;
		}
		
		shootMissile();
		
		for(int i=0; i<10; i++) {
			if(missiles[i]!=null) {
				missiles[i].move(); // This command line will execute the specific missile object's "move command"
			}
		}
		*/
		
		distance += vy;
		if(distance>=requiredDistance) {
			AlienMotherShip.add(new CloningAlien(x, y, image1, image2, -vx, vy, target)); // The clone will go the opposite way, hence it will be '-vx' instead of the normal 'vx'.
			// The new CloningAlien's reference must go into the AlienMotherShip's array if it wants to be created.
			distance = 0; // We must reset the distance so it can start again. Otherwise the number will be too big.
		}
	}

}
