package jrJava.alienInvader9_polymorphism;

import java.awt.Image;

public class NastyAlien extends SimpleAlien{
	
	public NastyAlien(int x, int y, Image image1, Image image2, int vx, int vy, BattleShip target) {
		super(x, y, image1, image2, vx, vy, target);
	}
	
	public void move() {
		
		x += Math.abs(vx)*(target.getX() - x)/100; // The further the BattleShip is away from the NastyAlien, the faster this NastyAlien will move (increase vx).
		// We put /100 so that the Alien doesn't move too fast.
		
		super.move();
		
		// The following information below can be put said as all of the 'super structure's codes'
		/*
		x += vx;
		y += vy;
		
		if(y>750) {
			AlienMotherShip.remove(this); // IMPORTANT: 'this' is the specific Alien object's address (needs to pass its address) so that it can be destroyed.
		}
		
		shootMissile();
		
		for(int i=0; i<10; i++) {
			if(missiles[i]!=null) {
				missiles[i].move(); // This command line will execute the specific missile object's "move command"
			}
		}
		target.isHit(this);
		*/
	}

}
