package jrJava.alienInvader9_polymorphism;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public abstract class Alien {
	
	protected Image image1, image2;
	protected int drawCount;
	protected static int drawCycle = 10; // Cycle needs to be even if we want to split
	protected int width, height; // Cannot be a constant WIDTH AND HEIGHT when e use images, as they will change depending on each alien.
	protected int x, y; // Bottom Center
	protected int vx, vy;
	protected Missile[] missiles; // to store multiple missile objects
	protected BattleShip target; // BattleShip will send its reference through here so that the Alien class can use it in its structure.
	
	protected boolean collided;
	public static final Color EXPLOSION_COLOR;
	public static final int EXPLOSION_RADIUS;
	
	static { // allows to initialize static variables
		EXPLOSION_COLOR = Color.GREEN;
		EXPLOSION_RADIUS = 120;
	}
	
	public Alien(int x, int y, Image image1, Image image2, int vx, int vy, BattleShip target) {
		
		this.x = x;
		this.y = y;
		this.image1 = image1;
		this.image2 = image2;
		width = image1.getWidth(null); // Image1 = Image2 Anyways	
		height = image1.getHeight(null);
		
		this.vx = vx;
		this.vy = vy;
		this.target = target;
		
		missiles = new Missile[10];	
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public abstract void move();
	
	protected abstract void shootMissile();
	
	public abstract void draw(Graphics g);
	
	public boolean isHit(Torpedo torpedo) {
		// It will evaluate if the torpedo's rectangle and the alien's rectangle overlap or not.
		
		/*  
		
		boolean c1 = torpedo.getX() >= x-WIDTH/2-Torpedo.WIDTH/2;
		boolean c2 = torpedo.getX() <= x+WIDTH/2+Torpedo.WIDTH/2;
		boolean c3 = torpedo.getY() >= y-HEIGHT-Torpedo.HEIGHT;
		boolean c4 = torpedo.getY() <= y;
		
		// If collision happens -> it will destroy itself and return true.
		
		if(c1 && c2 && c3 && c4) {
			AlienMotherShip.remove(this);
			return true;
		}
		
		*/
		
		// OR LIKE THIS (MORE EFFICIENT):
		
		if(torpedo.getX() >= x-width/2-Torpedo.WIDTH/2 && torpedo.getX() <= x+width/2+Torpedo.WIDTH/2 && torpedo.getY() >= y-height-Torpedo.HEIGHT && torpedo.getY() <= y) {
			AlienMotherShip.remove(this);
			return true;
		} // This method knows right away whether or not the if(boolean){} is true or false (short-circuit evaluation).
		
		for(int i=0; i<missiles.length; i++) {
			// if(missiles[i].isHit(torpedo)) {
			//	return true;
			// }
			
			if(missiles[i]!=null && missiles[i].isHit(torpedo)) {
				return true;
			}
		}
		
		// If not, it will return false.
		return false;
	}
	
	
		
	public void remove(Missile missile) { 
		for(int i=0; i<missiles.length; i++) {
			if(missiles[i]==missile) {
				missiles[i] = null;
				break;
			}
		}
	}
	
}
