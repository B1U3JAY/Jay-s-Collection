package jrJava.alienInvader9_polymorphism;

import java.awt.Image;

public class RealNastyAlien extends MultiShootAlien{

	public RealNastyAlien(int x, int y, Image image1, Image image2, int vx, int vy, BattleShip target) {
		super(x, y, image1, image2, vx, vy, target);
	}
	
	public void move() {
		x += Math.abs(vx)*(target.getX() - x)/100; // The further the BattleShip is away from the NastyAlien, the faster this NastyAlien will move (increase vx).
		// We put /100 so that the Alien doesn't move too fast.
		super.move();
	}

}
