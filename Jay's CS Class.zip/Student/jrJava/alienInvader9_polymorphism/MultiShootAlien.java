package jrJava.alienInvader9_polymorphism;

import java.awt.Image;

public class MultiShootAlien extends SimpleAlien{
	
	public MultiShootAlien(int x, int y, Image image1, Image image2, int vx, int vy, BattleShip target) {
		super(x, y, image1, image2, vx, vy, target);
	}
	
	protected void shootMissile() {
		if(Math.random()<0.95) {
			return;
		}
		
		boolean missile1Fired = false;
		boolean missile2Fired = false;
		boolean missile3Fired = false;
		
		for(int i=0; i<10; i++) {
			if(missiles[i]==null) { //If there is an unoccupied storage space, we create a new Missile object into the next available one. Once it is full, we 'break' and get out of the loop.
				
				if(!missile1Fired) { // !false is true. So this will only happen if the missile IS FIRED.
					missiles[i] = new Missile(x, y, 2*vy, this, target); // This will be the 'center' missile and it will be stored in the first storage of 'missiles'.
					missile1Fired = true; // This is so that the next time it loops through, it will not go through this 'if block'.
				}
				
				else if(!missile2Fired) {
					missiles[i] = new Missile(x-width/4, y, 2*vy, this, target); // This will be the 'left' missile.
					missile2Fired = true; 
				}
				
				else if(!missile3Fired) {
					missiles[i] = new Missile(x+width/4, y, 2*vy, this, target); // This will be the 'right' missile.
					missile3Fired = true;
				}
			}         
		}
	}

}
