package jrJava.alienInvader9_polymorphism;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

import resources.DrawingBoard;
import resources.SoundPlayer;
import resources.Timer;

public class Test_Image_and_Sound {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(200, 0, 500, 500);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		Image alienImage = new ImageIcon("jrJava/alienInvader8_Images_and_Sounds/blueAlien_1.png").getImage(); // filepaths are used with '/' not '.'
		
		int width = alienImage.getWidth(null);
		int height = alienImage.getHeight(null);
		System.out.println(width + ", " + height);
		
		// g.drawImage(alienImage, 250, 200, 50, 30, null);
		g.drawImage(alienImage, 250, 200, null); // Will be normal size if width and height is not provided
		
		board.repaint();
		
		SoundPlayer sound = new SoundPlayer("jrJava/alienInvader8_Images_and_Sounds/laser.wav"); // We need to create a string as a constructor for the SoundPlayer
		
		/* 
		for(int i=0; i<5; i++) {
			sound.play();
			timer.pause(1000); // 1 second pause
		*/
		
		SoundPlayer bgSound = new SoundPlayer("jrJava/alienInvader8_Images_and_Sounds/bgMusic.wav");
		//bgSound.play();
		
		bgSound.playLoop();
		
	}
		
}


