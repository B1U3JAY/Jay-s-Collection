package jrJava.alienInvader9_polymorphism;

import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

public class CloakAlien extends SimpleAlien{
	
	protected double opacity = 1.0;
	protected double cloakRate = 0.01;

	public CloakAlien(int x, int y, Image image1, Image image2, int vx, int vy, BattleShip target) {
		super(x, y, image1, image2, vx, vy, target);
	}
	
	public void draw(Graphics g) { // We want the CloakAlien to be able to control the opacity and transparency of itself
		
		Graphics2D g2 = (Graphics2D) g; // Downcasting
		Composite original = g2.getComposite();
		
		opacity -= cloakRate; // Opacity will slowly go down
		if(opacity<0){
			opacity = 0;
		}
		
		if(collided){
			opacity = 1.0; // If there is collision they will pop back up, indicating that they have been hit.
		}
		
		// AlphaComposite.getInstance(rule, alpha);
		Composite c = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float)opacity); // 1 is 100% opaque while 0 is 100% transparent. However, 0.5 (because it asks for a float) cannot be used because it is a double number. 
		g2.setComposite(c); // However, this is a problem because the BattleShip, Torpedoes, and other objects use the same graphics, therefore, the whole game is blurred
		
		drawCount++;
		
		if(drawCount%drawCycle<drawCycle/2) { // Slow down the changing images by grouping it by 4's instead of 2's so that image1/image2 will be in "groups of 2" instead of a "group of 1"
			g.drawImage(image1, x-width/2, y-height, null);
		}
		else {
			g.drawImage(image2, x-width/2, y-height, null);
		}
				
		for(int i=0; i<10; i++) {
			if(missiles[i]!=null) {
				missiles[i].draw(g); // This command line will execute the specific missile object's "draw command"
			}
		}
				
		if(collided) {
			g.setColor(EXPLOSION_COLOR);
			g.drawOval(x-EXPLOSION_RADIUS, y-EXPLOSION_RADIUS, 2*EXPLOSION_RADIUS, 2*EXPLOSION_RADIUS);
			AlienMotherShip.remove(this); // <----- GAME OVER CONDITION
		}
		g2.setComposite(original); // We must state the original composite object we use after we change it so it won't affect any other objects.
	}
}
