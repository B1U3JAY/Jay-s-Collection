package jrJava.inheritance1;

public class Test {

	public static void main(String[] args) {
		
		B ref = new B(); // Default constructor method
		
		System.out.println(ref.b);
		ref.mB();
		
		System.out.println(ref.a);
		ref.mA();
		
		C ref2 = new C();
		
		System.out.println(ref2.c);
		ref2.mC();

		System.out.println(ref2.a);
		ref2.mA();
		
		System.out.println(ref2.b);
		ref2.mB();
		
	}

}
