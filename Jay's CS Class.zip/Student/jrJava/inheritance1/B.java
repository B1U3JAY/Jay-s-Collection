package jrJava.inheritance1;

public class B extends A { // "Extends" Relationship with A
	
	public int b = 20;
	
	public void mB() {
		System.out.println(b);
	}

}
