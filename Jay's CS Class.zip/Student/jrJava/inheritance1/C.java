package jrJava.inheritance1;

public class C extends B {
	
	public int c = 30;
	
	public void mC() {
		System.out.println(c);
	}

}
