package jrJava.inheritance1;

public class A {
	
	public int a = 10;
	
	public void mA() {
		System.out.println(a);
	}
	
}
