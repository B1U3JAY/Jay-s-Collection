package jrJava.LinkedList5_1_sorted;

public class Link<E> {
	
	// For learning purposes we will make everything public:
	public Link<E> next; // Next 'Link's' address
	public E obj; // Any Java data object can come through here
	
	public Link(E obj) {
		this.obj = obj;
	}
	
	public String toString() {
		return '[' + obj.toString() + ']';
	}
	
	public boolean equals(Object o) {
		if(!(o instanceof Link)) {
			return false;
		}
		Link<E> other = (Link<E>) o;
		return obj.equals(other.obj);
	}
	
}
