package jrJava.LinkedList5_1_sorted;

import java.util.Iterator;

public class MyIterator<E extends Comparable<E>> implements Iterator<E>{
	
	// Iterator (ex. Scanner(s)):
	
	private LinkedList<E> list;
	private Link<E> current; // Null; Should point to one before the 'first'
	private Link<E> previous;
	
	public MyIterator(LinkedList<E> list) {
		this.list = list;
	}

	public boolean hasNext() {
		if(current==null) { // Special Case
			return list.first!=null; 
		}
		
		return current.next!=null;
	}
	
	public E next() {
		if(current==null) { // Special Case
			current = list.first; // Jump to 'first'
			return list.first.obj;
		}
		
		previous = current;
		current = current.next;
		return current.obj;
	}
	
	public void remove() {
		if(current==null) { // Special Case
			throw new UnsupportedOperationException("remove-operation");
		}
		
		if(previous==null) {
			list.first = list.first.next;
			current = null;
			return;
		}
		
		previous.next = current.next;
		// Move cursor one step backward to avoid staying on the address of the link we are trying to remove:
		current = previous;
		
	}
	

}
