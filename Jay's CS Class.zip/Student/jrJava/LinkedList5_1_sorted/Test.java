package jrJava.LinkedList5_1_sorted;

import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		
		LinkedList<String> list = new LinkedList<String>();
		list.insertAtEnd("aaa");
		list.insertAtEnd("bbb"); 
		list.insertAtEnd("ccc");
		/*
		list.insert("ccc");
		list.insert("bbb");
		list.insert("aaa");
		*/
		
		Iterator<String> iter = new MyIterator<String>(list);
		while(iter.hasNext()) {
			// Object each = iter.next(); // String objects have a sense of order 
			// String each = (String) iter.next(); // Downcast because it results in a 'Cosmic Super Class' type
			String each = iter.next();
			System.out.println(each);
		}
		

	}

}
