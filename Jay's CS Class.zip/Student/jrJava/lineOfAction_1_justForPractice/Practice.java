package jrJava.lineOfAction_1_justForPractice;

import playLOA.LaunchLOA;

public class Practice {

	public static void main(String[] args) {
		
		LaunchLOA.launch();

	}

}
