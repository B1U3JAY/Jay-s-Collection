package jrJava.cosmicSuperClass2;

public class Test1 {
	
	// NOTE: THIS IS THE "RIGHT" WAY
	
	public static void main(String[] args) {
		
		Thing t1 = new Thing(10, 20);
		Thing t2 = new Thing(10, 20);
		
		System.out.println(t1.equals(t2)); // Both we be printed false BECAUSE it will try to check if t1's address is the same as t2's address.
		System.out.println(t1.toString()); // 
		
		System.out.println(t2.equals(t1)); // Both we be printed false BECAUSE it will try to check if t1's address is the same as t2's address.
		System.out.println(t2.toString());

	}
}
