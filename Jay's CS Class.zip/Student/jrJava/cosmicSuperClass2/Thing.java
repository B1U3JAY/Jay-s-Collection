package jrJava.cosmicSuperClass2;

public class Thing extends Object { // You do not need to put 'extends Object' because it is already implied
	
	// NOTE: THIS IS THE "RIGHT" WAY
	
	private int a;
	private int b;
	
	public Thing(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	public boolean equals(Object o) { // Overriding
		
		if(o == this) { // If the reference coming is has the same address as the object then it will return true (however it is a rare case).
			return true;
		}
		
		if(!(o instanceof Thing)) { // If 'o' is not [an "instance of"] / [a 'Thing' type object], it will return false. If 'o' is [an "instance of"] / [a 'Thing' type object], then we will be downcast it and return the needed value(s) below:
			return false;
		}
		
		Thing thing = (Thing) o; // Downcasting in order to access 'o.a' and 'o.b', which in this case will be 'thing.a' and thing.b'.
		return a == thing.a && b == thing.b; // By comparing all their current states (which hold values 'a' and 'b'), we can see 't1' and 't2' are "equal".
	}
	
	public String toString() {
		return "(a: " + a + ", b: " + b + ")";
	}

}
