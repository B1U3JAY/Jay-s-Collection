package jrJava.cosmicSuperClass;

public class Thing extends Object { // You do not need to put 'extends Object' because it is already implied
	
	// NOTE: THIS IS THE "WRONG WAY"
	
	private int a;
	private int b;
	
	public Thing(int a, int b) {
		this.a = a;
		this.b = b;
	}

}
