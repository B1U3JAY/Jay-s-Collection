package jrJava.aboutType3;

public class Doctor implements Parent{
	
	private String name;
	
	public Doctor(String name) {
		this.name = name;
	}
	
	public void consultpatient() {
		System.out.println("I consult patients.");
	}
	
	public String prescribeMedicine(){
		return "anitbiotics";
	}
	
	

	public void notifyMeeting() {
		
	}

	public void donateBooks() {
		
	}

	public void accidentAlert() {
		
	}

}
