package jrJava.aboutType3;

public interface Parent {
	
	void notifyMeeting();
	void donateBooks();
	void accidentAlert();

}
