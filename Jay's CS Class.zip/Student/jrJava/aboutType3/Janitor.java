package jrJava.aboutType3;

public class Janitor implements Parent, StockListener{
	
	private void mopFloors() {
		System.out.println("I cleaned them spic-span.");
	}
	
	public void cleanBathroom() {
		System.out.println("I cleaned all the toilets.");
	}
	
	
	
	public void notifyMeeting() {
		
	}
	
	public void donateBooks() {
		
	}
	
	public void accidentAlert() {
		
	}

	
	
	public void priceUp() {
		
	}

	public void priceDown() {
		
	}

}
