package jrJava.aboutType3;

public class StockServer {
	
	// private Doctor ref1;
	// private Programmer ref2;
	// private Janitor ref3;
	
	private StockListener[] listeners;
	
	public void doService() {
		// It will notify all clients if the stock's price goes up or down
		
		listeners[0].priceUp();
		listeners[0].priceDown();
		// listeners[0].donateBooks(); Cannot do this because it is not a method in the listeners' interface.
		
	}

}
