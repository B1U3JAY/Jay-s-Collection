package jrJava.aboutType3;

public interface StockListener {
	
	void priceUp();
	void priceDown();

}
