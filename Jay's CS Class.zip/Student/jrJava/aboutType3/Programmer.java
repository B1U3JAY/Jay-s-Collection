package jrJava.aboutType3;

public class Programmer implements Parent, StockListener{
	
	private String name;
	
	public Programmer(String name) {
		this.name = name;
	}
	
	public void developApps() {
		System.out.println("I developed Tetris");
	}
	
	public void debug() {
		System.out.println("I cleaned up all the code.");
	}
	
	
	
	public void notifyMeeting() {
		
	}
	
	public void donateBooks() {
		
	}
	
	public void accidentAlert() {
		
	}
	
	

	public void priceUp() {
		
	}

	public void priceDown() {
		
	}

}
