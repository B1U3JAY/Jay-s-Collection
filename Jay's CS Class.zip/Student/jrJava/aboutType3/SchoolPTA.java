package jrJava.aboutType3;

public class SchoolPTA{
	
	// fields need to hold parents' references (addresses).
	// private Doctor ref1;
	// private Programmer ref2;
	// private Janitor ref3;
	
	private Parent[] parents;
	
	public void doService() {
		
		// Using the parents' addresses, it can:
		// - Notify parents for meetings
		// - Ask them for book/money donations 
		// - Alert them of any accident
		
		parents[0].accidentAlert();
		parents[0].donateBooks();
		parents[0].notifyMeeting();
		
	}
	
}
