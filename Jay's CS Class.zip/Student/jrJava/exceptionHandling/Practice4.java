package jrJava.exceptionHandling;

public class Practice4 {

	public static void main(String[] args) {
		
		int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		
		int sum = 0;
		int i = 0;
		
		// Do not use exception handling to overcome code deficiency!
		
		try {
			while(true) {
				sum += a[i++];
			}
		}
		catch (Exception e){
			System.out.println(sum);
		}

	}

}
