package jrJava.exceptionHandling;

public class Practice3 {
	
	// This is for the purpose of seeing examples and is not recommened for use of practicing:

	public static void main(String[] args) {
		
		String message = null;
		int[] data = {1, 2, 3};
		String quantity = "4Q5";
		doWork(message, data, quantity);

	}
	
	public static void doWork(String message, int[] data, String quantity) { // throws NullPointerException, ArrayIndexOutOfBoundsException, NumberFormatException { // Or we can throw exception alternatively instead of 'try-catch' blocks.
		
		try {
			// Each of these below will throw RUN-TIME exceptions:
			System.out.println("Message length = " + message.length()); // Null Pointer
			System.out.println("Data at index 4 = " + data[4]); // Index Out Of Bounds Exception
			System.out.println("The number = " + Integer.parseInt(quantity)); // Number Format Exception
		}
		
		/*
		catch(RuntimeException e) { // Since all the exceptions above are 'Run-time Exceptions'.
			// .....
		}
		*/
		
		// OR you can make three seperate 'catch' blocks for each exception:
		
		catch(NullPointerException e){
			// .....
		}
		catch(ArrayIndexOutOfBoundsException e){
			// .....
		}
		catch(NumberFormatException e){
			// .....
		}
		
	}

}
