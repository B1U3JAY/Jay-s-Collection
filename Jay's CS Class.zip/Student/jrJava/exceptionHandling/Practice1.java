package jrJava.exceptionHandling;

public class Practice1 {

	public static void main(String[] args) {
		
		int[] a = {2, 3, 5};
		
		System.out.println("Point 1");
		// doSomething(a, 3);
		if(3<=a.length-1) {
			doSomething(a, 3);
		}
		System.out.println("Point 4");

	}
	
	/*
	public static void doSomething(int[] data, int index) { // Throws a Runtime exception from here back to the main method because it is 'ArrayIndexOutOfBoundsException'.
		
		System.out.println("Point 2");
		System.out.println(data[index]);
		System.out.println("Point 3");
		
	}
	*/
	
	public static void doSomething(int[] data, int index) { 
		
		System.out.println("Point 2");
		
		// Note: This example is for educational purposes, it is recommended to let the Run-time exception(s) be 'thrown' back to the main method instead of 'handling' the exception.
		try { // If this does not work .....
			// if(index<=data.length-1) { // THIS is better as it "blocks" the potential run-in with this kind of exception.
			System.out.println(data[index]);
		    // }
		}
		catch(RuntimeException e) { // It will go into here:
			System.out.println("I handled it.");
		}
		
		System.out.println("Point 3");
		
	}

}
