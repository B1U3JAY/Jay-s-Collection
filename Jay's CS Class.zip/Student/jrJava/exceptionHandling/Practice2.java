package jrJava.exceptionHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Practice2 {

	public static void main(String[] args) throws FileNotFoundException{
		
		String path = "networkConn/.,,/data.txt";
		
		mA(path);
		
		/*  // If you do not use the 'try-catch' statement(s), you must throw the exception instead.
		try {
			mA(path);
		}
		catch(FileNotFoundException e) {
			// .....
		}
		*/

	}
	
	public static void mA(String path) throws FileNotFoundException{
		// .....
		mB(path);
		
		/*  // If you do not use the 'try-catch' statement(s), you must throw the exception instead.
		try {
			mB(path);
		}
		catch(FileNotFoundException e) {
			// .....
		}
		*/
		// .....
	}
	
	public static void mB(String path) throws FileNotFoundException{
		// .....
		
		Scanner sc = new Scanner(new File(path));
		
		// .....
		
		/*  // If you do not use the 'try-catch' statement(s), you must throw the exception instead.
		try {
			Scanner sc = new Scanner(new File(path)); // 'IO Exception'; Aside from 'Run-time Exception' (in which case we do not need to deal with it), we MUST use the 'try-catch' block statement in order to throw these exceptions.
		}
		catch(FileNotFoundException e) {
			// code that handles the exception
		}
		*/
		
		// .....
	}
	
}
