package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;
import resources.DrawingBoard;
import resources.Timer;

public class BrownianMotionCircle {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		DrawingBoard board = new DrawingBoard(0, 0, 500, 500);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		board.clear();
	
		int n;
		int r = 50;
		int x = 200;
		int y = 200;
		int r2 = 0;
		int g2 = 0;
		int b = 255;
		int i;
		
		for(;;) {
			
			board.clear();
			x = 200 - (int)(Math.random()*6-3);
			r2 = (int)(Math.random()*255);
			g2 = (int)(Math.random()*255);
			b = (int)(Math.random()*255);
			g.setColor(new Color(r2, g2, b));
			g.fillOval(x, y, r, r);
			board.repaint();
			timer.pause(40);
			
			board.clear();
			x = 200 + (int)(Math.random()*6-3);
			r2 = (int)(Math.random()*255);
			g2 = (int)(Math.random()*255);
			b = (int)(Math.random()*255);
			g.setColor(new Color(r2, g2, b));
			g.fillOval(x, y, r, r);
			board.repaint();
			timer.pause(40);
			
			board.clear();
			y = 200 - (int)(Math.random()*6-3);
			r2 = (int)(Math.random()*255);
			g2 = (int)(Math.random()*255);
			b = (int)(Math.random()*255);
			g.setColor(new Color(r2, g2, b));
			g.fillOval(x, y, r, r);
			board.repaint();
			timer.pause(40);
			
			board.clear();
			y = 200 + (int)(Math.random()*6-3);
			r2 = (int)(Math.random()*255);
			g2 = (int)(Math.random()*255);
			b = (int)(Math.random()*255);
			g.setColor(new Color(r2, g2, b));
			g.fillOval(x, y, r, r);
			board.repaint();
			timer.pause(40);
		}
	}	
}