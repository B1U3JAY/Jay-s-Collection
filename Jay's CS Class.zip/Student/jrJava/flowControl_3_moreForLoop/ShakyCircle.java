package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;

import resources.DrawingBoard;

import resources.Timer;

public class ShakyCircle {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		DrawingBoard board = new DrawingBoard(0, 0, 500, 500);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		board.clear();
	
		int n;
		int r = 200;
		int x = 150;
		int y = 150;
		int b = 100;
		int i;
		
		g.setColor(Color.BLACK);
		g.drawRect(150, 150, 200, 200);
		
		for(;;) {
			board.clear();
			x-=Math.random()*20-10;
			g.setColor(new Color(0, 0, b));
			g.fillOval(x, y, r, r);
			board.repaint();
			timer.pause(40);
			
			x+=Math.random()*20-10;
			g.setColor(new Color(0, 0, b));
			g.fillOval(x, y, r, r);
			board.repaint();
			timer.pause(40);
			
			y-=Math.random()*20-10;
			g.setColor(new Color(0, 0, b));
			g.fillOval(x, y, r, r);
			board.repaint();
			timer.pause(40);
			
			y+=Math.random()*20-10;
			g.setColor(new Color(0, 0, b));
			g.fillOval(x, y, r, r);
			board.repaint();
			timer.pause(40);
		}
	}	
}

