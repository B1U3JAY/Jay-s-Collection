package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;
import resources.DrawingBoard;
import resources.Timer;

public class Nesting_ForLoop_With_Graphics {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(0, 0, 2000, 1000);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		int x = 150;
		int y = 150;
		int i;
		
		for(i=1; i<=100; i++) {
			board.clear();
			Color CircleColor = new Color(255-255/100*i, 0, 0);
			g.setColor(CircleColor);
			g.fillOval(x, y, 100, 100);
			x += 5;
			timer.pause(20);
			board.repaint();
		}
		for(i=1; i<=100; i++) {
			board.clear();
			Color CircleColor2 = new Color(255/100*i, 0, 0);
			g.setColor(CircleColor2);
			g.fillOval(x, y, 100, 100);
			y += 5;
			timer.pause(20);
			board.repaint();
		}
		for(i=1; i<=100; i++) {
			board.clear();
			Color CircleColor = new Color(255-255/100*i, 0, 0);
			g.setColor(CircleColor);
			g.fillOval(x, y, 100, 100);
			x -= 5;
			timer.pause(20);
			board.repaint();
		}
		for(i=1; i<=100; i++) {
			board.clear();
			Color CircleColor2 = new Color(255/100*i, 0, 0);
			g.setColor(CircleColor2);
			g.fillOval(x, y, 100, 100);
			y -= 5;
			timer.pause(20);
			board.repaint();
		}
	}
}
