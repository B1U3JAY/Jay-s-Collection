package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;

import resources.DrawingBoard;
import resources.Timer;

public class ConnectedMultipleCircles {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(0, 0, 700, 700);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		Scanner sc = new Scanner(System.in);
		
		int x = 0;
		int y = 0;
		int radius = 25;
		int i;
		
		for(i=1; i<= 10; i++) {
			int previous_x = x;
			int previous_y = y;
			System.out.println("Please type in an integer x coordinate for circle #" + i + ":");
			x = sc.nextInt();
			System.out.println("Please type in an integer y coordinate for circle #" + i + ":");
			y = sc.nextInt();
			g.setColor(Color.GREEN);
			g.fillOval(x, y, 50, 50);
			board.repaint();
			if (i!=1) {
				g.drawLine(x+radius, y+radius, previous_x+radius, previous_y+radius);
			}
		}
		sc.close();
	}
}