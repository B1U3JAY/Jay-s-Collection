package jrJava.flowControl_3_moreForLoop;

public class UsingForLoop3 {

	public static void main(String[] args) {
		
		// 1 + 2 + 3 + ... + 789
		int sum = 0;
		int i;
		for(i=1; i<=789; i++) {
			sum+=i;
		}
		System.out.println(sum);

		//1 + 2 + 3 + ... + 789
		sum = 0;
		for(i=1; ; i+=2) {
			sum +=i;
		}
		System.out.println(sum);
		
		//1 + 2 + 3 + ... + 789
		sum = 0;
		for(i=1; ; i+=2) {
			sum +=i;
		}
		System.out.println(sum);
		
		// 1*1 + 2*2 + 3*3 + ... + 100*100
		sum = 0;
		for(i=1; i<=100; i++) {
			sum += i*i;
		}
		System.out.println(sum);
		
		// 1*2 + 2*3 + 3*4 + ... + 99*100
		sum = 0;
		for(i=1; i<=99; i++) {
			sum += i*(i+1);
		}
		System.out.println(sum);
		
		// sqrt(50) + sqrt(55) + sqrt(60) + ... + sqrt(200)
		double sum2 = 0;
		for(i=50; i<=200; i+=5) {
			sum2 += Math.sqrt(i);
		}
		System.out.println(sum2);
	}
}
