package jrJava.flowControl_3_moreForLoop;

public class ForLoop_Sum_Printing {

	public static void main(String[] args) {
		
		int i;
		int n = 0;
		for(i=2; i<=28; i+=2){
			if (n%2==0) {
				System.out.print(i + " "); 
			}
			else {
				System.out.print(-i + " "); 
			}
			n++;
		}
	}
}
