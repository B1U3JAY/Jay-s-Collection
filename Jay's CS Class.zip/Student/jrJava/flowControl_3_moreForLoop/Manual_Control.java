package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;

import resources.DrawingBoard;

public class Manual_Control {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		DrawingBoard board = new DrawingBoard(200, 500, 600, 1000);
		Graphics g = board.getCanvas();
		board.clear();
	
		int n;
		int r = 150;
		int x = 300;
		int y = 300;
		int gr = 200;
		int i;
		
		for(i=1; i<=100; i++) {
			g.setColor(new Color(0, gr, 0));
			g.fillOval(x, y, r, r);
			System.out.println("Change the color of the circle (Type in '1' to make it brighter and '2' to maake it darker):");
			n = sc.nextInt();
			if (n==1) {
				board.clear();
				gr+=2;
				g.setColor(new Color(0, gr, 0));
				g.fillOval(x, y, r, r);
				board.repaint();
			}
			else if(n==2) {
				board.clear();
				gr-=2;
				g.setColor(new Color(0, gr, 0));
				g.fillOval(x, y, r, r);
				board.repaint();
			}
			else {
				System.out.println("Please enter a number that is listed:");
			}
		}
	}	
}


/*
		Scanner sc = new Scanner(System.in);
		DrawingBoard board = new DrawingBoard(200, 100, 600, 400);
		Graphics g = board.getCanvas();
		board.clear();
	
		int n;
		int r = 100;
		int x = 300;
		int y = 300;
		int s = 30;
		int e = 90;
		int i;
		
		for(i=1; i<=100; i++) {
			g.setColor(Color.RED);
			g.fillArc(x, y, r, r, s, e);
			System.out.println("Dilate the circle (Type in '1' to grow and '2' to shrink):");
			n = sc.nextInt();
			if (n==1) {
				board.clear();
				e+=5;
				g.fillArc(x, y, r, r, s, e);
				board.repaint();
			}
			else if(n==2) {
				board.clear();
				e-=5;
				g.fillArc(x, y, r, r, s, e);
				board.repaint();
			}
			else {
				System.out.println("Please enter a number that is listed:");
			}
		}
	}	
}
 */


/*
		Scanner sc = new Scanner(System.in);
		DrawingBoard board = new DrawingBoard(200, 100, 600, 400);
		Graphics g = board.getCanvas();
		board.clear();
		
		int n;
		int r = 50;
		int x = 300;
		int y = 300;
		int i;
		
		for(i=1; i<=100; i++) {
			g.setColor(Color.ORANGE);
			g.fillOval(x, y, r, r); 
			System.out.println("Dilate the circle (Type in '1' to grow and '2' to shrink):");
			n = sc.nextInt();
			if (n==1) {
				board.clear();
				r+=5;
				g.fillOval(x, y, r, r);
				board.repaint();
			}
			else if(n==2) {
				board.clear();
				r-=5;
				g.fillOval(x, y, r, r);
				board.repaint();
			}
			else {
				System.out.println("Please enter a number that is listed:");
			}
		}
	}	
}
*/

/*
		Scanner sc = new Scanner(System.in);
		DrawingBoard board = new DrawingBoard(200, 100, 600, 400);
		Graphics g = board.getCanvas();
		board.clear();
		
		int n;
		int r = 50;
		int x = 300;
		int y = 300;
		int i;
		
		for(i=1; i<=100; i++) {
			g.setColor(Color.GREEN);
			g.fillOval(x, y, r, r); 
			System.out.println("Move the circle (Type in '1' to move left, '2' to move right, '3' to move up, and '4' to move down):");
			n = sc.nextInt();
			if (n==1) {
				board.clear();
				x-=5;
				g.fillOval(x, y, r, r);
				board.repaint();
			}
			else if(n==2) {
				board.clear();
				x+=5;
				g.fillOval(x, y, r, r);
				board.repaint();
			}
			else if(n==3) {
				board.clear();
				y+=5;
				g.fillOval(x, y, r, r);
				board.repaint();
			}
			else if(n==4) {
				board.clear();
				y-=5;
				g.fillOval(x, y, r, r);
				board.repaint();
			}
			else {
				System.out.println("Please enter a number that is listed:");
			}
		}
	}	
*/