package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;
import resources.DrawingBoard;
import resources.Timer;
import java.util.Scanner;

public class MultipleCircles {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(0, 0, 700, 700);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		Scanner sc = new Scanner(System.in);
		
		int x = 100;
		int y = 100;
		int r = 50;
		int n = 0;
		int changex = 5;
		int changey = 6;
		int i;
		
		for(i=1; i<=10; i++) {
			n++;
			r+=20;
			System.out.println("Please type in an x coordinate for circle #" + n + ":");
			x = sc.nextInt();
			System.out.println("Please type in an y coordinate for circle #" + n + ":");
			y = sc.nextInt();	
			g.setColor(Color.GREEN);
			g.fillOval(x, y, r, r);
			board.repaint();	
		}
		sc.close();
	}
}