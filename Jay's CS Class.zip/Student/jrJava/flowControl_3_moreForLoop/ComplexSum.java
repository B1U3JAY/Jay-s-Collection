package jrJava.flowControl_3_moreForLoop;

public class ComplexSum {

	public static void main(String[] args) {
		
		// (1) + (1+2) + (1+2+3) + ... (1+2+3+...100)
		
		int i;
		int j;
		int sum = 0;
		
		for(i=1; i<=100; i++) {
			
			for(j=1; j<=i; j++) {
				
				sum += j;
				
			}
		}
		
		System.out.println("sum = " + sum);
		
	}
}
