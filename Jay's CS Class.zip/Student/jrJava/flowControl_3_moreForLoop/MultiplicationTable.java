package jrJava.flowControl_3_moreForLoop;

public class MultiplicationTable {

	public static void main(String[] args) {
		
		int i;
		int j;

/*
		for(i=2; i<=9; i++) {
			
			for(j=2; j<=9; j++) {
				
				System.out.println(i + " x " + j + " = " + i*j);
			}
			System.out.println();
		}	
		*/
		for(i=2; i<=9; i++) {
			
			for(j=2; j<=9; j++) {
				
				System.out.println(i + " x " + j + " = " + i*j);
			}
			System.out.println();
		}	
	}
}
