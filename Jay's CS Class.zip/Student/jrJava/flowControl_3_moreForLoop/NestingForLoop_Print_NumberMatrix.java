package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;
import resources.Timer;

public class NestingForLoop_Print_NumberMatrix {

	public static void main(String[] args) {
		 DrawingBoard board = new DrawingBoard(100, 100, 700, 700);
		 Graphics g = board.getCanvas();
		 
		 int i, j;
		 int tileSize = 40;
		 Color color;
		 
		 board.clear();
		 
		 for(i=0; i<10; i++){
			 for(j=0; j<10; j++) {
				 color = new Color((10-j+i)*255/20, (10+j-i)*255/20, 0);
				 
				 g.setColor(color);
				 g.fillRect(100+tileSize*(i-1), 100+tileSize*(j-1), tileSize, tileSize);
				 g.setColor(Color.BLACK);
				 g.drawRect(100+tileSize*(i-1), 100+tileSize*(j-1), tileSize, tileSize);
			 }
		 }
	 board.repaint();
	}
}

