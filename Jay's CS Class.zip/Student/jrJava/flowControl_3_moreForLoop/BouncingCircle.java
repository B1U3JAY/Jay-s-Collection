package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;
import resources.DrawingBoard;
import resources.Timer;

public class BouncingCircle {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(0, 0, 700, 700);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		int x = 100;
		int y = 100;
		int changex = 5;
		int changey = 6;
		int i;
		
		for(;;) {
			x += changex;
			y += changey;
			board.clear();
			g.setColor(Color.BLUE);
			g.fillOval(x, y, 50, 50);
			board.repaint();
			timer.pause(50);
			if(x==400) {
				changex=-5;
			}
			else if(x==100) {
				changex=+5;
			}
			if(y==400) {
				changey=-6;
			}
			else if(y==100) {
				changey=+6;
			}
			board.clear();
		}
	}
}
/*
				else if (x==400 && y==400) {
					changex=-5;
					changey=-6;
				}
				else if (x==100 && y==400) {
					changex=+5;
					changey=-6;
				}
				else if (x==400 && y==100) {
					changex=-5;
					changey=+6;
				}
				else if (x==100 && y==100) {
					changex=+5;
					changey=+6;
				}
*/