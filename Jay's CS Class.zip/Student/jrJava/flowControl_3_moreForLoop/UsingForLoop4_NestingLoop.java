package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class UsingForLoop4_NestingLoop {

	public static void main(String[] args) {

		int i;
		int j;
		DrawingBoard board = new DrawingBoard(0, 0, 2000, 700);
		Graphics g = board.getCanvas();
/*
		for(i=1; i<=3; i++) {
			
			for(j=1; j<=4; j++) {
				
				System.out.println(i + ", " + j);
				
			}
		}
		
		for(i=1; i<=3; i++) {
			
			for(j=1; j<=i; j++) {
				
				System.out.println(i + ", " + j);
				
			}
		}

		for(i=1; i<=3; i++) {
			
			for(j=i; j<=4; j++) {
				
				System.out.println(i + ", " + j);
				
			}
		}
*/
		for(i=1; i<=4; i++) { 
			for(j=5; j>=i+1; j--) { 
				g.setColor(Color.CYAN);
				g.fillRect(i*100, j*100, 100, 100); }
		}
		g.setColor(Color.BLACK); 
		for(i=1; i<=5; i++) {
			for(j=1; j<=5; j++) {
				g.drawRect(i*100, j*100, 100, 100);
			}
		}
	}
}
