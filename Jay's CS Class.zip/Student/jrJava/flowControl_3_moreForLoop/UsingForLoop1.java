package jrJava.flowControl_3_moreForLoop;

public class UsingForLoop1 {

	public static void main(String[] args) {
		
		// Let's predict what will happen:
		
		int i;
		for(i=1; i<=4; i++) {
			System.out.println("i= " + i);
		}
		System.out.println("Outside Loop: i = " + i);
		System.out.println();
		
		for(i=3; i<9; i=i+3) {
			System.out.println("i= " + i);
		}
		System.out.println("Outside Loop: i = " + i);
		System.out.println();
		
		
		for(i=-1; i<5; i+=2) {
			System.out.println("i= " + i);
		}
		System.out.println("Outside Loop: i = " + i);
		System.out.println();
		
		
		int j;
		for(j=10; j>=5; j--) {
			System.out.println("j= " + j);
		}
		
		System.out.println("Outside Loop: j = " + j);
		System.out.println();
		
		
		
		
		double myMoney;
		
		for(myMoney=1.25; myMoney<=2; myMoney+=0.1) {
			// System.out.println("My money is $" + myMoney);
			System.out.printf("My money is $%5.2", myMoney);
			
		}
		
		System.out.printf("Outside Loop: myMoney is $%5.2f \n", myMoney);
		System.out.println();
		
	}
}
