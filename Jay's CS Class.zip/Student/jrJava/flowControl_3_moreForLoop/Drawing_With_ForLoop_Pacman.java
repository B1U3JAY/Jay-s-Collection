package jrJava.flowControl_3_moreForLoop;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;
import resources.DrawingBoard;
import resources.Timer;

public class Drawing_With_ForLoop_Pacman {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(0, 0, 750, 750);
		Graphics g = board.getCanvas();
		Scanner sc = new Scanner(System.in);
		Timer timer = new Timer();
		int i = 0;
		
		g.setColor(Color.BLUE);
		g.fillOval(350, 350, 100, 100);
		board.repaint();
		
		g.setColor(Color.WHITE);
		g.fillOval(400, 360, 20, 20);
		
		int n=0;
		
		for (;;) {
			g.setColor(Color.BLUE);
			g.fillOval(350, 350, 100, 100);
			board.repaint();
			
			g.setColor(Color.WHITE);
			g.fillOval(400, 360, 20, 20);
			
			n++;
			
			if (n%2==0) {
				g.setColor(Color.WHITE);
				g.fillArc(350, 350, 100, 100, 140, 80);
				timer.pause(500);
				board.repaint();
			}
			else {
				g.setColor(Color.WHITE);
				g.fillArc(350, 350, 100, 100, 170, 20);
				timer.pause(500);
				board.repaint();
			}
		}
	}
}
