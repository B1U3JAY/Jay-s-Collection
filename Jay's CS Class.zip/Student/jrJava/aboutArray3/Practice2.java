package jrJava.aboutArray3;

import jrJava.AlienInvader1.Missile;

public class Practice2 {
	
	// Format:
	// Reference_of_any_array.length_of_the_array();
	// For example:
	// missiles.length();

	public static void main(String[] args) {
		
		Missile[] theMissiles= {new Missile(110, 220, 20), new Missile(170, 270, 17), new Missile(150, 79, 7), new Missile(90, 50, 5)};
		
		makeThemMove(theMissiles);
		
	}
	
	public static void makeThemMove(Missile[] missiles) {
		
		System.out.println(missiles.length); // Right now the missile length is 4. So i will be less than 4 or reference.length - 1.
		
		for(int i=0; i<missiles.length; i++) {
			missiles[i].move();
		}
		
	}

}
