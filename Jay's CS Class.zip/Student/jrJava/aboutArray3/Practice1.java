package jrJava.aboutArray3;

public class Practice1 {

	public static void main(String[] args) {
		
		int[] values;
		// ..
		values = new int[] {7, 3, 2, 11, 5, 15, 4};
		// ...
		int smallest = getMinimum(values);
		System.out.println(smallest);
	}
	
	public static int getMinimum(int[] data) {
		int min = data[0];
		for(int i=1; i<data.length; i++) {
			if(data[i]<min) {
				min = data[i];
			}
		}
		return min;
	}

}
