package jrJava.inheritance9_abstractClass;

public abstract class Dog extends Mammal implements Trainable{
	
	public void bark() {
		System.out.println("I can bark.");
	}
	
	public void move() { 
		System.out.println("I can chase after a mailman.");
	}

}
