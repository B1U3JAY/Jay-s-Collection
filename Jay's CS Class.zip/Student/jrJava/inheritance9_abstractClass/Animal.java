package jrJava.inheritance9_abstractClass;

public abstract class Animal {
	
	public abstract void move();

}
