package jrJava.inheritance9_abstractClass;

public class Husky extends Dog{
	
	public void pullSled() {
		System.out.println("I can pull a sled.");
	}
	
	public void move() { 
		System.out.println("I can run in snow.");
	}
	
	public void train() {
		System.out.println("Trained to pull a sled in snow.");
	}

}
