package jrJava.inheritance9_abstractClass;

public class Parrot extends Bird implements Trainable{
	
	public void imitateSound() {
		System.out.println("I can imitate a sound.");
	}
	
	public void peck() {
		System.out.println("I can peck with rhythm");
	}
	
	public void train() {
		System.out.println("Trained to mimic words.");
	}

}
