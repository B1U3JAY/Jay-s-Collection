package jrJava.inheritance9_abstractClass;

public class AnimalHospital {
	
	public void performTreatment(Animal animal) {
		// .....
		animal.move();
		// .....
	}
	
	public void performTreatment(Animal[] animals) {
		// .....
		for(int i=0; i<animals.length; i++) {
			animals[i].move();
		}
		// .....
	}


}
