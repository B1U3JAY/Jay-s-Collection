package jrJava.inheritance9_abstractClass;

public class Bird extends Animal{
	
	public void peck() {
		System.out.println("I can peck.");
	}
	
	public void move() { // Method Overriding requires the name to be the same, the return type to be the same, and the same parameter requirements. Otherwise, it become Method OVERLOADING.
		System.out.println("I can fly.");
	}

}
