package jrJava.inheritance9_abstractClass;

public class Shepherd extends Dog{
	
	public void watchSheep() {
		System.out.println("I can watch sheep.");
	}
	
	public void train() {
		System.out.println("Trained to watch farm animals.");
	}

}
