package jrJava.inheritance9_abstractClass;

public class Chicken extends Bird{
	
	public void cuckaDoodleDoo() {
		System.out.println("I can cuck-a-doodle-doo.");
	}
	
	public void move() { 
		super.move(); // This will access Bird's move method which is flying.
		System.out.println("I can cross a road.");
	}
	
	public void peck() {
		System.out.println("I can peck with a style.");
	}

}
