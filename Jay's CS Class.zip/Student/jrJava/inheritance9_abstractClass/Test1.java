package jrJava.inheritance9_abstractClass;

public class Test1 {

	public static void main(String[] args) {
		
		// new Animal(); // You cannot do this since
		// new Mammal(); // they are abstract classes, so you cannot create an object out of them.
		
		// They can be used as types instead.
		Animal ref = new Chicken(); 
		Mammal ref2 = new Dog();
		
	}

}
