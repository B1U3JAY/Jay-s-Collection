package jrJava.inheritance9_abstractClass;

public class Test2 {

	public static void main(String[] args) {
		
		// new Dog();
		
		// We can use the interface and abstract classes as TYPES.
		Trainable ref1 = new Parrot();
		
		Dog ref2 = new Husky();
		 
		Trainable ref3 = ref2; // Ref2 is a dog type.

	}

}
