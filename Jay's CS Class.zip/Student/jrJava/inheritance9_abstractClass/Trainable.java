package jrJava.inheritance9_abstractClass;

public interface Trainable {
	
	void train(); // In front of this hides "public abstract"

}
