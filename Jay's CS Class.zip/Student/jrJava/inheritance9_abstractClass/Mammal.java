package jrJava.inheritance9_abstractClass;

public abstract class Mammal extends Animal{
	
	public void lactate() {
		System.out.println("I can lactate.");
	}

}
