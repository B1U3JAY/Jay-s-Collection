package jrJava.aboutType2;

// 1. Interface defines a 'type' as something that can do jobs (methods) required by the interface, m1() and m2(double)
// 2. So, if an object says it is an 'interface' type, then all others will expect it to have those methods required by the interface.
// 3. However, the interface itself will not complete those methods. 
// 	  It will leave them as incomplete. it will only say what jobs they will need to do.
//    But, it will not say exactly say how they are going to do them.
//    Without a method body -----? They are just ideas (Abstract)
// 4. Whoever wants to be the interface type, they need to take over those incomplete methods and complete them by providing method bodies.
// 5. Any class can be any interface type. (This is how 'interface' is different from 'inheritance'.)
// 6. Any class can implement as many interfaces as it likes as long as it completes all the abstract methods of those interfaces. (This is how 'interface' is different from 'inheritance'.)
// *Interface is very flexible, while inheritance is restricted.*

public interface III {
	
	void m1(); 					// public abstract void m1();
	int m2(double b); 		    // public abstract int m2(double b);
	
}
