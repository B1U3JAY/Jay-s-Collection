package jrJava.aboutType2;

// 1. When a class implements an interface and it does not complete all the abstract methods (If it leaves any out),
// 	  then the class will also become an incomplete class. It will also have to declare itself as
//    an 'abstract' class (meaning it has an incomplete design).
// 2. An abstract class cannot be used to create an object (cannot do "new BBB()".)
// 3. Sounds useless? Then, why do we even bother to deal with this abstract (incomplete) class.
//    You will see later that his 'abstract class' can be used as an "excellent type".

public abstract class BBB implements III{
	
	private int field1;
	private int field2;
	
	public BBB() {
		field1 = 10;
		field2 = field1*field1;
	}
	
	public void method2() {
		System.out.println("method2()");
	}
	
	// public abstract void m1();
	// public abstract int m2(double b);
}
