package jrJava.aboutType2;

public interface JJJ {
	void m3();
}
