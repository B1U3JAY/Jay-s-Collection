package jrJava.aboutType2;

// Suppose we say this class AAA also wants to be the Interface III type:
// (It is already 'AAA' type, but it also wants to be viewed as 'III' type.)

//  1. It needs to declare that it"implements the interface".
//  2. It will need to take over the abstract methods and complete them by providing the method bodies.

public class AAA implements III, JJJ  {

	private int field1;
	private int field2;
	
	public AAA() {
		field1 = 3;
		field2 = 7;
	}
	
	public void method1() {
		System.out.println("method1()");
	}
	
	public void m1() {
		System.out.println("Good morning!");
	}
	
	public int m2(double b) {
		return (int)(b*100);
	}
	
	public void m3() {
		System.out.println("Good afternoon!");
	}
	
}
