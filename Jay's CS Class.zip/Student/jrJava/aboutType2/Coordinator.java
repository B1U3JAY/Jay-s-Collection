package jrJava.aboutType2;

public class Coordinator {

	public static void main(String[] args) {
		
		AAA ref1 = new AAA();
		III ref2 = new AAA();
		JJJ ref3 = new AAA();
		
		ref1.method1();
		ref1.m1();
		ref1.m2(0.01);
		ref1.m3();
		
		ref2.m1();
		ref2.m2(0.1);
		//ref2.method1();
		
		ref3.m3();
		//ref2.m1();
		
		// BBB ref4 = new BBB(); // This does not work because BBB is an abstract (incomplete) class

	}

}
