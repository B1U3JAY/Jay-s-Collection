package jrJava.memoryCard_1;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Coordinator {
	
	private static String[] imageNames = {
										"apple", "bank", "basketball", "bubble_blue", "bubble_green", 
										"bubble_red", "building", "cat", "cheese", "denture", 
										"dog", "hockey_stick", "keys", "phone", "pizza",
										"santa", "soccer_ball", "sock", "toilet_bowl", "toilet_paper",
										"xmas_tree"};

	public static void main(String[] args) {
		
		Card[] cards = new Card[42]; // Exclude "backside.png" because it will be used as a back cover for all the cards
		
		Image image;
		
		for(int i=0; i<cards.length; i+=2) { // i+=2 because we need to when i is 0, the image will go into cards[0] and cards[1]. When i is 2 it will start at cards[2] and cards[3].....
			image = new ImageIcon("jrJava/memoryCard_imagesAndSounds/" + imageNames[i/2] + ".png").getImage();  // 0, (skip 1), 2, (skip 3), 4, (skip 5)..... So, we divide by 2
			cards[i] = new Card(image); // x2 card objects
			cards[i+1] = new Card(image);
		}
		
		GameBoard board = new GameBoard(cards);
		
	}

}
