package jrJava.memoryCard_1;

import java.awt.*;

public class Card {
	
	public static final int SIZE = 100;
	private int x, y;
	private Image image;
	
	public Card(Image image) {
		this.image = image;
		
	}
	
	public void setXY(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public void show() {
		
	}
	
	public void hide() {
		
	}
	
	public void paint(Graphics g) {
		
		// ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY); // Downcasting!!!!! This will "erase" or clean up the jagged lines shown in each picture.
		// ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		g.drawImage(image, x+SIZE/10, y+SIZE/10, SIZE*4/5, SIZE*4/5, null); // Field (x, y) is card's left-hand corner. The middle frame is a tenth of the size of the main square away from both x and y. / SIZE*4/5 because the area of the middle square is 80 pixels instead of 100. / Middle square that is 10 pixels away from each inner side of the outer square.
		
		g.setColor(Color.LIGHT_GRAY);
		g.drawRect(x+5, y+5, SIZE-10, SIZE-10); // Creating a center frame 5 pixels away from each inner side of the main square
		g.setColor(Color.BLACK);
		g.drawRect(x, y, SIZE, SIZE);
	}

}
