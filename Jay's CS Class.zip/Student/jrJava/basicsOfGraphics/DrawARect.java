package jrJava.basicsOfGraphics;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;

import resources.DrawingBoard;

public class DrawARect {

	public static void main(String[] args) {
		
		int x;	
		int y;
		int w;
		int h;
		Scanner sc = new Scanner(System.in);
		System.out.println("Please type in the x-coordinate of the rectangle:");
		x = sc.nextInt();
		System.out.println("Please type in the y-coordinate of the rectangle:");
		y = sc.nextInt();
		System.out.println("Please type in the width of the rectangle:");
		w = sc.nextInt();
		System.out.println("Please type in the height of the rectangle:");
		h = sc.nextInt();
		DrawingBoard board = new DrawingBoard(100, 100, 1000, 1000);
		Graphics g = board.getCanvas();
		board.clear();
		g.setColor(Color.BLUE);
		g.drawRect(x, y, w, h); 
		g.fillRect(x, y, w, h); 
		board.repaint();
		board.repaint();
	}
}