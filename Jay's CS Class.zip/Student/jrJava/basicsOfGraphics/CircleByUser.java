package jrJava.basicsOfGraphics;

import java.awt.Color;

import java.awt.Graphics;

import resources.DrawingBoard;

import java.util.Scanner;

public class CircleByUser {

	public static void main(String[] args) {
		int x;	
		int y;
		int r;
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the x-coordinate of the circle's center:");
		x = sc.nextInt();
		System.out.println("Enter the y-coordinate of the circle's center:");
		y = sc.nextInt();
		System.out.println("Enter the radius of the circle:");
		r = sc.nextInt();
		System.out.println("Choose the color (Type in '1' for red, '2' for green, '3' for blue, '4' for yellow):");
		n = sc.nextInt();
		DrawingBoard board = new DrawingBoard(200, 100, 600, 400);
		Graphics g = board.getCanvas();
		board.clear();
		if(n==1) {
			g.setColor(Color.RED);
			g.drawOval(x, y, r, r); 
			g.fillOval(x, y, r, r);
			board.repaint();
		}
		else if(n==2) {
			g.setColor(Color.GREEN);
			g.drawOval(x, y, r, r); 
			g.fillOval(x, y, r, r);
			board.repaint();
		}
		else if(n==3) {
			g.setColor(Color.BLUE);
			g.drawOval(x, y, r, r); 
			g.fillOval(x, y, r, r);
			board.repaint();
		}
		else {
			g.setColor(Color.YELLOW);
			g.drawOval(x, y, r, r); 
			g.fillOval(x, y, r, r);
			board.repaint();
		}
	}
}
		/*
		int x;
		
		int y;
		int r;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the x-coordinate of the circle's center:");
		x = sc.nextInt();
		System.out.println("Enter the y-coordinate of the circle's center:");
		y = sc.nextInt();
		System.out.println("Enter the radius of the circle:");
		r = sc.nextInt();
		
		DrawingBoard board = new DrawingBoard(200, 100, 600, 400);
		Graphics g = board.getCanvas();
		board.clear();
		g.setColor(Color.BLACK);
		g.drawOval(x, y, r, r); 
		board.repaint();
	}
}
		*/
