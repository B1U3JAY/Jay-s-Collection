package jrJava.basicsOfGraphics;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;

import resources.DrawingBoard;

public class ColorChoosing {

	public static void main(String[] args) {
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose the color of the ball (Type in '1' for red, '2' for green, '3' for blue, '4' for yellow, and '5' for cyan):");
		n = sc.nextInt();
		DrawingBoard board = new DrawingBoard(200, 100, 600, 400);
		Graphics g = board.getCanvas();
		board.clear();
		if(n==1) {
			g.setColor(Color.RED);
			g.drawOval(100, 100, 100, 100); 
			g.fillOval(100, 100, 100, 100);
			board.repaint();
		}
		else if(n==2) {
			g.setColor(Color.GREEN);
			g.drawOval(100, 100, 100, 100); 
			g.fillOval(100, 100, 100, 100);
			board.repaint();
		}
		else if(n==3) {
			g.setColor(Color.BLUE);
			g.drawOval(100, 100, 100, 100); 
			g.fillOval(100, 100, 100, 100);
			board.repaint();
		}
		else if(n==4) {
			g.setColor(Color.YELLOW);
			g.drawOval(100, 100, 100, 100); 
			g.fillOval(100, 100, 100, 100);
			board.repaint();
		}
		else {
			g.setColor(Color.CYAN);
			g.drawOval(100, 100, 100, 100); 
			g.fillOval(100, 100, 100, 100);
			board.repaint();
		}
	}	
}