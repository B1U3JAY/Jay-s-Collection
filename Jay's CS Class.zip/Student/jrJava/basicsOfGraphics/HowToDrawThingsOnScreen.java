package jrJava.basicsOfGraphics;

import java.awt.Color;

import java.awt.Graphics;

import resources.DrawingBoard;

public class HowToDrawThingsOnScreen {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(200, 100, 600, 400);
		// Created a window (JFram/JPanel). We can position it and size it.
		Graphics g = board.getCanvas();
		// We need to access the drawing surface inside the window.
		// -----> board.getCanvas();
		// If you use this, the DrawingBoard will give us a Graphics "g". It is kind of like a tool such as a pen/brush.
		// Once we have this "g", we can use it again and again.
		
		board.clear(); // Clears the drawing surface.
		
		// Using the method "g", we can draw many things as we like.
		g.setColor(Color.RED);
		g.drawRect(150, 100, 200, 75); // (x, y, width, height);
		
		
		board.repaint(); // THIS IS IMPORTANT!!!!!
		// If you are ready and want to show all the things you drew in the surface on the screen, you need to call this "repaint()" method.
	}

}
