package jrJava.basicsOfGraphics;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class RobotFace {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard (100, 50, 1000, 1000);
		Graphics g = board.getCanvas();
		
		board.clear();
		
		g.setColor(Color.YELLOW);
		g.drawOval(100,  60, 500,  500);
		g.fillOval(100,  60, 500,  500);
		
		g.setColor(Color.RED);
		g.drawOval(200, 150, 300, 300);
		g.setColor(Color.YELLOW);
		g.fillOval(200, 100, 300, 300);
		
		g.setColor(Color.RED);
		g.drawOval(225, 150, 100, 100);
		g.drawOval(375, 150, 100, 100);
		g.drawRect(320, 270, 50, 50);
		
		
		// Arcs
		
		// Lines
		
		// Texts
		
		board.repaint();

	}

}
