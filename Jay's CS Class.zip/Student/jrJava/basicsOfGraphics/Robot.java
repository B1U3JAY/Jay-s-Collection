package jrJava.basicsOfGraphics;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class Robot {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard (100, 50, 1000, 1000);
		Graphics g = board.getCanvas();
		
		board.clear();
		
		g.setColor(Color.YELLOW);
		g.drawOval(375,  80, 100,  100);
		g.fillOval(375,  80, 100,  100);
		
		g.setColor(Color.BLUE);
		g.drawOval(400, 100, 23, 23);
		g.drawOval(430
				, 100, 23, 23);
		
		g.setColor(Color.YELLOW);
		g.fillRect(350, 180, 150, 200);
		g.setColor(Color.BLUE);
		g.drawRect(350, 180, 150, 200);
		
		g.setColor(Color.BLUE);
		g.fillRect(300, 180, 50, 200);
		g.fillRect(502, 180, 200, 50);
		
		g.setColor(Color.BLUE);
		g.fillRect(350, 380, 50, 175);
		g.fillRect(450, 380, 50, 175);
		
		g.setColor(Color.BLUE);
		g.fillRect(300, 550, 100, 20);
		g.fillRect(450, 550, 100, 20);
		/*
		g.setColor(Color.RED);
		g.drawRect(200, 150, 100, 200);
		g.drawRect(350, 150, 100, 200);
		g.drawRect(300, 270, 200, 50);
		g.drawRect(350, 270, 200, 50);
		*/
		
		// Arcs
		
		// Lines
		
		// Texts
		
		board.repaint();

	}

}