package jrJava.basicsOfGraphics;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class DrawingShapes {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard (100, 50, 1000, 1000);
		Graphics g = board.getCanvas();
		
		board.clear();
		
		g.setColor(Color.RED);
		g.drawRect(50, 50, 100, 200);
		
		g.setColor(Color.GREEN);
		g.drawOval(300,  70, 300,  100);
		
		g.setColor(Color.BLUE);
		g.drawArc(250, 300, 500, 200, 30, 120);

	}
}
