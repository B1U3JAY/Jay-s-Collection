package jrJava.basicsOfGraphics;

import java.awt.Color;

import java.awt.Graphics;

import resources.DrawingBoard;

public class DrawingThings {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard (100, 50, 900, 600);
		Graphics g = board.getCanvas();
		
		board.clear();
		
		g.setColor(Color.BLUE);
		g.drawRect(100,  60,  200,  200);
		g.fillRect(100,  300,  120,  240);
		
		g.setColor(Color.RED);
		g.drawRect(350, 60, 200, 150);
		g.fillRect(350, 300, 200, 200);
		g.drawOval(350, 60, 200, 150);
		g.fillOval(350, 300, 200, 200);
		
		// Arcs
		g.setColor(Color.CYAN);
		g.drawArc(600, 60, 200, 200, -90, 180);
		g.drawArc(600, 300, 200, 200, -150, 300);
		
		// Lines
		g.setColor(Color.BLACK);
		g.drawLine(300,  100,  800,  500);;
		g.drawLine(0,  0,  900,  600);;
		
		// Texts
		g.setColor(Color.CYAN);
		g.drawString("Hello there!",  280,  150);;
		String message = "I had a great lunch";
		g.drawString(message, 300, 450);
		
		board.repaint();

	}

}
