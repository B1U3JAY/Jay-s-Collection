package jrJava.basicsOfGraphics;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class DrawGraph {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard (100, 50, 1000, 1000);
		Graphics g = board.getCanvas();
		
		board.clear();
		
		g.setColor(Color.BLACK);
		g.drawLine(500, 50, 500, 550);
		
		g.setColor(Color.BLACK);
		g.drawLine(490, 60, 500, 50);
		g.setColor(Color.BLACK);
		g.drawLine(510, 60, 500, 50);
		
		g.setColor(Color.BLACK);
		g.drawLine(60, 300, 940, 300);
		
		g.setColor(Color.BLACK);
		g.drawLine(930, 290, 940, 300);
		g.setColor(Color.BLACK);
		g.drawLine(930, 310, 940, 300);
	}
}

