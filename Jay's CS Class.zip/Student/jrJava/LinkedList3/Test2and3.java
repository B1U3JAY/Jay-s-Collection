package jrJava.LinkedList3;

import java.util.Iterator;

public class Test2and3 {
	
	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.insert(5, 5.0);
		list.insert(3, 3.0);
		list.insert(1, 1.0);
		list.insert(4, 4.0);
		list.insert(7, 7.0);
		list.insert(6, 6.0);
		list.insert(2, 2.0);
		list.insert(8, 8.0);
		
		list.printAll();

		Iterator iter1 = new MyIterator(list);
		Iterator iter2 = new MyIterator(list);
		
		AdditionOp additionOp = new AdditionOp(iter1);
		RemovalOp removalOp = new RemovalOp(iter2, 3);
		
		// Iterate through each link seperately (in our case all the link nodes should be an added value of 100 and remove a link node with an id of 3):
		// AdditionOp additionOp = new AdditionOp(list);
		// RemovalOp removalOp = new RemovalOp(list, 3);
		
		for(int i=0; i<20; i++) {
			additionOp.process();
			removalOp.process();
		}
		
		list.printAll();
	}

}
