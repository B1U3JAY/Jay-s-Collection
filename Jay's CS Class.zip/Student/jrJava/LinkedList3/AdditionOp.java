package jrJava.LinkedList3;

import java.util.Iterator;

public class AdditionOp {
	private Iterator iter;
	
	public AdditionOp(Iterator iter) {
		this.iter = iter;
	}
	    
	public void process() {
		
		if(iter.hasNext()) {
			Link each = (Link)iter.next();
			each.value += 100;
		}
		
	}

}
