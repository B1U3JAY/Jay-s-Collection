package jrJava.alienInvader3;

import java.awt.Color;
import java.awt.Graphics;

public class Alien {
	
	static int width, height;
	static int eyeRadius;
	
	Color bodyColor, eyeColor;
	int x, y; // Bottom Center
	int vx, vy;
	Missile[] missiles; // to store multiple missile objects
	
	static { // allows to initialize static variables
		width = 25;
		height = 25;
		eyeRadius = 3;
	}
	
	public Alien() {
		
	}
	
	public Alien(int x, int y, Color bodyColor, Color eyeColor, int vx, int vy) {
		
		this.x = x;
		this.y = y;
		this.bodyColor = bodyColor;
		this.eyeColor = eyeColor;
		this.vx = vx;
		this.vy = vy;
		
		missiles = new Missile[10];
		
	}
	
	void move() {
		
		x += vx;
		y += vy;
		
		if(Math.random()>0.9) {
			for(int i=0; i<10; i++) {
				if(missiles[i]==null) { //If there is an unoccupied storage space, we create a new Missile object into the next available one. Once it is full, we 'break' and get out of the loop.
					missiles[i] = new Missile(x, y, 2*vy);
					break;
				}         
			}
		}
		
		for(int i=0; i<10; i++) {
			if(missiles[i]!=null) {
				missiles[i].move(); // This command line will execute the specific missile object's "move command"
			}
		}
		
	}
	
	void draw(Graphics g) {
		g.setColor(bodyColor);
		g.drawRect(x-width/2, y-height, width, height); // x moves left by half of the width's length and y goes up by height length
		
		g.setColor(eyeColor);
		g.drawOval(x-width/4-eyeRadius, y-3*height/4-eyeRadius, 2*eyeRadius, 2*eyeRadius); // From the left eye's center which is (x-width/4, y-3/4*height), we must remove eye radius to get the left-hand corner coordinate.
		g.drawOval(x+width/4-eyeRadius, y-3*height/4-eyeRadius, 2*eyeRadius, 2*eyeRadius); // Same from above, but for the right eye move it to the right
		
		for(int i=0; i<10; i++) {
			if(missiles[i]!=null) {
				missiles[i].draw(g); // This command line will execute the specific missile object's "draw command"
			}
		}
		
	}
	
}
