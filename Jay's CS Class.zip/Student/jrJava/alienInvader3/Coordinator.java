package jrJava.alienInvader3;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;
import resources.Timer;

public class Coordinator {

	public static void main(String[] args)        {
		
		DrawingBoard board = new DrawingBoard (200, 0, 600, 600);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		AlienMotherShip motherShip = new AlienMotherShip();
		
		while(true) {
			motherShip.move();
			
			board.clear();
			motherShip.draw(g);
			board.repaint();
			timer.pause(50);
		}
	}

}
