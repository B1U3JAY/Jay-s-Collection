package jrJava.inheritance8_usingProtected;

public class B extends A{
	
	public void m() {
		
		// System.out.println(f1);
		System.out.println(f2);
		System.out.println(f3);
		
		// m1();
		m2();
		m3();
		
	}

}
