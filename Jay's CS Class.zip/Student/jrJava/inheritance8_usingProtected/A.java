package jrJava.inheritance8_usingProtected;

public class A {
	
	private int f1 = 10;
	protected int f2 = 20;
	public  int f3 = 30;
			
	private void m1() {
		System.out.println("m1() method.");
	}
	
	protected void m2() {
		System.out.println("m2() method.");
	}
	
	public void m3() {
		System.out.println("m3() method.");
	}

}
