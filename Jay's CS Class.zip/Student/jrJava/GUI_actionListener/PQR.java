package jrJava.GUI_actionListener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PQR implements ActionListener{
	
	// field1
	// field2
	// field3
	// field4
	// field5
	// .....
	
	// method1(){ ..... }
	// method2(){ ..... }
	// method3(){ ..... }
	// method4(){ ..... }
	// method5(){ ..... }
	// .....
	
	public void actionPerformed(ActionEvent e) {
		// System.out.println(e.getActionCommand());
		
		System.out.println("I am inside PQR. I just got notified by the JButton." + e.getActionCommand());
		
		// Using the button # we receive, we can make if statements to control the flow of our code:
		
		if(e.getActionCommand()=="My Button1") { // We usually write 'if(e.getActionCommand().equals("My Button1") {.....}' instead.
			System.out.println("I just bought 5000 Google stocks.");
		}
		else if(e.getActionCommand()=="My Button2") { // We usually write 'if(e.getActionCommand().equals("My Button2") {.....}' instead.
			System.out.println("I just sold 5000 Google stocks");
		}
	}

}
