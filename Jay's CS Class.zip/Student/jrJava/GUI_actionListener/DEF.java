package jrJava.GUI_actionListener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DEF implements ActionListener{
	
	// field1
	// field2
	// field3
	// field4
	// field5
	// .....
	
	// method1(){ ..... }
	// method2(){ ..... }
	// method3(){ ..... }
	// method4(){ ..... }
	// method5(){ ..... }
	// .....
	
	public void actionPerformed(ActionEvent e) {
		System.out.println("I am inside DEF. I just got notified by the JButton.");
	}

}
