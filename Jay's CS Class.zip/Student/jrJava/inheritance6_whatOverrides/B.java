package jrJava.inheritance6_whatOverrides;

public class B extends A{

	public int f = 20;
	public static int fS = 200;
	
	public void m() {
		System.out.println("B's m() method.");
		
	}
	
	public static void mS() {
		System.out.println("B's mS() method.");
	}

}
