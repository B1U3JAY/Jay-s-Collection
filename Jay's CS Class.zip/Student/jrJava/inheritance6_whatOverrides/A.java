package jrJava.inheritance6_whatOverrides;

public class A {
	
	public int f = 10;
	public static int fS = 100;
	
	public void m() {
		System.out.println("A's m() method.");
		
	}
	
	public static void mS() {
		System.out.println("A's mS() method.");
	}

}
