package jrJava.inheritance6_whatOverrides;

public class Test {

	public static void main(String[] args) {
		
		A ref = new B();
		
		System.out.println(ref.f);
		System.out.println(ref.fS);
		
		ref.mS();
		ref.m();

	}

}
