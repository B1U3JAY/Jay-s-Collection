package jrJava.barbarianAttack3;

import java.awt.*;

import javax.swing.ImageIcon;

public class Arrow {
	
	private double x, y, vx, vy, length;
	private double gravity = 0.6; // Tunable.
	private static Image eImage;
	private static int eWidth, eHeight;
	private boolean isCollided;
	
	static {
		eImage = new ImageIcon(Coordinator.R_PATH + "explosion.png").getImage();
		eWidth = eImage.getWidth(null);
		eHeight = eImage.getHeight(null);
	}
	
	public Arrow(double x, double y, double vx, double vy, double length) {
		this.x = x;
		this.y = y;
		this.vx = vx;
		this.vy = vy;
		this.length = length;
	}
	
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public boolean isCollided() {
		return isCollided;
	}
	
	public void move() {
		for(int i=0; i<10; i++) {
			x += vx/10;
			y += vy/10;
			vy += gravity/10;
		
			// If collision occurs, break out:
			if(BarbarianManager.isHit(this)) {
				isCollided = true;
			}
			
			// If(x<100 || y>600) ArrowManager.remove(this); 
		}
	}
	
	public void draw(Graphics2D g) {
		g.setColor(Color.BLACK);
		double hyp = Math.sqrt(vx*vx + vy*vy);
		g.drawLine((int)x, (int)y, (int)(x + length*vx/hyp), (int)(y + length*vy/hyp));
		
		if(isCollided) {
			g.drawImage(eImage, (int)x-eWidth/2, (int)y-eHeight/2, null);
			// ArrowManager.remove(this); // Call this and it starts from the beginning of the LinkedList - so it's a bad idea!
		}
	}

}
