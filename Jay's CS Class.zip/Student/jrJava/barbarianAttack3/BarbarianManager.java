package jrJava.barbarianAttack3;

import java.awt.*;
import java.util.Iterator;

import javax.swing.ImageIcon;

public class BarbarianManager { // Similar to 'Arrow Manager'
	
	// private static MyArrayList<Barbarian> barbarians;
	private static LinkedList<Barbarian> barbarians;
	
	private static Image[][] imagePairs; // An array of two image pair(s) arrays
	
	static {
		// barbarians = new MyArrayList<Barbarian>();
		barbarians = new LinkedList<Barbarian>();
		
		imagePairs = new Image[6][];
		
		for(int i=0; i<imagePairs.length; i++) {
			imagePairs [i] = new Image[2]; // The size of the second array "inside" the first array
		}
		
		// Running Barbarians:
		imagePairs[0][0] = new ImageIcon(Coordinator.R_PATH + "barbarian_robot1_image1.png").getImage();
		imagePairs[0][1] = new ImageIcon(Coordinator.R_PATH + "barbarian_robot1_image2.png").getImage();
		imagePairs[1][0] = new ImageIcon(Coordinator.R_PATH + "barbarian_robot2_image1.png").getImage();
		imagePairs[1][1] = new ImageIcon(Coordinator.R_PATH + "barbarian_robot2_image2.png").getImage();
		imagePairs[2][0] = new ImageIcon(Coordinator.R_PATH + "barbarian_robot3_image1.png").getImage();
		imagePairs[2][1] = new ImageIcon(Coordinator.R_PATH + "barbarian_robot3_image2.png").getImage();
		imagePairs[3][0] = new ImageIcon(Coordinator.R_PATH + "barbarian_robot4_image1.png").getImage();
		imagePairs[3][1] = new ImageIcon(Coordinator.R_PATH + "barbarian_robot4_image2.png").getImage();
		
		// Flying Barbarians:
		imagePairs[4][0] = new ImageIcon(Coordinator.R_PATH + "dragon1_image1.png").getImage();
		imagePairs[4][1] = new ImageIcon(Coordinator.R_PATH + "dragon1_image2.png").getImage();
		imagePairs[5][0] = new ImageIcon(Coordinator.R_PATH + "dragon2_image1.png").getImage();
		imagePairs[5][1] = new ImageIcon(Coordinator.R_PATH + "dragon2_image2.png").getImage();
	}
	
	private static void launchBarbarian() { // Create Barbarain Object(s)
		if(Math.random()>0.05) {
			return;
		}
		
		if(Math.random()>0.3) {
			barbarians.insert(new RunningBarbarian(imagePairs[(int)(Math.random()*4)], // Randomly we need to generate the number 1, 2, or 3 for Running Barbarians
					-imagePairs[0][0].getWidth(null), 600, (int)(Math.random()*3)+1)); // Random number from at least 3 to at most 7.
		}
		else {
			barbarians.insert(new FlyingBarbarian(imagePairs[(int)(Math.random()*2+4)], // Randomly we need to generate the number 4 or 5 for Flying (Dragon) Barbarians
					-imagePairs[4][0].getWidth(null), 100+(int)(Math.random()*400), (int)(Math.random()*3+2), 50)); // Random number from at least 100 to at most 500 and random number from at least 5 to at most 12.
		}
		
		// new RunningBarbarian(Image[] images, x, y, vx);
		// new FlyingBarbarian(Image[] images, x, y, vx, flySpan);
	}
	
	public static void move() {
		launchBarbarian();
		
		Iterator<Barbarian> iter = barbarians.iterator();
		
		while(iter.hasNext()) {
			iter.next().move();
		}
		
		/*
		for(int i=0; i<barbarians.size(); i++) {
			barbarians.get(i).move();
		}
		*/
	}
	
	public static void draw(Graphics2D g) {
		Iterator<Barbarian> iter = barbarians.iterator();
		
		while(iter.hasNext()) {
			iter.next().draw(g);
		}
	}
	
	public static boolean isHit(Arrow arrow) {
		Iterator<Barbarian> iter = barbarians.iterator();
		
		while(iter.hasNext()) {
			if(iter.next().isHit(arrow)){
				iter.remove();
				return true;
			}
		}
		
		return false;
	}
	
}
