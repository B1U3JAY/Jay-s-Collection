package jrJava.flowControl7_moreMethodPractice;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;
import resources.Timer;

public class Method_Design_Practice2 {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(0, 0, 2000, 820);
		Graphics g = board.getCanvas();
		
		drawGrids(g, Color.BLACK, 25, 25, 20, 25);
	}
	
	public static void drawGrids(Graphics g, Color color, int x, int y, int increment, int numberOfLines) {
		
		int i;
		int x1 = x;
		int y1 = y;
		int x2 = x;
		int y2 = y+increment*(numberOfLines-1);
		for(i=1; i<=numberOfLines; i++) {
			
			g.setColor(color);
			g.drawLine(x1, y1, x2, y2);
			
			x1 += increment;
			x2 += increment;
			
		}
		x1 = x;
		y1 = y;
		x2 = x+increment*(numberOfLines-1);
		y2 = y;
		for(i=1; i<=numberOfLines; i++) {
			
			g.setColor(color); 
			g.drawLine(x1, y1, x2, y2);
		  
			y1 += increment; 
			y2 += increment;
		  
		}
	
	}

}

/*
	public static void drawPacman(DrawingBoard board, Graphics g, Color color, int radius, int angle, int xC, int yC) {
		
		board.clear();
		g.setColor(color);
		g.fillOval(xC-radius, yC-radius, 2*radius, 2*radius);
		board.repaint();
		g.setColor(Color.BLACK);
		g.fillOval(xC, yC-(radius/2), 2*radius/6, 2*radius/6);
		board.repaint();
		g.setColor(Color.WHITE);
		g.fillArc(xC-radius, yC-radius, 2*radius, 2*radius, 160, 25);
		board.repaint();
		
	}

}
*/
