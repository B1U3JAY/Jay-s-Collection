package jrJava.flowControl7_moreMethodPractice;

import java.awt.Color;

import java.awt.Graphics;

import resources.DrawingBoard;

public class Method_drawTriangle {

	public static void main(String[] args) {
		DrawingBoard board = new DrawingBoard(0, 0, 700, 700);
		Graphics g = board.getCanvas();
		Color color = new Color (0, 120, 150);
		drawTriangle(g, color, 100, 100, 200, 200, 230, 300);
		
	}
	
	
	
	static void drawTriangle(Graphics g, Color color, int x1, int y1, int x2, int y2, int x3, int y3) {
		g.setColor(color);
		g.drawLine(x1, y1, x2, y2);
		g.drawLine(x2, y2, x3, y3);
		g.drawLine(x3, y3, x1, y1);
	}
}
