package jrJava.flowControl7_moreMethodPractice;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;
import resources.Timer;

public class Practice4 {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(0, 0, 600, 600);
		Timer timer = new Timer();
		
		moveCircle(board, timer, Color.GREEN, 80, 0, 0, 600, 600);
		moveCircle(board, timer, Color.GREEN, 80, 600, 600, -50, 300);
		moveCircle(board, timer, Color.GREEN, 80, -50, 300, 500, -100);
		moveCircle(board, timer, Color.GREEN, 80, 500, -100, 300, 300);

	}
	
	public static void moveCircle(DrawingBoard board, Timer timer, Color color, int radius, int x1, int y1, int x2, int y2) {
		
		Graphics g = board.getCanvas();
		int xC; // changing center coordinate
		int yC; // of the moving circle.
		
		int i;
		for(i=1; i<=100; i++) {
			
			xC = x1 + (x2-x1)*i/100;
			yC = y1 + (y2-y1)*i/100;
			
			board.clear();
			g.setColor(color);
			g.fillOval(xC-radius, yC-radius, 2*radius, 2*radius);
			board.repaint();
			timer.pause(10);
		}
		
	}
	
}
