package jrJava.flowControl7_moreMethodPractice;

import java.util.Scanner;

public class Practice3 {

	public static void main(String[] args) {
		
		System.out.println(2*calculateSumInteractively() + 3*calculateSumInteractively());

	}
	
	public static double calculateSumInteractively(){
		double sum = 0.0;
		Scanner scanner = new Scanner(System.in);
		double entered = 0.0;
		
		System.out.println("Enter a number (If you would like to stop the program, type in '-1'):");
		entered = scanner.nextDouble();
		
		while(entered!=-1) {
			sum += entered;
			System.out.println("Enter a number (If you would like to stop the program, type in '-1'):");
			entered = scanner.nextDouble();
		}
		
		return sum;
	}
	
}
