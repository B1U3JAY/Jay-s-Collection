package jrJava.imageManipulation4;

import java.awt.*;

import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyDrawingBoard extends JPanel{
	
	public JFrame frame;
	private BufferedImage bImage;
	private Graphics bufferedG;
	
	public MyDrawingBoard(int x, int y, int w, int h) {
		frame = new JFrame("DrawingBoard");
		frame.setBounds(x, y, 0, 0); // Width and Height of JPanel will be fixed
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setPreferredSize(new Dimension(w, h));
		frame.add(this);
		frame.pack(); // JFrame will calculate the dimension to fit the dimensions given/wanted
		frame.setVisible(true);
		
		bImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB); // Created another set of utilizable pixels so that the user can draw on this and not on the "hardware graphics (g)" which is used in the 'paintComponent' method below.
		bufferedG = bImage.getGraphics();
	
		((Graphics2D)bufferedG).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	}
	
	public Graphics getBufferedG() {
		return bufferedG;
	}
	
	public void clear() {
		bufferedG.setColor(Color.WHITE);
		bufferedG.fillRect(0, 0, getWidth(), getHeight());
		
		/* Same Thing:
		int i, j;
		for(i=0; i<getWidth(); i++) {
			for(j=0; j<getHeight(); j++) {
				bImage.setRGB(i, j, 0xffffffff);
			}
		}
		*/
	}
	
	public void paintComponent(Graphics g) {
		g.drawImage(bImage, 0, 0, this);
	}

}
