package jrJava.flowControls10_branchingStatements;

public class UsingContinueStatement {

	public static void main(String[] args) {
		
		int sum = 0;
		int i;
		for(i=1; i<=1000; i++) {
			
			if(i%10!=9) {
				sum += i;
			}
			
		}
		
		System.out.println(sum);

	}

}
