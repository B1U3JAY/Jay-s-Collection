package jrJava.flowControls10_branchingStatements;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class UsingContinueStatement2 {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(100, 100, 180, 180);
		Graphics g = board.getCanvas();
		int size = 20;
		int margin = 0;
		
		int i;
		int j;
		
		for(i=1; i<=9; i++) {
			for(j=1; j<=9; j++) {
				
				if(i==j) {
					continue;
				}
				
				if(10-i==j) {
					continue;
				}
				
				g.setColor(Color.GREEN);
				g.fillRect(margin+(i-1)*size,  margin + (j-1)*size, size, size);
				g.setColor(Color.BLACK);
				g.drawRect(margin+(i-1)*size,  margin + (j-1)*size, size, size);
				
			}
		}
		board.repaint();
	}

}
