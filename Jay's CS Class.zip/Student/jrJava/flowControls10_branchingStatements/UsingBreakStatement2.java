package jrJava.flowControls10_branchingStatements;

import java.util.Scanner;

public class UsingBreakStatement2 {

	public static void main(String[] args) {
		
		double sum = 0.0;
		double average;
		int numberOfData = 0;
		
		Scanner scanner = new Scanner(System.in);
		double entered;
		
		while(true) {
			System.out.println("Enter a number. (To stop, enter a negative number)");
			entered = scanner.nextDouble();
			
			if(entered<0) {
				break;
			}
			
			sum += entered;
			numberOfData++;
			
		}
		
		average = sum/numberOfData;
		System.out.println("Sum:" + sum + ", average:" + average);

	}

}
