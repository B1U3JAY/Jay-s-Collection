package jrJava.flowControls10_branchingStatements;

public class UsingReturnStatement {

	public static void main(String[] args) {
		
		

	}
	
	public static int max(int v1, int v2) {
		
		if(v1>=v2) {
			return v1;
		}
		
		else {
			return v2;
		}
		
	}
}
