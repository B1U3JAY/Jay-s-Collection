package jrJava.flowControls10_branchingStatements;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class UsingBreakStatement3 {

	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(200, 100, 500, 500);
		Graphics g = board.getCanvas();
		int size = 30;
		int margin = 100;
		
		int i;
		int j;
		boolean shouldBreak = false;
		
		for(i=1; i<=10; i++) {
			for(j=1; j<=10; j++) {
				
				g.setColor(Color.GREEN);
				g.fillRect(margin+(i-1)*size,  margin + (j-1)*size, size, size);
				g.setColor(Color.BLACK);
				g.drawRect(margin+(i-1)*size,  margin + (j-1)*size, size, size);
				
				if(j==5) {
					shouldBreak = true;
					
					break;
				}
			}
			// If you want to get out of both loop structures, then .....
			if(shouldBreak == true) {
				break;
			}
		}
		board.repaint();
	}
	
	public static int getAbsolute(int a) {	
		if(a>=0) {
			return a;
		}
		if(a<0) {
			return -a;
		}
		return a;
	}
	
}
