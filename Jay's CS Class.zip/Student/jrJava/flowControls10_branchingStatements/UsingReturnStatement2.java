package jrJava.flowControls10_branchingStatements;

public class UsingReturnStatement2 {

	public static void main(String[] args) {
		
		printSum(15);

	}
	
	public static void printSum(int n) {
		
		int sum = 0;
		int i;
		for(i=1; i<=n; i++) {
			sum += i*i*i;
			
			if(sum>=10000) {
				System.out.println("i=" + i + ", sum=" + sum);
				break;
			}
			
		}
		
		System.out.println(sum);
		return;
		
	}

}
