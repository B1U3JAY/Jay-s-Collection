package jrJava.abstractType_generics1;

public class Storage1 {
	
	private String data;
	
	public void setData(String data) {
		this.data = data;
	}
	
	public String getData() {
		return data;
	}

}
