package jrJava.abstractType_generics1;

public class Test2 {

	public static void main(String[] args) {
		
		Storage2 storage = new Storage2();
		
		storage.setData(123); // These integer values will go through the process of going through a Integer Wrapper Class so that it can be represented as a String-like object
		Integer data = storage.getData();
		// storage.setData("123"); // This will not work because it need to be an Integer type.
		// String data = storage.getData(); // If it tries to get a String 'type' it will be a type mismatch resulting in a failure
		System.out.println(data.intValue());

	}

}
