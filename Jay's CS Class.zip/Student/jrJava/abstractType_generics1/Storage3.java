package jrJava.abstractType_generics1;

// * Generic Types' purpose is to allow any object or object type to be accepted:

public class Storage3 {
	
	private Object data;
	
	public void setData(Object data) { // Like this for example (because it is technically "upcasting" from whatever Object is being inputed).
		this.data = data;
	}
	
	public Object getData() { // However, here we must "downcast" it in order to return the specifc Object type that you want:
		return data;
	}

}
