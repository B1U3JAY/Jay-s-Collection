package jrJava.abstractType_generics1;

public class Test1 {
	
	public static void main(String[] args) {
		
		Storage1 storage = new Storage1();
		
		// storage.setData("abc");
		// storage.setData(123); // '123' is a integer trying to go through a String parameter (will go through as a Integer Wrapper Class Object).
		String ref = storage.getData();
		
		System.out.println(ref.charAt(0));
		
	}

}
