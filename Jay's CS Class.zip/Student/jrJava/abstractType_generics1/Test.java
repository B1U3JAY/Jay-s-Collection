package jrJava.abstractType_generics1;

public class Test {

	public static void main(String[] args) {
		
		// Storage<> storage = new Storage<>(); // Whatever data type you intend to use, you put the type in between the brackets. For Example:
		
		Storage<String> storage = new Storage<String>(); // During compile time, it will check the 'type' coming in/leaving.
		
		storage.setData("123");
		// storage.setData(123); // Right now, we made for all types to be 'String' at the moment.
		
		String data = storage.getData();
		// Integer data = storage.getData(): // Same thing here.
		
		Storage<Integer> storage2 = new Storage<Integer>(); // Now we want to use the data structure for processing 'Integer' data type (including what it returns):
		
		// So now if someone tried to use/return 'String', it wouldn't work:
		
		// storage2.setData("456");
		storage2.setData(456);
		
		// String data2 = storage2.getData();
		Integer data2 = storage2.getData();

	}

}
