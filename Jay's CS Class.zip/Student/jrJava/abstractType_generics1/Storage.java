package jrJava.abstractType_generics1;

// * Overall, by using generics, programmercs can implement generic algorithms that work on collections of different types that can be customized and are "type safe" and easier to read.
// Basically it will allow you take catch these 'type' checking errors far earlier in your programming:

public class Storage<E> { // "Angle Brackets" or "< >" will indicate a "type parameter". In this case we are vaguely indicating the type by stating the type as something like 'E'.
	
	private E data; // Know whatever type we use, it will be this kind of storage type ('E' type).
	
	public void setData(E data) {
		this.data = data;
	}
	
	public E getData() {
		return data; // Returns an 'E' type 'data'.
	}

}
