package jrJava.abstractType_generics1;

public class Storage2 {
	
	private Integer data;
	
	public void setData(Integer data) { // "Integer Wrapper Class"
		this.data = data;
	}
	
	public Integer getData() { // It is an "Integer" return type
		return data;
	}

}
