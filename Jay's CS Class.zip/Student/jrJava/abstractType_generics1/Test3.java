package jrJava.abstractType_generics1;

public class Test3 {

	public static void main(String[] args) {
		
		Storage3 storage = new Storage3();
		
		// storage.setData("123"); // "Upcasting" = true
		// storage.setData(123); // This will also work ("autoboxing" will happen; converts to Wrapper Class Object). However retrieving it means we must "downcast" the type in order to get the one we want, but during the runtime there may be a problem because a "Wrapper Class Object" can't be downcasted into a "String" (Class Cast Exception).
		String ref = (String) storage.getData(); // Here we are tyring to get the subtype of 'String' for the 'ref' which we must "downcast"

	}

}
