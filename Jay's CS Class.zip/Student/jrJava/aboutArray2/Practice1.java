package jrJava.aboutArray2;

import java.awt.Color;

import jrJava.AlienInvader1.Missile;

public class Practice1 {

	public static void main(String[] args) {
		
		// Initializing Arrays:
		
		// 1.
		int[] a = {7, 5, 11, -6, 10}; // This is fine if you initialize everything in the SAME LINE
		
		// 2.
		int[] b = new int[] {7, 5, 11, -6, 10}; // When you need to split the initialization into TWO OR MORe SEPERATE LINESS, you must use this.
		
		// Even though they function the same and number 2 is longer, sometimes we have to choose option 2 because of a "Java Compiler Issue".
		// Sometimes Java needs to know what kind of array it is (integer, double, object, boolean, etc.)
		// So if you separate the initialization into two lines, Java will not accept it. That is why "new int[]" is a good idea.
		
		// For example:
		
		int[] a1 = new int[] {7, 5, 11, -6, 10};
		
		// int[] a2;
		// a2 = {7, 5, 11, -6, 10}; // As you can see, it won't work.
		
		int[] b2;
		b2 = new int[] {7, 5, 11, -6, 10}; // No problem!
		
		double[] values1 = {2.1, 3.14, 2.71, 6.78, 0.01, -4.44}; 
		
		double[] values2;
		values2 = new double[] {2.1, 3.14, 2.71, 6.78, 0.01, -4.44};
		
		Color[] color1 = {Color.RED, Color.GREEN, new Color(100, 120, 77)};
		Color[] color2;
		color2 = new Color[]{Color.RED, Color.GREEN, new Color(100, 120, 77)};
		
		Missile[] missiles1 = {new Missile(110, 220, 20), new Missile(170, 270, 17), new Missile(150, 79, 7), new Missile(90, 50, 5)};
		
		Missile[] missiles2; 
		missiles2 = new Missile[] {new Missile(110, 220, 20), new Missile(170, 270, 17), new Missile(150, 79, 7), new Missile(90, 50, 5)};
		
		String[] names = { "John", "Tom", "sally", "Mary", "Justin" };
		
	}

}
