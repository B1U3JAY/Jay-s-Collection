package jrJava.homework4;

import java.awt.Color;

import java.awt.Font;

import java.awt.Graphics2D; import resources.DrawingBoard;

public class SchoolWork {

	public static void main(String[] args){
		DrawingBoard board = new DrawingBoard(0, 0, 800, 500); 
		Graphics2D g = board.getCanvas();
		
		g.setColor(Color.GREEN); 
		g.drawOval(140, 100, 350, 350);
		
		g.setFont(new Font("Times", Font.BOLD, 40)); 
		g.setColor(Color.CYAN);
		g.drawString("Good afternoon!", 160, 280);
		board.repaint(); 
		
	}
}