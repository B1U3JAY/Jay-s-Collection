package jrJava.barbarianAttack2;

public class MathUtility {
	
	public static void translate(Point[] points, Point ref) { // Translate from starting/standard point to where we want it to go:
		for(int i=0; i<points.length; i++) {
			points[i].x += ref.x;
			points[i].y += ref.y;
		}
	}
	
	/*
	public static Point scaleAndRotate(Point point, Point ref, double scale, double angle) { // We use angle so that the x position of the point is 'radius*cos(theta)' and so that the y position of the point is 'radius*sin(theta)':
		// Since our destination point's 'x' is 'radius*cos(theta+angle)' you can simplify and get that the x position of the original point * cos(theta) - y position of the original point * sin(theta). (This is true for the destination point's 'y' as well but '+' instead of '-').
		
		double x1 = point.x - ref.x; // Or 'r*cos(theta)'
		double y1 = point.y - ref.y; // Or 'r*sin(theta)'
		
		// Now we get our new position:
		
		double x2 = x1*Math.cos(angle) - y1*Math.sin(angle);
		double y2 = x1*Math.cos(angle) + y1*Math.sin(angle);
		
		// Now we return our position (with the given user's scale):
		
		return new Point(scale*x2 + ref.x, scale*y2 + ref.y);
		
	}
	*/
	
	public static void scaleAndRotate(Point point, Point ref, double scale, double angle) { // We use angle so that the x position of the point is 'radius*cos(theta)' and so that the y position of the point is 'radius*sin(theta)':
		// Since our destination point's 'x' is 'radius*cos(theta+angle)' you can simplify and get that the x position of the original point * cos(theta) - y position of the original point * sin(theta). (This is true for the destination point's 'y' as well but '+' instead of '-').
		
		double x1 = point.x - ref.x; // Or 'r*cos(theta)'
		double y1 = point.y - ref.y; // Or 'r*sin(theta)'
		
		// Now we get our new position:
		
		double x2 = x1*Math.cos(angle) - y1*Math.sin(angle);
		double y2 = x1*Math.cos(angle) + y1*Math.sin(angle);
		
		// Now we return our position (with the given user's scale):
		
		point.x = scale*x2 + ref.x;
		point.y = scale*y2 + ref.y;
		
	}

}
