package jrJava.flowControl_1_if;

import java.util.Scanner;

public class AreaComparison {

	public static void main(String[] args) {
		
		double r;
		double w;
		double h;
		double difference;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What is the radius of the circle? ");
		r = sc.nextDouble();
		System.out.println("What is the width of the rectangle? ");
		w = sc.nextDouble();
		System.out.println("What is the height of the rectangle? ");
		h = sc.nextDouble();
		if(Math.PI*r*r>w*h) {
			difference = Math.PI*r*r - w*h;
			System.out.println("The circle is bigger by " + difference + " unit squared.");
		}
		if (w*h>Math.PI*r*r) { 
			difference = w*h - Math.PI*r*r;
			System.out.println("The rectangle is bigger by " + difference + " unit squared.");
		}
		if (Math.PI*r*r==w*h) {
			System.out.println("The circle and rectangle have the same/similar areas.");
		}
	}
}