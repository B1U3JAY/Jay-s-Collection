package jrJava.flowControl_1_if;

import java.util.Scanner;

public class NestingBlockStructure {

	public static void main(String[] args) {
		
		double x;
		double y;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Think of a point in a x,y-coordinate plane");
		System.out.println("What is the x-value?");
		x = scanner.nextDouble();
		System.out.println("What is the y-value?");
		y = scanner.nextDouble();
		
		if(x>=0) {
			// Point must either be in Quadrant 1 or Quadrant 4
			if(y>=0) {
				System.out.println("Your point is in Quadrant 1");
			}
			else {
				System.out.println("Your point is in Quadrant 4");
			}
		}
		else {
			// Otherwise, must either be in Quadrant 2 or Quadrant 3
			if(y>=0) {
				System.out.println("Your point is in Quadrant 2");
			}
			else {
				System.out.println("Your point is in Quadrant 3");
			}
		}
	}

}
