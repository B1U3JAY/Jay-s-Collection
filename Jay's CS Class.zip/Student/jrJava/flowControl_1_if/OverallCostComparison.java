package jrJava.flowControl_1_if;

import java.util.Scanner;

public class OverallCostComparison {

	public static void main(String[] args) {
		
		double priceOfPencil;
		double priceOfPen;
		int numOfPencil;
		int numOfPen;
		double difference;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What is the price of the pencil? ");
		priceOfPencil = sc.nextDouble();
		System.out.println("How many pencils are you going to buy? ");
		numOfPencil = sc.nextInt();
		System.out.println("What is the price of the pen? ");
		priceOfPen = sc.nextDouble();
		System.out.println("How many pens are you going to buy? ");
		numOfPen = sc.nextInt();
		
		if(priceOfPencil*numOfPencil>priceOfPen*numOfPen) {
			difference = priceOfPencil*numOfPencil - priceOfPen*numOfPen;
			System.out.println("The pencil costs $" + difference + " more than the pens.");
		}
		else { 
			difference = priceOfPen*numOfPen - priceOfPencil*numOfPencil;
			System.out.println("The pen costs $" + difference + " more than the pencils.");
		}
		sc.close();
	}
}

