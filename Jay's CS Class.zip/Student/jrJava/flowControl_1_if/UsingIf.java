package jrJava.flowControl_1_if;

import java.util.Scanner;

public class UsingIf {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		int quantity1;
		int quantity2;
		
		System.out.println("Type in an integer: ");
		quantity1 = scanner.nextInt();
		
		System.out.println("Type in another integer: ");
		quantity2 = scanner.nextInt();
		
		if(quantity1>quantity2) {
			System.out.println("The first one is greater than the second one.");
		}
		
		System.out.println("Done! ");
		scanner.close();
	}

}
