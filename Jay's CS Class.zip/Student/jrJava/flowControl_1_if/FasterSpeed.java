package jrJava.flowControl_1_if;

import java.util.Scanner;

public class FasterSpeed {

	public static void main(String[] args) {
		
		double d1;
		double t1;
		double d2;
		double t2;
		double difference;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What is your distance in miles? ");
		d1 = sc.nextDouble();
		System.out.println("What is your time in hours? ");
		t1 = sc.nextDouble();
		double s1 = d1/t1;
		System.out.println("What is your friend's distance in miles? ");
		d2 = sc.nextDouble();
		System.out.println("What is your friend's time in hours?");
		t2 = sc.nextDouble();
		double s2 = d2/t2;
		if(s1>s2) {
			difference = s1 - s2;
			System.out.println("You are faster by " + difference + " mph.");
		}
		if (s2>s1) { 
			difference = s2 - s1;
			System.out.println("Your friend is faster by " + difference + " mph.");
		}
		if (s1==s2) {
			System.out.println("You both have the same speed.");
		}
	}
}