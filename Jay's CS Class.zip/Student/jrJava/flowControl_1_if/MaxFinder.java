package jrJava.flowControl_1_if;

import java.util.Scanner;

public class MaxFinder {

	public static void main(String[] args) {
		
		double d1;
		double d2;
		double d3;
		double d4;
		double LargestN = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What is your first decimal number? ");
		d1 = sc.nextDouble();
		System.out.println("What is your second decimal number? ");
		d2 = sc.nextDouble();
		System.out.println("What is your third decimal number? ");
		d3 = sc.nextDouble();
		System.out.println("What is your fourth decimal number? ");
		d4 = sc.nextDouble();	
		if(d1>LargestN) {
			LargestN = d1;
		}
		if(d2>LargestN) { 
			LargestN = d2;
		}
		if(d3>LargestN) {
			LargestN = d3;
		}
		if(d4>LargestN) {
			LargestN = d4;
		}
		System.out.println (LargestN + " is the greatest decimal number.");
		sc.close();
	}
}
