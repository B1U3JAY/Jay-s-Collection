package jrJava.flowControl_1_if;

import java.util.Scanner;

public class FastestSpeed {

	public static void main(String[] args) {
		
		double d1;
		double t1;
		double d2;
		double t2;
		double d3;
		double t3;
		double FastestSpeed = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What is the first person's distance in miles? ");
		d1 = sc.nextDouble();
		System.out.println("What is the first person's time in minutes? ");
		t1 = sc.nextDouble();
		double s1 = d1/t1;
		System.out.println("What is the second person's distance in miles? ");
		d2 = sc.nextDouble();
		System.out.println("What is the second person's time in minutes? ");
		t2 = sc.nextDouble();
		double s2 = d2/t2;
		System.out.println("What is the third person's distance in miles? ");
		d3 = sc.nextDouble();
		System.out.println("What is the third person's time in minutes? ");
		t3 = sc.nextDouble();
		double s3 = d3/t3;
		if(s1>FastestSpeed) {
			FastestSpeed = s1;
		}
		if (s2>FastestSpeed) { 
			FastestSpeed = s2;
		}
		if (s3>FastestSpeed) {
			FastestSpeed = s3;
		}
		System.out.println("The fastest speed is " + FastestSpeed + " miles per minute.");
		sc.close();
	}
}