package jrJava.flowControl_1_if;

import java.util.Scanner;

public class UsingElseIf {

	public static void main(String[] args) {
		
		int score;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What was your math test score?");
		score = sc.nextInt();
		
		if(score>=95) {
			System.out.println("Excellent! We are very proud of you!");		
		}
		else if(score>=90) {
			System.out.println("Very good! Howver, you can do better!");
		}
		else if(score>=80) {
			System.out.println("That's okay. Keep trying!");		;
		}
		else if(score>=70) {
			System.out.println("Oh no! Do you need help with anything?");		
		}
		else if(score>=60) {
			System.out.println("That's not good! You need to do better!");		
		}
	}

}
