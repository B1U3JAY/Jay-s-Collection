package jrJava.flowControl_1_if;

import java.util.Scanner;

public class UsingIfElse_5 {

	public static void main(String[] args) {
		

		double allowance;
		Scanner sc = new Scanner(System.in);
		
		System.out.println( "How much is your current allowance?");
		allowance = sc.nextDouble();
		
		if(allowance>=20) {
			allowance -= 10;
		}
		
		if(allowance<20) {
			allowance += 10;
		}
		System.out.println("Now, your updated allowance is $" + allowance + ".");
		sc.close();
	}

}