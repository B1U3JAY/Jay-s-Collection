package jrJava.flowControl_1_if;

import java.util.Scanner;

public class Sports {
	
	public static void main(String[] args) {
		
		double Answer;
		double Answer2 = 0;
		double Answer3 = 0;
		double t2;
		double d3;
		double t3;
		double FastestSpeed = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Do you prefer indoor sports(1) or outdoor sports(2)? ");
		Answer = sc.nextDouble();
		if (Answer==1) {
			System.out.println("Do you prefer basketball(1) or ping-pong(2)?");
			Answer2 = sc.nextDouble();
			if (Answer2==1) {
				System.out.println("Meet in the gym at 10:00.");
			}
			else if (Answer2==2) {
				System.out.println("Meet in the gym at 11:00.");
			}
		}
		if (Answer==2) {
			System.out.println("Do you prefer soccer(1) or football(2)?");
			Answer3 = sc.nextDouble();
			if (Answer3==1) {
				System.out.println("Meet in the gym at 1:00.");
			}
			if (Answer3==2) {
				System.out.println("Meet in the gym at 2:00.");
			}
		}
		sc.close();
	}
}

