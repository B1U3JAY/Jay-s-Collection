package jrJava.flowControl_1_if;

import java.util.Scanner;

public class RobinHood {

	public static void main(String[] args) {
		
		double UserMoney;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("How much money do you have? ");
		UserMoney = sc.nextDouble();
		if(UserMoney>=100) {
			UserMoney = UserMoney/2;
		}
		else { 
			UserMoney = UserMoney*2;
		}
		System.out.println("You now have $" + UserMoney + ".");
		sc.close();
	}
}