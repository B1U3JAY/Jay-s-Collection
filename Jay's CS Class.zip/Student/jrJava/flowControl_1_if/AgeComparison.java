package jrJava.flowControl_1_if;

import java.util.Scanner;

public class AgeComparison {

	public static void main(String[] args) {
		
		double allowance = 20.0;
		int yourAge;
		int friendAge;
		int difference;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("How old are you? Please enter your age: ");
		yourAge = sc.nextInt();
		System.out.println("How old is your friend? Please enter the age: ");
		friendAge = sc.nextInt();
		
		if(yourAge>friendAge) {
			difference = yourAge - friendAge; // allowance = allowance + 10;
			System.out.println("You are older by " + difference + " year(s).");
		}
		else { // Try not to use "if" "if" statements. Use "if" "else" statements!
			difference = friendAge - yourAge; // allowance = allowance - 10;
			System.out.println("Your friend is older by " + difference + " year(s).");
		}
		sc.close();
	}
}
