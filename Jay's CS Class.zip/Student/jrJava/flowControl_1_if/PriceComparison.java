package jrJava.flowControl_1_if;

import java.util.Scanner;

public class PriceComparison {
		public static void main(String[] args) {
			double priceOfPencil;
			double priceOfPen;
			double difference;
			Scanner sc = new Scanner(System.in);
			
			System.out.println("What is the price of the pencil? ");
			priceOfPencil = sc.nextDouble();
			System.out.println("What is the price of the pen? ");
			priceOfPen = sc.nextDouble();
			
			if(priceOfPencil>priceOfPen) {
				difference = priceOfPencil - priceOfPen;
				System.out.println("The pencil costs $" + difference + " more than the pen.");
			}
			else { 
				difference = priceOfPen - priceOfPencil; 
				System.out.println("The pen costs $" + difference + " more than the pencil.");
			}
			sc.close();
		}
	}