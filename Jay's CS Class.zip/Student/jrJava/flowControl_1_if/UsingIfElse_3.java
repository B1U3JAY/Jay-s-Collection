package jrJava.flowControl_1_if;

import java.util.Scanner;

public class UsingIfElse_3 {

	public static void main(String[] args) {
		
		double allowance = 20.0;
		int age;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("How old are you? Please enter your age: ");
		age = sc.nextInt();
		
		if(age>=14) {
			allowance += 10; // allowance = allowance + 10;
			System.out.println("Lucky you! You earned 10 more dollars!");
		}
		else { // Try not to use "if" "if" statements. Use "if" "else" statements!
			allowance -= 10; // allowance = allowance - 10;
			System.out.println("Sorry! We will take 10 dollars off of you!");
		}
		
		System.out.println("Now, your allowance is $" + allowance + ".");
	}

}
