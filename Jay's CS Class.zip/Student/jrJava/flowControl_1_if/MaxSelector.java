package jrJava.flowControl_1_if;

import java.util.Scanner;

public class MaxSelector {

	public static void main(String[] args) {
		
		double decimal1;
		double decimal2;
		double difference;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What is your first decimal number? ");
		decimal1 = sc.nextDouble();
		System.out.println("What is your second decimal number? ");
		decimal2 = sc.nextDouble();
		if(decimal1>decimal2) {
			System.out.println(decimal1 + " is greater.");
		}
		if(decimal2>decimal1) { 
			System.out.println(decimal2 + " is greater");
		}
		if(decimal1==decimal2) {
			System.out.println("Both numbers are equal.");
		}
		sc.close();
	}
}
