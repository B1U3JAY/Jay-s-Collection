package jrJava.GUI_custom_component;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class MyButton extends JButton{
	
	private Image orange1, orange2;
	private Image blue1, blue2;
	private String text;
	
	public MyButton(String text) {
		this.text = text;
		
		orange1 = new ImageIcon("jrJava/GUI_custom_component/orangeAlien_1.png").getImage();
		orange2 = new ImageIcon("jrJava/GUI_custom_component/orangeAlien_2.png").getImage();
		blue1 = new ImageIcon("jrJava/GUI_custom_component/blueAlien_1.png").getImage();
		blue2 = new ImageIcon("jrJava/GUI_custom_component/blueAlien_2.png").getImage();
		
		setRolloverEnabled(true); // For Mac users only, because the creators forgot to turn on this feature for Mac. Window users do not need to do this!
	}
	
	public void paintComponent(Graphics g) {
		Color bgColor = Color.WHITE;
		Image image1 = orange1;
		Image image2 = blue1;
		String label = text;
		
		if(getModel().isRollover()) { // If mouse detects the button it is hovering above.....
			bgColor = Color.YELLOW;
			image1 = orange2;
			image2 = blue2;
			label = " Hoy ";
		}
		
		if(getModel().isPressed()) { // If mouse presses the button it is clicking.....
			bgColor = Color.CYAN;
			image1 = orange1;
			image2 = blue1;
			label = "Aiyi!";
		}
		
		g.setColor(bgColor);
		g.fillRect(0, 0, getWidth(), getHeight());
		g.drawImage(image1, 5, 2, 18, 18, null);
		g.drawImage(image2, 55, 2, 18, 18, null);
		g.setColor(Color.GRAY);
		g.drawString(label, 25, 14);
	}
	
	public void paintBorder(Graphics g) {
		g.setColor(Color.RED); // Red Line
		g.drawLine(0, 0, getWidth()-1, 0);
		
		g.setColor(Color.BLUE); // Blue Line
		g.drawLine(0, getHeight()-1, getWidth()-1, getHeight()-1);
		
		g.setColor(Color.GREEN); // Green Line
		g.drawLine(0, 0, 0, getHeight()-1);
		
		g.setColor(Color.ORANGE); // Orange Line
		g.drawLine(getWidth()-1, 0, getWidth()-1, getHeight()-1);
	}
	
}
