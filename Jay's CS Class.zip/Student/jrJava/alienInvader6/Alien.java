package jrJava.alienInvader6;

import java.awt.Color;
import java.awt.Graphics;

public class Alien {
	
	public static final int WIDTH, HEIGHT;
	private static int eyeRadius;
	
	private Color bodyColor, eyeColor;
	private int x, y; // Bottom Center
	private int vx, vy;
	private Missile[] missiles; // to store multiple missile objects
	private BattleShip target; // BattleShip will send its reference through here so that the Alien class can use it in its structure.
	
	private boolean collided;
	public static final Color EXPLOSION_COLOR;
	public static final int EXPLOSION_RADIUS;
	
	static { // allows to initialize static variables
		WIDTH = 25;
		HEIGHT = 25;
		eyeRadius = 3;
		
		EXPLOSION_COLOR = Color.GREEN;
		EXPLOSION_RADIUS = 120;
	}
	
	public Alien() {
		
	}
	
	public Alien(int x, int y, Color bodyColor, Color eyeColor, int vx, int vy, BattleShip target) {
		
		this.x = x;
		this.y = y;
		this.bodyColor = bodyColor;
		this.eyeColor = eyeColor;
		this.vx = vx;
		this.vy = vy;
		this.target = target;
		
		missiles = new Missile[10];	
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public void move() {
		
		x += vx;
		y += vy;
		
		if(y>750) {
			AlienMotherShip.remove(this); // IMPORTANT: 'this' is the specific Alien object's address (needs to pass its address) so that it can be destroyed.
		}
		
		if(Math.random()>0.90) {
			for(int i=0; i<10; i++) {
				if(missiles[i]==null) { //If there is an unoccupied storage space, we create a new Missile object into the next available one. Once it is full, we 'break' and get out of the loop.
					missiles[i] = new Missile(x, y, 2*vy, this, target); // 'this' is the ALIEN OBJECT'S ADRESSS/REFERENCE which is this whole class with Alien code so that the Missile object knows which owner it is referring to.
					break;
				}         
			}
		}
		
		for(int i=0; i<10; i++) {
			if(missiles[i]!=null) {
				missiles[i].move(); // This command line will execute the specific missile object's "move command"
			}
		}
		
		target.isHit(this); 
		
	}
	
	public boolean isHit(Torpedo torpedo) {
		// It will evaluate if the torpedo's rectangle and the alien's rectangle overlap or not.
		
		/*  
		
		boolean c1 = torpedo.getX() >= x-WIDTH/2-Torpedo.WIDTH/2;
		boolean c2 = torpedo.getX() <= x+WIDTH/2+Torpedo.WIDTH/2;
		boolean c3 = torpedo.getY() >= y-HEIGHT-Torpedo.HEIGHT;
		boolean c4 = torpedo.getY() <= y;
		
		// If collision happens -> it will destroy itself and return true.
		
		if(c1 && c2 && c3 && c4) {
			AlienMotherShip.remove(this);
			return true;
		}
		
		*/
		
		// OR LIKE THIS (MORE EFFICIENT):
		
		if(torpedo.getX() >= x-WIDTH/2-Torpedo.WIDTH/2 && torpedo.getX() <= x+WIDTH/2+Torpedo.WIDTH/2 && torpedo.getY() >= y-HEIGHT-Torpedo.HEIGHT && torpedo.getY() <= y) {
			AlienMotherShip.remove(this);
			return true;
		} // This method knows right away whether or not the if(boolean){} is true or false (short-circuit evaluation).
		
		for(int i=0; i<missiles.length; i++) {
			// if(missiles[i].isHit(torpedo)) {
			//	return true;
			// }
			
			if(missiles[i]!=null && missiles[i].isHit(torpedo)) {
				return true;
			}
		}
		
		// If not, it will return false.
		return false;
	}
	
	public void draw(Graphics g) {
		g.setColor(bodyColor);
		g.drawRect(x-WIDTH/2, y-HEIGHT, WIDTH, HEIGHT); // x moves left by half of the WIDTH's length and y goes up by HEIGHT length
		
		g.setColor(eyeColor);
		g.drawOval(x-WIDTH/4-eyeRadius, y-3*HEIGHT/4-eyeRadius, 2*eyeRadius, 2*eyeRadius); // From the left eye's center which is (x-WIDTH/4, y-3/4*HEIGHT), we must remove eye radius to get the left-hand corner coordinate.
		g.drawOval(x+WIDTH/4-eyeRadius, y-3*HEIGHT/4-eyeRadius, 2*eyeRadius, 2*eyeRadius); // Same from above, but for the right eye move it to the right
		
		for(int i=0; i<10; i++) {
			if(missiles[i]!=null) {
				missiles[i].draw(g); // This command line will execute the specific missile object's "draw command"
			}
		}
		
		if(collided) {
			g.setColor(EXPLOSION_COLOR);
			g.drawOval(x-EXPLOSION_RADIUS, y-EXPLOSION_RADIUS, 2*EXPLOSION_RADIUS, 2*EXPLOSION_RADIUS);
			// AlienMotherShip.remove(this); <----- GAME OVER CONDITION
		}
	
	}
		
	public void remove(Missile missile) { 
		for(int i=0; i<missiles.length; i++) {
			if(missiles[i]==missile) {
				missiles[i] = null;
				break;
			}
		}
	}
	
}
