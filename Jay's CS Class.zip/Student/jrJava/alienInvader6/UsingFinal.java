package jrJava.alienInvader6;

public class UsingFinal {
	
	// In some of the fields, we like to expose it as public.
	// The concern, however, is that an outside user can not only read the information,
	// but also, they can CHANGE/ALTER the information contained in the field.
	// To prevent this situation, we can use the key word
	// 'FINAL'
	
	// Java allows two chances to initialize the final fields.
	// We have to use one of these two chances only once.
	// If it is a non-static field:
	//  	1. At the time of the declaration
	// 		2. In the constructor method
	// If it is a static field:
	// 		1. At the time of declaration
	// 		2. Inside the static block
	
	// If the field happens to be 'public', 'static', and 'final' (all three),
	// then, it is a special king of case called 'constant'.
	// If the field happens to be 'constant' -----> We indicate (emphasize) that the field is constant by making the field name ALL UPPER-CASE and UNDERSCORE the space between two or more words.
	
	public final String address; // = "10601 S. DeAnza Blvd, Cupertino";
	public static final String PHONE_NUMBER; // = "408-111-1111";
	
	private double profit;
	private int employeeNumber;
	
	static {
		PHONE_NUMBER = "408-111-1111";
	}
	
	public UsingFinal() {
		address = "10601 S. DeAnza Blvd, Cupertino";
	}
	
	public void makeChange() {
		
		// address = "10602 S. DeAnza Blvd, Cupertino";
		
	}

}
