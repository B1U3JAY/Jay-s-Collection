package jrJava.alienInvader7_outOfControl;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class Missile implements KeyListener, MouseMotionListener{
	
	public static final int WIDTH, HEIGHT;
	private static Color color;
	private int x, y; // Bottom center of missile
	private int vy;
	private Alien owningAlien;
	private BattleShip target; // BattleShip will send its reference through here so that the Missile class can use it in its structure.
	
	private boolean collided;
	public static final Color EXPLOSION_COLOR;
	public static final int EXPLOSION_RADIUS;
	
	static {
		WIDTH = 4;
		HEIGHT = 12;
		color = Color.RED;
		
		EXPLOSION_COLOR = Color.PINK;
		EXPLOSION_RADIUS = 70;
	}
	
	public Missile(int x, int y, int vy, Alien owningAlien, BattleShip target) { // Missile constructor method
		this.x = x;
		this.y = y;
		this.vy = vy;
		this.owningAlien = owningAlien; // the Alien owningAlien code is so that it can store the individual address of the Alien object.
		this.target = target; 
		
		Coordinator.board.addKeyListener(this);
		Coordinator.board.addMouseMotionListener(this);
	}
	
	public boolean isHit(Torpedo torpedo) {
		
		if(torpedo.getX() >= x-WIDTH/2-Torpedo.WIDTH/2 && torpedo.getX() <= x+WIDTH/2+Torpedo.WIDTH/2 && torpedo.getY() >= y-HEIGHT-Torpedo.HEIGHT && torpedo.getY() <= y) {
			owningAlien.remove(this);
			Coordinator.board.removeKeyListener(this);
			Coordinator.board.removeMouseMotionListener(this);
			return true;
		} // This method knows right away whether or not the if(boolean){} is true or false (short-circuit evaluation).
		
		return false;
	}
	
	public int getX() {
		
		return x;
	}
	
	public int getY() {
		
		return y;
	}
	
	public void move() {
		y += vy;
		
		if(y>750) {
			owningAlien.remove(this); // IMPORTANT: 'this' is the specific Missile object's address (needs to pass its address) so that it can be destroyed.
			Coordinator.board.removeKeyListener(this);
			Coordinator.board.removeMouseMotionListener(this);
		}
		
		collided = target.isHit(this);
		
	}
	
	public void draw(Graphics g) {
		g.setColor(color);
		g.drawRect(x-WIDTH/2, y-HEIGHT, WIDTH, HEIGHT); // To get the (x,y) coordinate of the rectangular missile, we x is x-w/2 and y is y-h
		
		if(collided) {
			g.setColor(EXPLOSION_COLOR);
			g.drawOval(x-EXPLOSION_RADIUS, y-EXPLOSION_RADIUS, 2*EXPLOSION_RADIUS, 2*EXPLOSION_RADIUS);
			// owningALien.remove(this); <----- GAME OVER CONDITION
		}
	}
	
	public void keyTyped(KeyEvent e) {
		
	}

	public void keyPressed(KeyEvent e) {
		// 'T' stands for Torpedo
		if(e.getKeyCode()==KeyEvent.VK_T) {
			x = 20;
		}
	}

	public void keyReleased(KeyEvent e) {
		
	}
	
	
	
	public void mouseDragged(MouseEvent e) {
		x = e.getX();
		y = y/2;
		vy = 1;
	}

	public void mouseMoved(MouseEvent e) {
		
	}

}

