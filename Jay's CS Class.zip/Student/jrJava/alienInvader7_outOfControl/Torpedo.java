package jrJava.alienInvader7_outOfControl;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Torpedo implements KeyListener{
	
	private static Color color;
	public static final int WIDTH, HEIGHT;
	private int x;
	private int y;
	private int vy; // We need vy < 0 in order to go up on the DrawingBoard.
	private boolean collided;
	private static Color explosionColor;
	private static int explosionRadius;
	
	private BattleShip owningShip;
	
	static {
		color = Color.BLUE;
		WIDTH = 4;
		HEIGHT = 12;
		
		explosionColor = Color.YELLOW;
		explosionRadius = 40;
	}
	
	public Torpedo(int x, int y, int vy, BattleShip owningShip) {
		this.x = x;
		this.y = y;
		this.vy = vy;
		this.owningShip = owningShip;
		
		Coordinator.board.addKeyListener(this);
	}
	
	public int getX() { // 'Get X' Method so other classes can access it.
		return x;
	}
	
	public int getY() { // 'Get Y' Method so other classes can access it.
		return y;
	}
	
	
	
	public void move() {
		y += vy;
		
		
		if(y<100) { 
			owningShip.remove(this);
			Coordinator.board.removeKeyListener(this);
		}
		
		// Check whether if the collision happened or not!
		if(AlienMotherShip.isHit(this)) {
			collided = true;
		}
		
	}
	
	public void draw(Graphics g) {
		g.setColor(color);
		g.drawRect(x-WIDTH/2, y, WIDTH, HEIGHT);
		
		if(collided) {
			g.setColor(explosionColor);
			g.drawOval(x-explosionRadius, y-explosionRadius, 2*explosionRadius, 2*explosionRadius);
			owningShip.remove(this); // We delayed removing the object so that an explosion animation can be shown
			Coordinator.board.removeKeyListener(this);
		}
	}

	public void keyTyped(KeyEvent e) {
		
	}

	public void keyPressed(KeyEvent e) {
		// 'T' stands for Torpedo
		if(e.getKeyCode()==KeyEvent.VK_T) {
			color = Color.RED;
		}
	}

	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_T) {
			color = Color.BLUE;
		}
	}
	
}
