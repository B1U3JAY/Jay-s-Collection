package jrJava.inheritance2_cosmicSuperClass;

public class B extends A{
	
	public int b = 20;
	
	public void mB() {
		
	}

}
