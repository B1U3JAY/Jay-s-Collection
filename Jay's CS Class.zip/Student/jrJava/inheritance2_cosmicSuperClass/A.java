package jrJava.inheritance2_cosmicSuperClass;

public class A { // -----> public Class A extends Object{ ..... Java automatically extends this class to the Object or the "Cosmic Super Class". 
	
	public int a = 10;
	
	public void mA() {
		
	}

}
