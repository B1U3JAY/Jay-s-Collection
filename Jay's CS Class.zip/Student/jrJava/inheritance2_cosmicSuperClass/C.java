package jrJava.inheritance2_cosmicSuperClass;

public class C extends B{
	
	public int c = 30;
	
	public void mC() {
		
	}

}
