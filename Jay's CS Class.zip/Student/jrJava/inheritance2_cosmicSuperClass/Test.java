package jrJava.inheritance2_cosmicSuperClass;

public class Test {

	public static void main(String[] args) {
		
		Object obj1 = new Object();
		Object obj2 = new Object();
		
		boolean isEqual = obj1.equals(obj2); // Object type is equal, but the actual Object (class) itself is not, so the return will be false. In the future we can make it "logically equal", however, right now they are "physically unequal".
		String description = obj1.toString();
		int uniqueNumber1 = obj1.hashCode();
		int uniqueNumber2 = obj2.hashCode();
		Class theClass = obj1.getClass();
		
		System.out.println(isEqual);
		System.out.println(description);
		System.out.println(uniqueNumber1);
		System.out.println(uniqueNumber2);
		System.out.println(theClass);
		
	}

}
