package jrJava.inheritance2_cosmicSuperClass;

public class Test2 {
	
	public static void main(String[] args) {
		
		A ref1 = new A();
		B ref2 = new B();
		C ref3 = new C();
		
		// ref1.
		// ref2.
		// ref3.
		
	}
		
}
