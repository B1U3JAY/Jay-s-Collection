package jrJava.abstractType_arrayList2;

public class ObjectB {
	
	public static void doTheJob(MyArrayList list) {
		list.add(789); // It automatically creates an 'Integer' Wrapper Class (so an Integer Object).
		list.add(213);
	}

}
