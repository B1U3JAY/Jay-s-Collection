package jrJava.abstractType_arrayList2;

public class Test {
	
	public static void main(String[] args) {
		
		MyArrayList list = new MyArrayList();
		
		ObjectA.doTheJob(list);
		ObjectB.doTheJob(list);
		ObjectC.doTheJob(list);
	}

}
