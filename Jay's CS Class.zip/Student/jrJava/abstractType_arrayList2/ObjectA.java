package jrJava.abstractType_arrayList2;

public class ObjectA {
	
	public static void doTheJob(MyArrayList list) {
		list.add("123"); // This is a String type object that we are passing. Once it goes into the 'MyArrayList', it becomes an Object type object.
		list.add("456");
	}

}
