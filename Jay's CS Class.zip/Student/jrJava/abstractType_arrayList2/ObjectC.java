package jrJava.abstractType_arrayList2;

public class ObjectC {
	
	public static void doTheJob(MyArrayList list) {
		
		
		for(int i=0; i<list.size(); i++) {
			String obj = (String) list.get(i); // We must downcast the reference before calling a method such as '.length'. THEREFORE, we must downcast it because its POSSIBLE for an Object to be a String. Also this will allow us to call the specific methods we want for a String object.
			System.out.println(obj.length()); // The problem is when we actually try to call it (refer to class 'ObjectB'), it will be a 'ClassCastException' because we tried to use an Integer Wrapper Class Object as a String Object.
		}
		
	}
	
	/*
	public static void main(String[] args) {
		
		MyArrayList list = new MyArrayList();
		
		ObjectA.doTheJob(list);
		ObjectB.doTheJob(list);
		ObjectC.doTheJob(list);
		
	}
	*/

}
