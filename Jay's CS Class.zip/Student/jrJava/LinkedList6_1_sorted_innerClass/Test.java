package jrJava.LinkedList6_1_sorted_innerClass;

import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		
		LinkedList<String> list = new LinkedList<String>();
		
		list.insert("ddd");
		list.insert("bbb");
		list.insert("ccc");
		list.insert("eee");
		list.insert("aaa");
		
		Iterator<String> iter = list.iterator();
		while(iter.hasNext()) {
			String each = iter.next();
			System.out.println(each);
			if(each.indexOf("c")>=0){
				iter.remove();
			}
		}
		
		System.out.println();
		
		iter = list.iterator();
		while(iter.hasNext()) {
			String each = iter.next();
			System.out.println(each);
		}

	}

}
