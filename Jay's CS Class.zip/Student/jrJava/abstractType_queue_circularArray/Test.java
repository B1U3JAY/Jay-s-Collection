package jrJava.abstractType_queue_circularArray;

public class Test {

	public static void main(String[] args) {
		
		MyQueue q = new MyQueue(8);
		q.enqueue("A");

	}

}
