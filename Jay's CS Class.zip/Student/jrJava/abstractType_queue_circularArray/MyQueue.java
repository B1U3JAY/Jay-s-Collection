package jrJava.abstractType_queue_circularArray;

// This time the array will loop back to the first index of the array when it reaches the end, hence a circular motion/path.

public class MyQueue {
	
	private Object[] elements;
	private int front, rear, size;
	
	public MyQueue(int size) {
		elements = new Object[size];
		front = -1;
		rear = 0;
		size = 0;
	}
	
	public void enqueue(Object ref) { // 'front' is for enqueue
		if(size==elements.length) {
			throw new IndexOutOfBoundsException();
		}
		
		front++;
		
		if(front==elements.length) { // Sinc elemenets.length is 1 more than the end of the array.
			front = 0; // "Circle" it back and change it back to '0'.
		}
		
		elements[front] = ref;
		
	}
	
	public Object dequeue() { // 'rear' is for dequeue
		if(isEmpty()) {
			throw new IndexOutOfBoundsException();
		}
		
		Object temp = elements[rear];
		
		elements[rear] = null; // This is not necessary.
		
		rear++;
		
		if(rear==elements.length) {
			rear = 0;
		}
		size--;
		return temp;
	}
	
	public Object peek() {
		if(isEmpty()) {
			throw new IndexOutOfBoundsException();
		}
		
		return elements[rear];
	}
	
	public boolean isEmpty() {
		return size==0;
	}

}
