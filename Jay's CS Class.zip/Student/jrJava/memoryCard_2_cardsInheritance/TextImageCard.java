package jrJava.memoryCard_2_cardsInheritance;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

public class TextImageCard extends TextCard{
	protected Image image;

	public TextImageCard(String text, Image image) {
		super(text);
		this.image = image;
		font = new Font("Times", Font.BOLD, 14);
	}
	
	protected void paintContent(Graphics g) {
		g.setColor(Color.BLACK);
		g.setFont(font);
		g.drawString(text, x+20, y+25);
		// super.paintContent(g);
		/*  // Calling the super's (TextCard's) paintContent method, you don't have to re-type the same code (that is commented out).
		g.setColor(Color.BLACK);
		g.setFont(font);
		g.drawString(text, x+20, y+60);
		*/
		g.drawImage(image, x+10, y+10, SIZE-20, SIZE-20, null);
		
	}

}
