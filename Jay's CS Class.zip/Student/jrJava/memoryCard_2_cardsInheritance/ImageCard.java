package jrJava.memoryCard_2_cardsInheritance;

import java.awt.*;

public class ImageCard extends Card{
	
	protected Image image; // We want subclasses to see or use it, hence, it is 'protected'
	
	public ImageCard(Image image) {
		this.image = image;
	}
	
	protected void paintContent(Graphics g) { // We want subclasses to see or use it, hence, it is 'protected'
		System.out.println("Image's Paint Content");
		// if(shouldReveal) {
			g.drawImage(image, x+10, y+10, SIZE-20, SIZE-20, null); // Field (x, y) is card's left-hand corner. The middle frame is a tenth of the size of the main square away from both x and y. / SIZE*4/5 because the area of the middle square is 80 pixels instead of 100. / Middle square that is 10 pixels away from each inner side of the outer square.
		// }
		
		// else {
		//	g.drawImage(backSideImage, x+10, y+10, SIZE-20, SIZE-20, null); // Backside of the card (backSideImage).
		// }
		
		/*
		// This is the same thing as above ^^^^^
		if(shouldReveal) {
			g.drawImage(image, x+SIZE/10, y+SIZE/10, SIZE*4/5, SIZE*4/5, null); // Field (x, y) is card's left-hand corner. The middle frame is a tenth of the size of the main square away from both x and y. / SIZE*4/5 because the area of the middle square is 80 pixels instead of 100. / Middle square that is 10 pixels away from each inner side of the outer square.
		}
		
		else {
			g.drawImage(backSideImage, x+SIZE/10, y+SIZE/10, SIZE*4/5, SIZE*4/5, null); // Backside of the card (backSideImage).
		}
		*/
		
		
		
	}

}
