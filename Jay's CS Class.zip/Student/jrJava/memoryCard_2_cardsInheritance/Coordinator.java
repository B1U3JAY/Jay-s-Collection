package jrJava.memoryCard_2_cardsInheritance;

import java.awt.*;

import javax.swing.ImageIcon;

import resources.SoundPlayer;

public class Coordinator {
	
	private static String[] imageNames = {
										"apple", "bank", "basketball", "bubble_blue", "bubble_green", 
										"bubble_red", "building", "cat", "cheese", "denture", 
										"dog", "hockey_stick", "keys", "phone", "pizza",
										"santa", "soccer_ball", "sock", "toilet_bowl", "toilet_paper",
										"xmas_tree"};

	public static void main(String[] args) {
		
		/*
		Card[] cards = new Card[8];
		
	    Image image = new ImageIcon("jrJava/memoryCard_imagesAndSounds/hockey_stick.png").getImage();
		
		cards[0] = new ImageCard(image);
		cards[0].show();
		
		cards[1] = new ImageCard(image);
		cards[1].show();
		
		cards[2] = new TextCard("2+4=?");
		cards[2].show();
		
		cards[3] = new TextCard("  6  ");
		cards[3].show();
		
		SoundPlayer aahSound = new SoundPlayer("jrJava/memoryCard_imagesAndSounds/scream.wav");
		cards[4] = new SoundCard(aahSound);
		cards[4].show();
		
		cards[5] = new TextCard(" Aah! ");
		cards[5].show();
		
		Image image2 = new ImageIcon("jrJava/memoryCard_imagesAndSounds/apple.png").getImage();
		cards[6] = new TextImageCard("Name?", image2);
		cards[6].show();
		cards[7] = new TextCard("Apple");
		cards[7].show();
		*/
		
		Card[] cards = new Card[42]; // Exclude "backside.png" because it will be used as a back cover for all the cards
		
		Image image;
		
		for(int i=0; i<cards.length; i+=2) { // i+=2 because we need to when i is 0, the image will go into cards[0] and cards[1]. When i is 2 it will start at cards[2] and cards[3].....
			image = new ImageIcon("jrJava/memoryCard_imagesAndSounds/" + imageNames[i/2] + ".png").getImage();  // 0, (skip 1), 2, (skip 3), 4, (skip 5)..... So, we divide by 2
			cards[i] = new ImageCard(image); // x2 card objects
			cards[i+1] = new ImageCard(image);
			cards[i].hide();
			cards[i+1].hide();
		
		}
		
		GameBoard board = new GameBoard(cards);
		
	}

}
