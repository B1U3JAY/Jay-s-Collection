package jrJava.memoryCard_2_cardsInheritance;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

import resources.SoundPlayer;

public class SoundCard extends Card {
	
	protected SoundPlayer sound;
	protected static Image musicImage;
	
	static {
		musicImage = new ImageIcon("jrJava/memoryCard_imagesAndSounds/music.png").getImage();
	}
	
	public SoundCard(SoundPlayer sound) {
		this.sound = sound;
	}
		
	protected void paintContent(Graphics g) {
		g.drawImage(musicImage, x+10, y+10, SIZE-20, SIZE-20, null);
		sound.play();
	}
	
}
