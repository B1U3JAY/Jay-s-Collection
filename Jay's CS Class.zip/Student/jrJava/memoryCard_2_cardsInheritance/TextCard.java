package jrJava.memoryCard_2_cardsInheritance;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class TextCard extends Card{
	
	protected String text;
	protected Font font;
	
	public TextCard(String text) {
		this.text = text;
		font = new Font("Times", Font.BOLD, 24);
	}
	
	protected void paintContent(Graphics g) {
		// if(shouldReveal) {
			g.setColor(Color.BLACK);
			g.setFont(font);
			g.drawString(text, x+20, y+60);
		// }
		
	}

}
