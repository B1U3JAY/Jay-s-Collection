package jrJava.abstractType_generics4;

public class SorterTest1 {
	
	public static void main(String[] args) {
		
		SelectionSorter1 sorter = new SelectionSorter1();
		
		Comparable[] data = new Comparable[4];
		
		data[0] = new Ball(500, 100, 50);
		data[1] = new Ball(300, 100, 60);
		data[2] = "abc"; //new Ball(100, 100, 10);
		data[3] = new Ball(400, 100, 30);
		
		sorter.sort(data);
		
		for(int i=0; i<data.length; i++) {
			System.out.println(data[i]);
		}
		
	}

}
