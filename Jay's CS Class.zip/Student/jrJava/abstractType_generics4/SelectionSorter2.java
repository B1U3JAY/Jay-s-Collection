package jrJava.abstractType_generics4;

// The structure is '<T extends Comparable<T>>' so that if we choose to use Ball (for example), then it will be '<Ball extends Comparable<Ball>>' so that it can be compared with the same type:
public class SelectionSorter2<T extends Comparable<T>> { // This is a bounded & recursive generic type: // Only 'Comparable' type objects will be able compared (by using '.compareTo'):
	
	public void sort(T[] objs) { // Look to Class 'Test.java' in this package for more information.
		
		int i, j, minIndex;
		T temp;

		for(i=0; i<objs.length-1; i++) {

			minIndex = i;

			for(j=i+1; j<objs.length; j++) { // In order to compare the 'Ball' objects, we will be comparing each of its distance 'd' (and compare that in order to rearrange from least to greatest).
				if(objs[j].compareTo(objs[minIndex])<0) { // '-1'; When two 'Ball' objects are compared and one is smaller than the other, we will make that its 'minIndex'. (This is a better way to handle these multiple criteria/conditions instead of doing it like in package "jrJava.sorting_Objects")
					minIndex = j;
				}
			}

			temp = objs[i]; 
			objs[i] = objs[minIndex];
			objs[minIndex] = temp;
		}
	}

}
