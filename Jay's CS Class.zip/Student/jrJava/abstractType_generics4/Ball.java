package jrJava.abstractType_generics4;

import java.util.Scanner;

// We will be designing "sample objects" for future uses of "Object Sorting"; We will create a 'Ball' and an 'Employee':

// "Recursive Generic Type":
public class Ball implements Comparable<Ball> { // If you look at the 'Comparable' interface, it uses a generic type '<T>' (which was a method 'compareTo(T o){}'; We will use Ball as the generic type which then we will have to make 'compareTo(T o){}' into 'compareTo(Ball o){}' (Only 'Ball' type objects will be accepted):
	
	// Center coordinates (x, y):
	private int x;
	private int y;
	
	private int radius;
	private double distance;
	
	public Ball(int x, int y, int radius) { // Constructor Method:
		super();
		this.x = x;
		this.y = y;
		this.radius = radius;
		distance = Math.sqrt(x*x + y*y);
	}
	
	// "Better" constructor method:
	// Overloaded constructor method:
	public Ball(String line) { // 'line' will refer to each and every line in a '.txt' file (which holds all the information for the paramters needed to create multiple 'Ball' objects).
		// Ex: 23 55 50
		
		Scanner s = new Scanner(line);
		
		x = s.nextInt(); // Ex: 23
		y = s.nextInt(); // Ex: 55
		radius = s.nextInt(); // Ex: 50
		
		s.close();
		
		distance = Math.sqrt(x*x + y*y);
	}
	
	/*
	public int greaterThan(Ball o) { // Java also has something similar prepared for these kinds of comparisons which uses the method 'compareTo'. Look at package "jrJava.sorting_Objects4" for more on this information.
		// (Similarly, if one object is greater than the other it return a positive number such as one, if both objects are equal it returns a neutral value such as zero, and if one is less than the other it returns a negative number such as negative one).
		if(distance>o.distance) {
			return 1;
		}
		else if(distance<o.distance) {
			return -1;
		}
		else { // If they are equal
			// We can make further conditions so we can truly see which object is "greater" than the other.
			if(radius>o.radius) {
				return 1;
			}
			else if(radius<o.radius) {
				return -1;
			}
			else {
				return 0; 
			}
		}
	}
	*/
	
	public int compareTo(Ball o) { // Must complete this Interface 'Comparable' method.
		Ball b = (Ball) o; // First we must downcast it, so that we can access the specific methods and fields from the 'Ball' object (instead of the general 'Object' object).
		
		// Similar to the 'greaterThan' method, we will compare the 'distance' between each 'Ball' object first:
		if(distance>b.distance){ // Even though these are 'private' they are of the same class, so we can access it.
			return 1;
		} 
		else if(distance<b.distance) {
			return -1;
		}
		else {
			// Now if the 'distance' are equal we will compare the next field which is each 'Ball' object's 'radius'.
			if(radius>b.radius) {
				return 1;
			}
			if(radius<b.radius) {
				return -1;
			}
			return 0; // If both 'distance' and 'radius' are the same, then we return '0'. (This means they are equal)
		}
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getRadius() {
		return radius;
	}
	
	public double getDistance() {
		return distance;
	}
	
	public boolean equals(Object o) { // We need to override this super class method (Overridding is when the method name and the paramters are exactly the same except they provide different functionality).
		if(!(o instanceof Ball)) {
			return false;
		}
		Ball b = (Ball) o; // Downcast (so that we can compare)
		return x==b.x && y==b.y && radius==b.radius; // Either return 'true' or 'false.
	}
	
	public String toString() { // Override
		return "[x=" + x + ", y=" + y + ", r=" + radius + ", d=" + (int)((distance*100)/100.0) + "]"; // The distance has continous numbers after the decimal point, so it will be rounded up to the nearest whole number (since dividing by a double will make 'distance' a double type and then we can cast it into an integer type).
	}
	
	public int hashCode() { // Override
		return x + 100*y + 10000*radius; // We will learn this later.
	}
	
}
