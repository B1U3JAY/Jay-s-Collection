package jrJava.abstractType_generics3;

public class PairedDataStorage<K, V> { // This time we use two generic types:
	
	private K key;
	private V value;
	
	public void put(K key, V value) {
		this.key = key;
		this.value = value;
	}
	
	public K getKey() {
		return key;
	}
	
	public V getValue() {
		return value;
	}

}
