package jrJava.abstractType_generics3;

public class Test1 {

	public static void main(String[] args) {
		
		PairedDataStorage<String, Ball> storage = new PairedDataStorage<String, Ball>();
		
		storage.put("abc", new Ball(1, 2)); // Matches type for (String and Ball), so it goes in.
		
		String key = storage.getKey();
		Ball value = storage.getValue();

	}

}
