package jrJava.abstractType_generics3;

public class Test2 {

	public static void main(String[] args) {
		
		// Example:
		
		StatDataStorage<Integer> storage = new StatDataStorage<Integer>(); // It will accept all sub-types from the 'Number' type. (So objects like 'Ball' or 'String' won't be accepted)
		
		Integer[] values = {4, 3, 2, 1};
		
		storage.setData(values);
		
		Integer min = storage.min();
		System.out.println(min);
		
		double mean = storage.getAverage();
		System.out.println(mean);
		
	}

}
