package jrJava.abstractType_generics3;

// Bounded Generic Types:

public class StatDataStorage<E extends Number> { // 'extends' indicates the "sub-family" (In our case we are limiting the sitaution to a 'Number' type):
	
	// *Note: 'Number' includes 'Integer', 'Byte', 'Short', 'Long', 'Double, & 'Float'
	
	private E[] data;
	
	public void setData(E[] ref) {
		this.data = ref;
	}
	
	public E getData(int index) {
		return data[index];
	}

	public E min() {
		E min = data[0];
		for(int i=1; i<data.length; i++) {
			if(data[i].doubleValue()<min.doubleValue()){ // We will change it into its 'double' value in order to compare it with one another.
				min = data[i];
			}
		}
		return min;
	}
	
	public double getAverage() {
		double sum = 0.0;
		for(int i=0; i<data.length; i++) {
			sum += data[i].doubleValue();
		}
		return sum/data.length;
	}
	
	/*
	public double getVariance() {
	
	}
	*/

}
