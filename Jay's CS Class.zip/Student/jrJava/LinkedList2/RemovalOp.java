package jrJava.LinkedList2;

import java.util.Iterator;

public class RemovalOp {
	
	private LinkedList iter;
	private int removeId;
	
	public RemovalOp(LinkedList iter, int removeId) {
		this.iter = iter;
		this.removeId = removeId;
	}
	
	public void process() {
		if(iter.hasNext()) {
			Link each = (Link)iter.next();
			if(each.id==removeId) {
				iter.remove();
			}
		}
	}

}
