package jrJava.LinkedList2;

public class Test1 {

	public static void main(String[] args) {
		
		int[] data = {3, 6, 1, 9, 6, 3, 5};
		
		for(int i=0; i<data.length; i++) {
			data[i] = data[i] + 1;
			// System.out.println(data[i]);
		}
		
		//---------------------------------
		
		LinkedList list = new LinkedList();
		
		list.insert(3, 3.0);
		list.insert(6, 5.0);
		list.insert(1, 1.0);
		list.insert(9, 9.0);
		list.insert(6, 6.0);
		list.insert(3, 3.0);
		list.insert(5, 5.0);
		
		/*
		int size = list.size();
		
		for(int i=0; i<size; i++) {
			Link each = list.get(i);
			each.value = each.value + 1;
		}
		
		list.printAll();
		*/
		
		while(list.hasNext()) {
			Link each = list.next();
			System.out.println(each);
		}
		
	}

}
