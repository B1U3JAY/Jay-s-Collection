package jrJava.LinkedList2;

import java.util.Iterator;

public class AdditionOp {
	private LinkedList iter;
	
	public AdditionOp(LinkedList list) {
		this.iter = list;
	}

	public void process() {
		
		if(iter.hasNext()) {
			Link each = (Link)iter.next();
			each.value += 100;
		}
		
	}

}
