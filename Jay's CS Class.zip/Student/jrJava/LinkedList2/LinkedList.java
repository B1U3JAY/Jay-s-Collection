package jrJava.LinkedList2;

public class LinkedList{ 
	
	// Iterator (ex. Scanner(s)):
	
	private Link current; // Null; Should point to one before the 'first'
	private Link previous;
	
	public boolean hasNext() {
		if(current==null) { // Special Case
			return first!=null; 
		}
		
		return current.next!=null;
	}
	
	public Link next() {
		if(current==null) { // Special Case
			current = first; // Jump to 'first'
			return first;
		}
		
		previous = current;
		current = current.next;
		return current;
	}
	
	public void remove() {
		if(current==null) { // Special Case
			throw new UnsupportedOperationException("remove-operation");
		}
		
		if(previous==null) {
			first = first.next;
			current = null;
			return;
		}
		
		previous.next = current.next;
		// Move cursor one step backward to avoid staying on the address of the link we are trying to remove:
		current = previous;
		
	}
	
	// ------------------
	
	public Link first;
	
	public LinkedList() {
		
	}
	
	public boolean isEmpty() {
		return first==null;
	}
	
	public void insertAtBeginning(int id, double value) {
		Link link = new Link(id, value);
	
		link.next = first;
		first = link; // We are inserting the new 'link' at the front; the first link in the 'LinkedList' will be this now:
	}
	
	public void insertAtEnd(int id, double value) {
		Link link = new Link(id, value);
		
		if(first==null) { // Check if the 'first' happens to be 'null' first:
			first = link;
			return;
		}
		
		Link current = first;
		while(current.next!=null) { // If the next link is 'null'
			current = current.next;
		}
		
		current.next = link;
	}
	
	// if only this insert(.....) method is used, then the linkedList  will be a sorted-linkedList:
	public void insert(int id, double value) {
		
		Link link = new Link(id, value);
		
		Link current = first;
		Link previous = null;
		
		while(current!=null && current.id<id) { // If its less than the inputted 'id', it will keep moving up until it is in the right position. (We must be careful of the NPE - Null Pointer Exception! - by using short circuit evaluation - '&&').
			previous = current;
			current = current.next;
		}
		
		// if(current==null) // One of the three 'Null Pointer Exception' cases (which is taken care of the 'if & else' statement below):
		
		if(previous==null) {
			link.next = first;
			first = link;
		}
		else { 
			previous.next = link; // We must be careful of the NPE - Null Pointer Exception!.
			link.next = current;
		}
		
	}
	
	public Link removeFirst() { // As long as there is any 'link' in the 'LinkedList', it will remove the first one in the list:
		
		Link temp = first;
		if(first!=null) {
			first = first.next;
		}
		return temp;
		
	}
	
	public Link removeEnd() {
		if(first==null) {
			return null;
		}
		
		Link current = first;
		Link previous = null;
		
		while(current.next!=null) {
			previous = current;
			current = current.next;
		}
		
		if(previous==null) {
			first = null;
		}
		else {
			previous.next = null;
		}
		
		return current;
		
	}
	
	public Link remove(int id) { // Remove based on 'id':
		
		if(first==null) {
			return null;
		}
		
		Link current = first;
		Link previous = null;
		
		while(current.id!=id) { // Keep finding until we get a match:
			previous = current;
			current = current.next; // We cannot throw a 'Null pointer Exception'.
			if(current==null) {
				return null;
			}
		}
		
		if(previous==null) {
			first = first.next;
		}
		else {
			previous.next = current.next; // Be careful because we can't have a 'null.next', hence, the previous 'if' statement.
		}
		
		return current;
	}
	
	public int size() { // Basically smae thing as 'printAll()' but counts instead of prints:
		int count = 0;
		Link current = first;
		while(current!=null) {
			count++;
			current = current.next; // Move link from one to the next
		}
		return count;
	}
	
	public void printAll() {
		Link current = first;
		
		while(current!=null) {
			System.out.print(current + " ");
			current = current.next; // Move link from one to the next
		}
		System.out.println();
	}
	
	public Link get(int index) {
		if(index<0 || index>size()-1) {
			throw new IndexOutOfBoundsException();
		}
		
		Link current = first;
		
		for(int i=0; i<index; i++) {
			current = current.next;
		}
		
		return current;
	}

}
