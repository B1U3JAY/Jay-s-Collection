package jrJava.LinkedList6_innerClass;

import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		
		LinkedList<String> list = new LinkedList<String>();
		list.insertAtEnd("aaa");
		list.insertAtEnd("bbb"); 
		list.insertAtEnd("ccc");
		/*
		list.insert("ccc");
		list.insert("bbb");
		list.insert("aaa");
		*/
		
		// Iterator<String> iter = new MyIterator<String>(list); // This is what we did when 'MyIterator' was a separate class, but now:
		
		Iterator<String> iter = list.iterator(); // We can do this now 
		
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
		

	}

}
