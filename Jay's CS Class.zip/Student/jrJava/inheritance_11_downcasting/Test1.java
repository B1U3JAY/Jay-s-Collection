package jrJava.inheritance_11_downcasting;

public class Test1 {

	public static void main(String[] args) {
		
		// Upcasting:
		
		A ref1 = new C(); // OR A ref1 = (A) new C(); We don't need a casting operating since this is always true.
		B ref2 = new C();
		I ref3 = new C();
		Object ref4 = new C(); 
		C ref5 = new C(); // All of these go 'up' to the next class type.
		
		A ref6 = ref5; // This is also upcasting since a C type reference is a specialized A type.
		B ref7 = ref5;
		I ref8 = ref5;
		Object ref9 = ref5; // Same logic follows up to here.....
		
		// Downcasting:
		
		A ref11 = new C(); // Using the A type reference we can only call methods that belong to its types (which is A type).
		ref11.mA();
		// We cannot call these because they may not belong in the A type
		// ref11.mB(); 
		// ref11.mC();
		// ref11.mI();
		
		// If we want to call the above commented methods, we need to make the type more specialized by putting a 'lower' type. For example:
		
		B ref12 = (B) ref11; // Now we can call mB and mI methods.
		ref12.mA();
		ref12.mB();
		ref12.mI();
		// ref12.mC(); However, we cannot call mC method yet.
		
		// Therefore we lower the type once more and add the needed casting operator type:
		
		C ref13 = (C) ref11;
		ref13.mA();
		ref13.mB();
		ref13.mI();
		ref13.mC(); // Hence, all of them work!
		
		// Another example:
		// Say we have an Interface I type reference and we create a C object. It will not work unless we lower down the type.
		
		I ref14 = new C();
		ref14.mI();
		// ref14.mA();
		// ref14.mB();
		// ref14.mC();
		
		// Something like this will work because we are forcefully making the I reference a B type and putting it into a B type reference.
		B ref15 = (B) ref14;
		// So we can call:
		ref15.mI();
		ref15.mA();
		ref15.mB();
		ref15.mC();
		
		// Summary: We can either go up the type diagram (upcasting) or down the type diagram (downcasting).
		
	}

}
