package jrJava.inheritance_11_downcasting;

public class B extends A implements I{
	
	public void mB() {
		System.out.println("I got processed.");
	}
	
	public void mI() {
		
	}

}
