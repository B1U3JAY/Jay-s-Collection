package jrJava.inheritance_11_downcasting;

public class Test3 {

	public static void main(String[] args) {
		
		Object[] objs = new Object[4];
		
		objs[0] = new B();
		objs[1] = new B();
		objs[2] = new B();
		// objs[3] = new D(); // All of the B types will work, BUT even though there is no error, the D type will not work even with the B type force
		// So Java will shut down after objs[3]. This is why downcasting is a problem since you may not notice this subtle mistake (that is so huge!).
		
		process(objs); 

	}
	
	public static void process(Object[] refs) {
		
		for(int i=0; i<refs.length; i++) {
			B each = (B) refs[i]; // Follows same concept; this is one line of downcasting so Java will accept this.
			each.mB();
		}
		
	}

}
