package jrJava.inheritance_11_downcasting;

public class D extends A{
	
	public void mD() {
		
	}

}
