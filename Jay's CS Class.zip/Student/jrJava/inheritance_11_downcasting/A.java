package jrJava.inheritance_11_downcasting;

public class A {
	
	public void mA() {
		
	}

}
