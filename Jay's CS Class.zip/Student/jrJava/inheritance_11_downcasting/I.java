package jrJava.inheritance_11_downcasting;

public interface I {
	
	public abstract void mI();

}
