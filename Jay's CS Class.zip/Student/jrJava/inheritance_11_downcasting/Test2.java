package jrJava.inheritance_11_downcasting;

public class Test2 {

	public static void main(String[] args) {
		
		// D ref1 = new B(); This will obviously not work.
		
		// Even if we try to force it:
		// D ref1 = (D) new B();
		
		// Another example:
		
		A ref2 = new B(); // Upcasting
		
		// ClassCastException Error:
		
		D ref3 = (D) ref2; // If we do this, the B type can become a D type. 
		// We are taking the new B type, storing it in an A type reference, 
		// and forcefully making it a D type so that we can insert it in a D type reference.
		
		// HOWEVER:
		// During the runtime, Java will go to your memory (heap) space and go to the object's address. 
		// Java will realize it is not possible, so it will shut down everything.
		
		// This is a problem because as you can see there is no error, but in reality Java will not accept this.
		
		// Another example:
		
		I ref11 = new C();
		// D ref12 = ref11; This will not work because it is not one line of upcasting or downcasting.
		// If we do this:
		D ref12 = (D) ref11; // However, this is possible because any object can be an Interface (I) type.
		// But since D did NOT implement I, Java will shut down.

	}

}
