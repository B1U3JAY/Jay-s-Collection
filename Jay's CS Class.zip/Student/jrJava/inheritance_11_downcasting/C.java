package jrJava.inheritance_11_downcasting;

public class C extends B{
	
	public void mC() {
		
	}

}
