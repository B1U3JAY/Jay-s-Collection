package jrJava.lineOfAction_2;

import java.awt.*;

public class Coordinator {
	
	public static boolean gameOver;
	public static int winner;

	public static void main(String[] args) {
		
		MyDrawingBoard board = new MyDrawingBoard(500, 100, 500, 500);
		Graphics g = board.getBufferedG();
		
		GameBoard gameBoard = new GameBoard(g);
		
		board.addMouseListener(gameBoard);
		board.addMouseMotionListener(gameBoard);
		
		while(!gameOver) {
			if(winner!=0) {
				gameOver = true; // Game Over is 'true' here so that the board can draw one last time before it ends/
			}
			
			board.clear();
			gameBoard.draw();
			board.repaint();
			
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) { }
		
		}
		
		// Must register the listners again (since we exited the loop):
		board.addMouseListener(gameBoard);
		board.addMouseMotionListener(gameBoard);
		
		g.setColor(Color.BLACK);
		g.drawString("Game Over", 50, 50);
		board.repaint();
	}

}
