package jrJava.lineOfAction_3_dumb_AI;

import java.awt.*;

public class Coordinator {
	
	public static boolean gameOver;
	public static int winner;
	public static boolean humanPlayerTurn;
	
	public static final int HUMAN_TURN = 1;
	public static final int COMPUTER_TURN = -1;

	public static void main(String[] args) {
		
		MyDrawingBoard board = new MyDrawingBoard(500, 100, 500, 500);
		Graphics g = board.getBufferedG();
		
		GameBoard gameBoard = new GameBoard(g);
		
		board.addMouseListener(gameBoard);
		board.addMouseMotionListener(gameBoard);
		
		AIPlayer AI = new AIPlayer(gameBoard);
		gameBoard.setTurn(HUMAN_TURN);
		humanPlayerTurn = true;
		
		int countAfterTurnChange = 0;
		
		while(!gameOver) {
			if(winner!=0) {
				gameOver = true; // Game Over is 'true' here so that the board can draw one last time before it ends.
			}
			
			board.clear();
			gameBoard.draw();
			board.repaint();
			
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) { }
			
			if(!humanPlayerTurn) {
				countAfterTurnChange++;
				if(countAfterTurnChange>1) { // So we make the thread go back to the beginning of the 'while' loop. This is so that we can see what move the human makes and what move the AI makes (instead of them both all at once).
					AI.makeMove();
					humanPlayerTurn = true;
					countAfterTurnChange = 0;
				}
			}
		}
		
		// Must register the listners again (since we exited the loop):
		board.addMouseListener(gameBoard);
		board.addMouseMotionListener(gameBoard);
		
		g.setColor(Color.BLACK);
		if(winner==HUMAN_TURN) {
			g.drawString("Human Won!", 50, 50);
		}
		else if(winner==COMPUTER_TURN) {
			g.drawString("AI Won!", 50, 50);
		}
		
		board.repaint();
	}

}
