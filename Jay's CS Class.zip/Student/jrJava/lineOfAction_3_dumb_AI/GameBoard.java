package jrJava.lineOfAction_3_dumb_AI;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GameBoard implements MouseListener, MouseMotionListener {
	
	private Graphics g;
	private int radius = 15;
	private int margin = 100; // Margin of the actual board game
	private int interval = 50; // Horizontal/Vertical gap or distance (in pixels) from one side to another
	private int rows, cols;
	
	private int[] sq = {
		 0,  1,  1,  1,  0,
		-1,  0,  0,  0, -1,
		-1,  0,  0,  0, -1,
		-1,  0,  0,  0, -1,
		 0,  1,  1,  1,  0
	};
	
	private int turn; // Which color's turn (based on + or -)
	private int selected; // Index of the selected square
	private boolean beingDragged;
	private int dragX, dragY;
	private boolean dragCompleted;
	private int dragEndIndex;
	
	private ArrayList<Integer> validMovesList;
	// Total 8 directions (in pairs):
	private int[] dirX = {1, -1, 0, 0, 1, 1, -1, -1};
	private int[] dirY = {0, 0, 1, -1, 1, -1, 1, -1};
	
	public GameBoard(Graphics g) {
		this.g = g;
		rows = 5;
		cols = 5;
		turn = 1; // Red's turn
		selected = -1;
		
		validMovesList = new ArrayList<Integer>();
	}
	
	public int getTurn() {
		return turn;
	}
	
	public void setTurn(int turn) {
		this.turn = turn;
	}
	
	public void draw() {
		g.setColor(Color.BLACK);
		
		// Horizontal Lines:
		for(int i=0; i<=cols; i++) {
			g.drawLine(margin + i*interval, margin, margin + i*interval, margin + rows*interval);
		}
		
		// Vetical Lines:
		for(int i=0; i<=cols; i++) {
			g.drawLine(margin, margin + i*interval, margin + cols*interval, margin + i*interval);
		}
		
		// Display Pieces:
		int x, y;
		for(int k=0; k<sq.length; k++) {
			x = margin + k%cols*interval + interval/2 - radius;
			y = margin + k/cols*interval + interval/2 - radius;
			
			if(sq[k]==1) {
				g.setColor(Color.RED);
				g.fillOval(x, y, 2*radius, 2*radius);
			}
			else if(sq[k]==-1) {
				g.setColor(Color.GREEN);
				g.fillOval(x, y, 2*radius, 2*radius);
			}
		}
		
		if(!dragCompleted && selected>=0) {
			markSelected();
			markAllValidMoves();
		}
		
		if(beingDragged) {
			g.setColor(Color.GRAY);
			g.fillOval(dragX-6, dragY-6, 12, 12);
		}
	
	}
	
	private int findIndex(int x, int y) {
		return (x-margin)/interval +  (y-margin)/interval*cols;
	}
	
	private void markAllValidMoves() {
		g.setColor(Color.GRAY);
		int markIndex, markX, markY;
		
		for(int i=0; i<validMovesList.size(); i++) {
			markIndex = validMovesList.get(i);
			markX = margin + markIndex%cols*interval;
			markY = margin + markIndex/cols*interval;
			
			g.drawRect(markX+2, markY+2, interval-4, interval-4);
			g.drawRect(markX+3, markY+3, interval-6, interval-6); // For clarity
		}
	}
	
	private void markSelected() {
		int x = margin + selected%cols*interval + interval/2 - radius;
		int y = margin + selected/ cols*interval + interval/2 - radius;
		
		g.setColor(Color.LIGHT_GRAY);
		g.fillOval(x-6, y-6, 12, 12);
	}

	public void mousePressed(MouseEvent e) {
		if(!Coordinator.humanPlayerTurn) { // Check Turn
			return;
		}
		
		int mousePressedIndex = findIndex(e.getX(), e.getY());
		if(sq[mousePressedIndex]!=turn) {
			return;
		}
		selected = mousePressedIndex;
		dragCompleted = false;
		
		findAllValidMoves();
	}

	public void mouseDragged(MouseEvent e) {
		if(!Coordinator.humanPlayerTurn) { // Check Turn
			return;
		}
		
		if(selected<0) {
			return;
		}
		
		beingDragged = true;
		dragX = e.getX();
		dragY = e.getY();
	}

	public void mouseReleased(MouseEvent e) {
		if(!Coordinator.humanPlayerTurn) { // Check Turn
			return;
		}
		
		if(selected<0) {
			return;
		}
		
		beingDragged = false;
		dragCompleted = true;
		dragEndIndex = findIndex(e.getX(), e.getY());
		
		if(!isValidMove()) {
			selected = -1;
			return;
		}
		
		sq[selected] = 0;
		sq[dragEndIndex] = turn;
		selected = -1;
		
		boolean result = isGameOver();
		
		if(result) { // Game Over & Set The Winner
			Coordinator.winner = turn;
		}
		
		turn *= -1;
		
		Coordinator.humanPlayerTurn = false;
	}

	public void mouseMoved(MouseEvent e) { }

	public void mouseClicked(MouseEvent e) { } 

	public void mouseEntered(MouseEvent e) { }

	public void mouseExited(MouseEvent e) { } 
	
	// This method is for the AI Player:
	public ArrayList<Integer> allMyPieces(){
		ArrayList<Integer> allMyPieces = new ArrayList<Integer>();
		for(int i=0; i<sq.length; i++) {
			if(sq[i]==turn) {
				allMyPieces.add(i);
			}
		}
		
		return allMyPieces;
	}
	
	// This method is for the AI Player:
	public void selectPiece(int selected){
		this.selected = selected;
	}
	
	// This method is for the AI Player:
	public ArrayList<Integer> allValidMoves() {
		findAllValidMoves();
		
		return validMovesList;
	}
	
	// This method is for the AI Player:
	// This method will move the piece at the 'from' index to the 'to' index:
	// If the move captures an enemy piece, it will return 'true' (otherwise it will be 'false').
	public boolean makeMove(int from, int to) {
		boolean captureEnemyPiece = sq[to]==-turn;
		sq[to] = turn;
		sq[from] = 0;
		
		return captureEnemyPiece;
	}

	// This method is for the AI Player:
	public boolean makeMove(Move move) {
		return makeMove(move.getFromIndex(), move.getToIndex());
	}
	
	private void findAllValidMoves() {
		
		validMovesList.clear();
		
		int selectX = selected%cols;
		int selectY = selected/cols;
		int numOfSteps;
		int targetX, targetY, targetIndex;
		int k, px, py, pIndex;
		
		for(int i=0; i<dirX.length; i++) {
			numOfSteps = findNumOfPiecesInLineOfAction(dirX[i], dirY[i]);
			targetX = selectX + dirX[i]*numOfSteps;
			targetY = selectY + dirY[i]*numOfSteps;
			targetIndex = targetX + targetY*cols;
			
			// Check to see if it will still be inside the board:
			if(targetX<0 || targetX>=cols || targetY<0 || targetY>=rows) { // Then its an invalid move (so skip by continuing):
				continue;
			}
			
			// Check to see if it will land on an ally piece:
			if(sq[targetIndex]==turn) {
				continue;
			}
			
			// Check to see if it will jump over an enemy piece:
			boolean jumpOverEnemy = false;
			for(k=1; k<numOfSteps; k++) {
				px = selectX + dirX[i]*k;
				py = selectY + dirY[i]*k;
				pIndex = px + py*cols;
				if(sq[targetIndex]==-turn) {
					jumpOverEnemy = true;
					break;
				}
			}
			
			if(jumpOverEnemy) {
				continue;
			}
			
			validMovesList.add(targetIndex);
		}
		
	}
	
	private boolean isValidMove() {
		return validMovesList.contains(dragEndIndex);
	}
	
	private int findNumOfPiecesInLineOfAction(int xInc, int yInc) {
		int pX, pY, pIndex;
		int numOfPieces = 1; // Count itself
		
		for(int i=1; i<cols; i++) { // Forward
			pX = selected%cols + xInc*i;
			pY = selected/cols + yInc*i;
			pIndex = pX + pY*cols;
			// Check if it goes out of board:
			if(pX<0 || pX>=cols || pY<0 || pY>=rows) {
				break;
			}
			if(sq[pIndex]!=0) {
				numOfPieces++;
			}
		}
		
		for(int i=1; i<cols; i++) { // Backward
			pX = selected%cols - xInc*i;
			pY = selected/cols - yInc*i;
			pIndex = pX + pY*cols;
			// Check if it goes out of board:
			if(pX<0 || pX>=cols || pY<0 || pY>=rows) {
				break;
			}
			if(sq[pIndex]!=0) {
				numOfPieces++;
			}
		}
		
		return numOfPieces;
	}
	
	public boolean isGameOver() {
		ArrayList<Integer> pieces = new ArrayList<Integer>();
		ArrayList<Integer> cluster = new ArrayList<Integer>();
		
		for(int i=0; i<sq.length; i++) {
			if(sq[i]==turn) {
				pieces.add(i);
			}
		}
		
		// Cluster Starts With One Element:
		cluster.add(pieces.remove(0));
		
		int clusterSize;
		while(!pieces.isEmpty()) {
			clusterSize = cluster.size();
			addToCluster(pieces, cluster);
			
			if(cluster.size()==clusterSize){
				return false;
			}
		}
		
		return true; // Everything was able to move!
	}
	
	private void addToCluster(ArrayList<Integer> pieces, ArrayList<Integer> cluster) {
		int i, j, each, cEach;
		
		for(i=pieces.size()-1; i>=0; i--) {
			each = pieces.get(i);
			for(j=0; j<cluster.size(); j++) {
				cEach = cluster.get(j);
				if(Math.abs(cEach%cols-each%cols)<=1 && Math.abs(cEach/cols-each/cols)<=1) {
					cluster.add(each);
					pieces.remove(i);
					break;
				}
			}
		}
	}

}
