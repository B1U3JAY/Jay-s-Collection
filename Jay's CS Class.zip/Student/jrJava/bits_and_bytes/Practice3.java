package jrJava.bits_and_bytes;

public class Practice3 {
	
	// Bitwise Operators:

	public static void main(String[] args) {
		
		/*
		int a = 1234567890;
		int b = 4444444;
		int c = a ^ b; // 'XOR'
		// int c = a & b;
		// int c = a | b;
		
		printBinary(a);
		printBinary(b);
		printBinary(c);
		*/
		
		int a = 15;
		int b = ~a; // Bitwise Operator to turn it negative
		
		printBinary(a);
		printBinary(b);
		
		int p = 3124565;
		int q = ~p + 1; // To use the bitwise operator and turn it negative it will do it by flipping the original (binary) value and adding 1
		System.out.println(q);
	}
	
	public static void printBinary(int value) {
		String binaryString = Integer.toBinaryString(value);
		
		// 32-binaryString.length() // preceding zeroes
	
		for(int i=0; i<32-binaryString.length(); i++) {
			System.out.print('0');
		}
		
		System.out.println(binaryString);
	}

}
