package jrJava.booleanType;

import java.util.Scanner;

public class CanBuy {

	public static void main(String[] args) {
		
		double m;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Please type in how much money you have:");
		m = scanner.nextDouble();
		if (m>2000.0) {
			System.out.println("You can buy a car!");
		}
		else if(m>=700.0){
			System.out.println("You can buy a laptop!");
		}
		else {
			System.out.println("You can't buy anything on this list!");
		}
		scanner.close();
	}
}