package jrJava.booleanType;

public class ShortCircuitEvaluation {

	public static void main(String[] args) {
		
		int x =3;
		boolean result1 = x<2 && !(x!=3) && x>2;
		System.out.println(result1);
		
		boolean result2 = x>4 || x<3.1 || x>0 || x>5;
		System.out.println(result2);
		
		int xx = 10;
		int yy = 20;
		
		boolean aaa = xx + 1 > yy - 5 && !(yy>=xx || 2*xx!=3*yy) && yy - xx<= yy + xx;
		
		if(xx + 1 > yy - 5 && !(yy>=xx || 2*xx!=3*yy) && yy - xx<= yy + xx) {
			// .....
			// .....
		}
		
		boolean bbb = xx + yy > xx - yy || !(xx<=yy && xx>100) || !aaa;
		
		if(xx + yy > xx - yy || !(xx<=yy && xx>100) || !aaa) {
			// .....
			// .....
		}

	}

}
