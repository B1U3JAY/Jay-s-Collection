package jrJava.booleanType;

import java.util.Scanner;

public class DetermineQuadrant {

	public static void main(String[] args) {
		
		double x;
		double y;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Think of a point in a x,y-coordinate plane");
		System.out.println("What is the x-value?");
		x = scanner.nextDouble();
		System.out.println("What is the y-value?");
		y = scanner.nextDouble();
		
		if(x>0) {
			if(y>0) {
				System.out.println("Your point is in Quadrant 1");
			}
			else {
				System.out.println("Your point is in Quadrant 4");
			}
		}
		if(x<0) {
			if(y>0)
				System.out.println("Your point is in Quadrant 2");
			}
			else if(y<0){
				System.out.println("Your point is in Quadrant 3");
			}
		if(x==0) {
			if(y!=0) {
				System.out.println("Your point is on the x-axis");
			}
		}
		if(y==0) {
			if(x!=0) {
				System.out.println("Your point is on the y-axis");
			}
		}
		if (x==0 && y==0) {
			System.out.println("Your point is on the origin.");
		}
	}
}
