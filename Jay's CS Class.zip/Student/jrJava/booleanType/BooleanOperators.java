package jrJava.booleanType;

public class BooleanOperators {

	public static void main(String[] args) {
		
		// !(NOT) Operator
		
		boolean a1 = 100>99;
		boolean a2 = !a1;
		boolean a3 = !a2;
		System.out.println("a3 holds " + a3);
		
		int x = 55;
		boolean b1 = !(x<60);
		boolean b2 = !b1;
		System.out.println("b2 holds " + b2);
		
		// &&(AND) Operator
		
		int y = 100;
		boolean c1 = y>50 && y<120;
		System.out.println("c1 = " + c1);
		boolean c2 = !(y>50 && y<90);
		System.out.println("c2 = " + c2);
		boolean c3 = y>=50 && y<150 && y!=99;
		System.out.println("c3 = " + c3);
		boolean c4 = y==100 && y!=100; // "Silly" Expression! Always False!
		System.out.println("c4 = " + c4);
		boolean c5 = y>=100 && y<100; // "Silly" Expression! Always False!
		System.out.println("c5 = " + c5);
		
		// ||(OR) Operator
		
		int z = 15;
		boolean d1 = z<16 || z> 21;
		System.out.println("d1 = " + d1);
		boolean d2 = z==20 || z<=10 || z!=18;
		System.out.println("d2 = " + d2);
		
		boolean d3 = z==100|| z!=100;  // "Silly" Expression! Always True!
		System.out.println("d3 = " + d3);
		boolean d4 = z>=100 || z<100; // "Silly" Expression! Always True!
		System.out.println("d4 = " + d4);
	}

}
