package jrJava.booleanType;

import java.util.Scanner;

public class IdentifyShape {

	public static void main(String[] args) {
		
		double s;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Type in the number of sides your shape has here:");
		s = sc.nextDouble();
		if (s==3) {
			System.out.println("It is a Triangle!");
		}
		else if (s==4){ 
			System.out.println("It is a Quadrilateral!");
		}
		else if(s==5){
			System.out.println("It is a Pentagon!");
		}
		else if (s==6) {
			System.out.println("It is a Hexagon!");
		}
		else {
			System.out.println("Invalid Shape");
		}
		sc.close();
	}
}