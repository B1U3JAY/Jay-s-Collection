package jrJava.booleanType;

import java.util.Scanner;

public class BooleanType {

	public static void main(String[] args) {
		
		// boolean type variable (storage) can hold logical data (True or False).
		/*
		boolean aaa; //declration
		aaa = true; // initialization
		System.out.println("aaa holds " + aaa);
		
		boolean bbb = false; // declaration and initialization
		System.out.println ("bbb holds " + bbb);
		 */
		
		double pocketMoney;
		boolean isRich;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("How much money do you have in your pocket?");
		pocketMoney = scanner.nextDouble();
		
		isRich = pocketMoney>=100;
		
		System.out.println("Our verdict: Do we think you are rich? Answer is " + isRich);
	}

}
