package jrJava.booleanType;

import java.util.Scanner;

public class DoubleOrTriple {

	public static void main(String[] args) {
		
		double n;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Please type in a number");
		n = scanner.nextDouble();
		if (n>100.0) {
			n = n*2;
		}
		else if(n>50){
			n = n*3;
		}
		else {
			n = n;
		}
		System.out.println("Your new number is " + n + " .");
		scanner.close();
	}
}
