package jrJava.booleanType;

import java.util.Scanner;

public class DetermineGrade {

	public static void main(String[] args) {
		
		double Grade;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Please type in your grade:");
		Grade = scanner.nextDouble();
		if (Grade>=90.0) {
			System.out.println("You got an A!");
		}
		else if(Grade>=80.0){
			System.out.println("You can a B!");
		}
		else if(Grade>=70.0){
			System.out.println("You got a C!");
		}
		else if(Grade>=60.0){
			System.out.println("You got a D!");
		}
		else if(Grade<=50.0){
			System.out.println("You got a F!");
		}
		scanner.close();
	}
}