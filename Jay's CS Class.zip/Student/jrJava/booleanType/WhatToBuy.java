package jrJava.booleanType;

import java.util.Scanner;

public class WhatToBuy {

	public static void main(String[] args) {
		
		double m;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please type how much money you have:");
		m = sc.nextDouble();
		if (m>10000.0) {
			System.out.println("Do you want to buy a car (type in 1) or a house (type in 2)?");
			int a = sc.nextInt();
			if (a==1) { 
				System.out.println("A car costs $30,000");
			}
			else {
				System.out.println("A house costs $1,000,000");
			}
		}
		else if(m<=10000.0){
			System.out.println("Do you want to buy a laptop (type in 1) or a phone (type in 2)");
			int b = sc.nextInt();
			if (b==1) {
				System.out.println("A laptop costs $1,000");
			}
			else {
				System.out.println("A phone costs $700");
			}
		}
		sc.close();
	}
}