package jrJava.booleanType;

import java.util.Scanner;

public class PassedTest {
	
	public static void main(String[] args) {
		
		double score;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("What score did you receive?");
		score = scanner.nextDouble();
		if (score>=70.0) {
			System.out.println("YOU PASSED!");
		}
		else {
				System.out.println("Sorry. you failed.");
		}
	}
}
