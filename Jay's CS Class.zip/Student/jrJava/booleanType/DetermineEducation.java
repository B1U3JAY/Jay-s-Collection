package jrJava.booleanType;

import java.util.Scanner;

public class DetermineEducation {

	public static void main(String[] args) {

		int age;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Type in your age here:");
		age = sc.nextInt();
		if (age<4) {
			System.out.println("You should be in Preschool!");
		}
		else if (age<=9){ 
			System.out.println("You should be in Elementary School!");
		}
		else if(age<=13){
			System.out.println("You should be in Middle School!");
		}
		else if (age<=18) {
			System.out.println("You should be in High School!");
		}
		else {
			System.out.println("You should be in College!");
		}
		sc.close();
	}
}