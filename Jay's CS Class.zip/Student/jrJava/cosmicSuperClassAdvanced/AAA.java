package jrJava.cosmicSuperClassAdvanced;

public class AAA { // Remember that the Cosmic Super Class has no state (or no fields).
	
	private int a1 = 10;
	private int a2 = 20;
	
	public AAA(int a1, int a2) {
		this.a1 = a1;
		this.a2 = a2;
	}
	
	public void mA() {
		
	}

}
