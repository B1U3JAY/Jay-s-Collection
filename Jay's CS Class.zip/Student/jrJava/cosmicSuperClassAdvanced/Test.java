package jrJava.cosmicSuperClassAdvanced;

public class Test {

	public static void main(String[] args) {
		
		AAA ref1 = new BBB(1, 2, 3, 4); // If you use 'ref1' it can only access the 'AAA' types.
		
		Object ref2 = new BBB(1, 2, 3, 4); // If you use 'ref1' it can only access the 'Cosmic Super Class' types.
		
		System.out.println(ref1.getClass());
		System.out.println(ref2.getClass());
	}

}
