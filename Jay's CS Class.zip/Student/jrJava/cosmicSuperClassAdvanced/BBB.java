package jrJava.cosmicSuperClassAdvanced;

public class BBB extends AAA {
	
	private int b1;
	private int b2;
	
	public BBB(int a1, int a2, int b1, int b2) {
		super(a1, a2);
		this.b1 = b1;
		this.b2 = b2;
	}
	
	public void mB() {
		
	}

}
