package jrJava.GUI_actionListener2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*; // The star (*) will import everything from the javax.swing package. This is better than importing all 10 packages every single time.

public class MyGUI implements ActionListener{
	
	private JFrame frame;
	// private JFrame frame2;
	private JPanel panel, smallPanel;
	private JScrollPane scrollPane;
	private JTextArea textArea;
	private JLabel label1, imageLabel1, imageLabel2, imageLabel3;
	private JTextField textField;
	private JMenuBar menuBar;
	private JMenu menu1, menu2;
	private JMenuItem item1A, item1B, item1C, item1D, item1E, item2A, item2B;
	private JButton button1, button2;
	
	public MyGUI() {
		
		frame = new JFrame();
		frame.setTitle("My First GUI");
		frame.setBounds(300, 100, 500, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // DISPOSE_ON_CLOSE makes the app still be runeven if the user presses the 'X' button to close the window.
		
		/*
		frame2 = new JFrame();
		frame2.setBounds(500, 100, 200, 100);
		frame2.setTitle("Another JFrame");
		frame2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
		*/
		
		menuBar = new JMenuBar();
		frame.add(menuBar, BorderLayout.NORTH); // If there is no border component it will take up all the space
		
		menu1 = new JMenu("Move");
		menu2 = new JMenu("Help");
		menuBar.add(menu1);
		menuBar.add(menu2);
		
		item1A = new JMenuItem("Up");
		item1B = new JMenuItem("Down");
		item1C = new JMenuItem("Left");
		item1D = new JMenuItem("Right");
		item1E = new JMenuItem("Center");
		item2A = new JMenuItem("Search");
		item2B = new JMenuItem("About");
		menu1.add(item1A);
		menu1.add(item1B);
		menu1.add(item1C);
		menu1.add(item1D);
		menu1.add(item1E);
		menu2.add(item2A);
		menu2.add(item2B);
		
		item1A.addActionListener(this);
		item1B.addActionListener(this);
		item1C.addActionListener(this);
		item1D.addActionListener(this);
		item1E.addActionListener(this);
		
		panel = new JPanel(); // "Containing relationship" between JFrame and JPanel. JPanel is an "excellent container" because it is invisible, hence, we can use a lot.
		// panel.setBackground(Color.CYAN); // Use a 'setter' for a the background color if you want to really see the JPanel. We usually put Color.WHITE.
		panel.setBackground(Color.WHITE); 
		panel.setLayout(null); // Note: To set bounds we must go to JPanel ('panel' in this case) (which is the "container" for some J Objects) and pass the LayoutManager to be null so that it doesn't use the default layout.
		frame.add(panel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 50, 300, 200);
		panel.add(scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea); // Remember that TextArea's ('textArea' in this case) immediate container is ScrollPane ('scrollPane' in this case).
		
		label1 = new JLabel("Type in:"); // JLabel's ('label1' in this case) immediate container is JPanel ('panel' in this case).
		label1.setBounds(20, 250, 100, 20);
		panel.add(label1);
		
		textField = new JTextField(); // JTextField's ('textField' in this case) immediate container is JPanel ('panel' in this case).
		textField.setBounds(20, 270, 300, 20);
		textField.addActionListener(this);
		panel.add(textField);
		
		smallPanel = new JPanel(); // JPanel's ('smallPanel' in this case) immediate container is JPanel ('panel' in this case).
		smallPanel.setBounds(340, 40, 100, 200);
		smallPanel.setBackground(Color.WHITE); // Make the same color as the rest so that it looks 'invisible'.
		smallPanel.setLayout(null); // Note: To set bounds we must go to JPanel ('smallPanel' in this case) (which is the "container" for some J Objects) and pass the LayoutManager to be null so that it doesn't use the default layout.
		panel.add(smallPanel);
		
		// From here
		ImageIcon icon1 = new ImageIcon("jrJava/GUI_1/orangeAlien_1.png");
		imageLabel1 = new JLabel("GUI Demo", icon1, JLabel.CENTER); // JLabel's ('imageLabel1' in this case) immediate container is JPanel ('smallPanel' in this case).
		imageLabel1.setVerticalTextPosition(JLabel.TOP);
		imageLabel1.setHorizontalTextPosition(JLabel.CENTER);
		imageLabel1.setBounds(10, 0, 80, 80);
		smallPanel.add(imageLabel1);
		
		ImageIcon icon2 = new ImageIcon("jrJava/GUI_1/torpedo.png");
		imageLabel2 = new JLabel(" ", icon2, JLabel.CENTER); // JLabel's ('imageLabel2' in this case) immediate container is JPanel ('smallPanel' in this case).
		imageLabel2.setVerticalTextPosition(JLabel.TOP);
		imageLabel2.setHorizontalTextPosition(JLabel.CENTER);
		imageLabel2.setBounds(10, 90, 80, 80);
		smallPanel.add(imageLabel2);
		
		ImageIcon icon3 = new ImageIcon("jrJava/GUI_1/ship.png");
		imageLabel3 = new JLabel(" ", icon3, JLabel.CENTER); // JLabel's ('imageLabel3' in this case) immediate container is JPanel ('smallPanel' in this case).
		imageLabel3.setVerticalTextPosition(JLabel.TOP);
		imageLabel3.setHorizontalTextPosition(JLabel.CENTER);
		imageLabel3.setBounds(10, 130, 80, 80);
		smallPanel.add(imageLabel3);
		// To here =====> JPanel's smallPanel is right now using the default LayoutManager which is why the setBounds command does not work.
		
		// button1 = new JButton();
		// button1.set  Text("Shoot");
		button1 = new JButton("Shoot");
		button1.setBounds(350, 255, 80, 20);
		button1.addActionListener(this);
		panel.add(button1);
		
		// button2 = new JButton();
		// button2.set  Text("Shoot");
		button2 = new JButton("Abort");
		button2.setBounds(350, 285, 80, 20); 
		button2.addActionListener(this);
		panel.add(button2);
		
		frame.setVisible(true); // Make the frame visible
		// frame2.setVisible(true); 
	}
	
	public void actionPerformed(ActionEvent e) {
		
		// e.getSource(); // The object on which the Event initially occurred.
		
		if(e.getSource()==button1) {
			textField.setText("A Torpedo got shot!");
			textArea.setText("Alert! Alert! Alert! World citizens! \nA torpedo has been launched"); // "\n" stands for the next line.
			imageLabel2.setBounds(10, 40, 80, 80); // Moves 50 pixels up when "Shoot" is pressed.
		}
		
		else if(e.getSource()==button2) {
			textField.setText("A Torpedo got cancelled!");
			textArea.setText("False Alert! False Alert! False Alert!"); // "\n" stands for the next line.
			imageLabel2.setBounds(10, 90, 80, 80); // Moves 50 pixels back down when "Abort" is pressed.
		}
		
		else if(e.getSource()==item1A) {
			smallPanel.setBounds(340, 20, 100, 200);
		}
		
		else if(e.getSource()==item1B) {
			smallPanel.setBounds(340, 60, 100, 200);
		}
		
		else if(e.getSource()==item1C) {
			smallPanel.setBounds(320, 40, 100, 200);
		}
		
		else if(e.getSource()==item1D) {
			smallPanel.setBounds(360, 40, 100, 200);
		}
		
		else if(e.getSource()==item1E) {
			smallPanel.setBounds(340, 40, 100, 200);
		}
		
		else if(e.getSource()==textField) {
			String content = textField.getText();
			// String content2 = textArea.getText();
			textArea.setText(textArea.getText() + "\n" + content + "\n" + content + "\n" + content);
		}
		
	}
	
	public static void main(String[] args) {
		new MyGUI();
	}
}
