package jrJava.abstractType_arrayList;

public class Test {

	public static void main(String[] args) {
		
		MyArrayList list = new MyArrayList(); // In our example it starts with a size '5' array.
		
		System.out.println(list.size());
		list.add(new Ball(1, 1));
		
		System.out.println(list.size());
		list.add(new Ball(2, 2));
		
		System.out.println(list.size());
		list.add(new Ball(3, 3));
		System.out.println(list.size());
	
		// System.out.println(list.get(1));
		
		System.out.println(list);
		
		list.add(1, new Ball(3, 3));
		list.add(1, new Ball(5, 5));
		list.add(1, new Ball(7, 7));
		
	}

}
