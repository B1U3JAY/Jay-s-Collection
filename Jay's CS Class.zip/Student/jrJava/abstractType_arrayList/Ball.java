package jrJava.abstractType_arrayList;

import java.util.ArrayList;

public class Ball {
	
	private int x;
	private int y;
	
	public Ball(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public double getDistance() {
		return Math.sqrt(x*x + y*y);
	}
	
	public String toString() {
		return "[" + x + ", " + y + "]";
	}
	
	public boolean equals(Object o) {
		if(!(o instanceof Ball)) {
			return false;
		}
		
		Ball other = (Ball) o; // Downcast so that it can be compared/accessed later.
		
		return x==other.x && y==other.y;
	}

}
