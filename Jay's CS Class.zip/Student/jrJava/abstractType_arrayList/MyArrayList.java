package jrJava.abstractType_arrayList;

public class MyArrayList {
	
	private Ball[] elements;
	private int lastElementIndex = -1; // 'last'ElementIndex' + 1 will be the 'size'.
	
	// get(i); // Will get the reference at index 'i'.
	// add(ref); // Will add at the end.
	// add(i, ref); // Will insert the 'ref' so that its index will be 'i'.
	// remove(i); // Will remove AND return the reference at incdex 'i'.
	// remove(r); // Will search and find the 'ref', and remove it.
	// size(); // Will report the current number of references.
	
	public MyArrayList() {
		elements = new Ball[5];
		lastElementIndex = -1;
	}
	
	public MyArrayList(int size) {
		elements = new Ball[size];
		lastElementIndex = -1;
	}
	
	public int size() {
		return lastElementIndex + 1;
	}
	
	public Ball get(int index) {
		if(index<0 || index>lastElementIndex) {
			throw new ArrayIndexOutOfBoundsException(); // This exercise's purpose is to hide the user from knowing that we are using an array and can't return a null pointer since its part of the data.
		}
		
		return elements[index]; // Now we must 'toString' it so we don't receive the reference.
	}
	
	public void add(Ball ref) { // If the user reaches the end of the array we will make a bigger one instead:
		if(lastElementIndex == elements.length-1) {
			// Create another array with double the size
			Ball[] elements2 = new Ball[elements.length*2];
			
			// Transfer all the references to the new array
			for(int i=0; i<=lastElementIndex; i++) {
				elements2[i] = elements[i];
			}
			
			// Garbage-collect the old array
			elements = elements2; // What we are doing here is replacing the reference of 'elements' with the reference of 'elements2'.
		}
		
		elements[lastElementIndex + 1] = ref;
		lastElementIndex++;
	}
	
	public void add(int index, Ball ref) {
		
		if(index<0 || index>lastElementIndex+1) {
			throw new IndexOutOfBoundsException();
		}
		
		// Make space available:
		
		if(lastElementIndex==elements.length-1) {
			Ball[] elements2 = new Ball[elements.length*2]; // Make a new one, but twice the size.
			for(int i=index; i<=lastElementIndex; i++) {
				elements2[i+1] = elements[i]; // Shift everything one over to make space at index 'index'.
			}
			elements = elements2;
		}
		
	}
	
	public Ball remove(int index) { // We are returning a 'Ball' type because when we remove an object we also want to return it back to the user.
		
		if(index<0 || index>lastElementIndex) {
			throw new IndexOutOfBoundsException();
		}
		
		Ball toReturn = elements[index];
		
		// Shift Operation (Shift to the left instead of right):
		for(int i=index; i<lastElementIndex; i++) {
			elements[i] = elements[i+1]; // Recipient is 'elements[i]'
		}
		
		lastElementIndex--;
		
		return toReturn;
	}
	
	// HOWEVER, this is WRONG/DANGEROUS:
	public boolean remove(Ball ref) { // If it accepts the 'Ball' object (will return 'true' or 'false'):
		
		for(int i=0; i<=lastElementIndex; i++) {
			if(elements[i].equals(ref)) { // Comparing the 'ref' so it will NEVER work because every address is different. // We need to compare the "state" of the object such as its 'x' and 'y' values (of the object called 'Ball').
				remove(i); // Call the other 'remove' method
				return true;
			}
		}
		return false;
		
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<=lastElementIndex; i++) {
			sb.append(elements[i]);
			if(i<lastElementIndex){
				sb.append("->");
			}
		}
		
		return sb.toString();
	}
	
	public void spillTheGut() { // Later on, after the development, we will delete this:
		
		for(int i=0; i<elements.length; i++) {
			if(elements[i]!=null) {
				System.out.print(elements[i]);
			}
			System.out.print("[null]");
		}
		System.out.println();
	}

}
