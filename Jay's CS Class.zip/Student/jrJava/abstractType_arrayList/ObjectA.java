package jrJava.abstractType_arrayList;

public class ObjectA {

	public static void main(String[] args) {
		
		MyArrayList list = new MyArrayList();
		
		// Now we are comparing the content or the state of each object (which in this case is the specific object's' 'x', 'y', 'color', 'size', etc.).
		list.add(new Ball(1, 1)); 
		list.add(new Ball(2, 2));
		list.add(new Ball(3, 3));
		
		ObjectB.doTheJob(list);

	}

}
