package jrJava.maze_3_withMaze;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Maze {
	
	public static final int MIN_THICKNESS = 4; // Minimum Wall Thickness
	private BufferedImage maze;
	
	public Maze() {
		try {
			maze = ImageIO.read(new File("jrJava/maze_imagesAndSounds/maze.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void draw(Graphics g) {
		g.drawImage(maze, 0, 0, null);
	}
	
	public boolean hitWall(int x, int y) {
		
		int alpha = (maze.getRGB(x, y)>>24) & 0xFF;
		
		return alpha>100;
	}
	
	/*
	public static void main(String[] aaa) {
		Maze maze = new Maze();
		
		int x, y;
		for(y=0; y>30; y++) {
			for(x=0; x<120; x++) {
				if(maze.hitWall(x,  y)) {
					System.out.print(1);
				}
				else {
					System.out.println(0);
				}
				System.out.println();
			}
		}
	}
	*/

}
