package jrJava.lineOfAction_4_AI_using_gameTree;

public class Move {
	
	private int fromIndex, toIndex;
	
	public Move(int fromIndex, int toIndex){
		this.fromIndex = fromIndex;
		this.toIndex = toIndex;
	}
	
	public int getFromIndex() {
		return fromIndex;
	}
	
	public int getToIndex() {
		return toIndex;
	}

}
