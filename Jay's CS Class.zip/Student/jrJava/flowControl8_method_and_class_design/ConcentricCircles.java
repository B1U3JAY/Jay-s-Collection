package jrJava.flowControl8_method_and_class_design;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class ConcentricCircles {

	public static void main(String[] args) {
		DrawingBoard board = new DrawingBoard(0, 0, 700, 700);
		Color color = new Color(0, 55, 200);
		Graphics g = board.getCanvas();
		
		drawConcentricCircles(g, color, 350, 350, 100, 10);
	}
	
	public static void drawConcentricCircles(Graphics g, Color color, int xC, int yC, int radius, int numberOfCircles) {
		
		int i;
		int increment = 0;
		
		for(i=1; i<=numberOfCircles; i++) {
			g.setColor(color);
			g.drawOval(xC-radius-increment, yC-radius-increment, 2*(2+increment), 2*(2+increment));
			increment += radius/numberOfCircles;
		}
	}
	
}
