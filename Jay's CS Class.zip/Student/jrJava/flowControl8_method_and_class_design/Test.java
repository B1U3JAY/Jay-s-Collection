package jrJava.flowControl8_method_and_class_design;

public class Test {

	public static void main(String[] args) {
		
		Radar.display(300, 300, 120);

	}

}
