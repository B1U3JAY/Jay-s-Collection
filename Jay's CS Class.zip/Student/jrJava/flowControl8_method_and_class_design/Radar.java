package jrJava.flowControl8_method_and_class_design;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Toolkit;

import resources.DrawingBoard;
import resources.Timer;

public class Radar {
	
	public static void main(String[] args) {
		
		display(300, 300, 100);
		
	}
	
	public static void display(int xC, int yC, int radius){
		
		DrawingBoard board = new DrawingBoard(200, 50, 600, 600);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		int i; //starting angle
		
		for(i=0; i<=3600; i++) {
			board.clear();
			
			drawGradientSector(g,  radius,  xC,  yC,  i);
			g.setColor(Color.DARK_GRAY);
			g.drawOval(xC-radius, yC-radius, 2*radius, 2*radius);
			board.repaint();
			
			if(i%360==90 || i%360==270) {
				Toolkit.getDefaultToolkit().beep();
			}
			
			timer.pause(10);
		}
		
	}
	
	public static void drawGradientSector(Graphics g, int radius, int xC, int yC, int startingAngle) {
		
		int angleSize = 40;
		int colorIncrement = 255/40;
		
		int i;
		for(i=1; i<=40; i++) {
			
			Color color = new Color(255-colorIncrement*i, 255, 255-colorIncrement*i);
			g.setColor(color);
			g.fillArc(xC-radius, yC-radius, 2*radius, 2*radius, startingAngle, angleSize);
			
			startingAngle++;
			angleSize--;
		}
	}

}
