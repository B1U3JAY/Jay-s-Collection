package jrJava.flowControl8_method_and_class_design;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Scanner;

import resources.DrawingBoard;
import resources.Timer;

public class BlackHole {
	
	public static void main(String[] args) {
		
		DrawingBoard board = new DrawingBoard(0, 0, 800, 800);
		Graphics g = board.getCanvas();
		Scanner sc = new Scanner(System.in);
		Timer timer = new Timer();
		int radius = 80;
		int increment = (800-2*radius)/100;
		int i;
		int x = 80;
		int y = 80;
		
		for(i=1; i<=100; i++) {
			board.clear();
			moveBlackHole(g, 150, 0, 0, 270, 220, 100);
			moveBlackHole(g, 0, 255, 0, x, y, radius);
			moveBlackHole(g, 0, 150, 230, 380, 400, 120);
			board.repaint();
			x += increment;
			timer.pause(20);
		}
		for(i=1; i<=100; i++) {
			board.clear();
			moveBlackHole(g, 150, 0, 0, 270, 220, 100);
			moveBlackHole(g, 0, 255, 0, x, y, radius);
			moveBlackHole(g, 0, 150, 230, 380, 400, 120);
			board.repaint();
			y += increment;
			timer.pause(20);
		}
		for(i=1; i<=100; i++) {
			board.clear();
			moveBlackHole(g, 150, 0, 0, 270, 220, 100);
			moveBlackHole(g, 0, 255, 0, x, y, radius);
			moveBlackHole(g, 0, 150, 230, 380, 400, 120);
			board.repaint();
			x -= increment;
			timer.pause(20);
		}
		for(i=1; i<=100; i++) {
			board.clear();
			moveBlackHole(g, 150, 0, 0, 270, 220, 100);
			moveBlackHole(g, 0, 255, 0, x, y, radius);
			moveBlackHole(g, 0, 150, 230, 380, 400, 120);
			board.repaint();
			y -= increment;
			timer.pause(20);
		}
	}
	
	
	public static void moveBlackHole(Graphics g, int red, int green, int blue, int xC, int yC, int radius) {
		Timer timer = new Timer();
		int i; // i represents the changing radius
		
		for(i=radius; i>0; i--) { 
			Color color = new Color(red*i/radius, green*i/radius, blue*i/radius);
			g.setColor(color);
			g.fillOval(xC-i, yC-i, 2*i, 2*i);
		}
	}
}

