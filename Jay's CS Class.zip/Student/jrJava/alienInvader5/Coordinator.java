package jrJava.alienInvader5;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;
import resources.Timer;

public class Coordinator {

	public static void main(String[] args)        {
		
		DrawingBoard board = new DrawingBoard (200, 50, 800, 750);
		Graphics g = board.getCanvas();
		Timer timer = new Timer();
		
		BattleShip ship = new BattleShip(400, 650);
		
		while(true) {
			AlienMotherShip.move();
			
			board.clear();
			AlienMotherShip.draw(g);
			ship.draw(g);
			board.repaint();
			timer.pause(50);
		}
	}

}
