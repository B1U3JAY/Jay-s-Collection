package jrJava.alienInvader5;

import java.awt.Color;
import java.awt.Graphics;

public class BattleShip {
	
	private int x;
	private int y;// top center of the BattleShip
	private Color color = Color.RED;
	private int height = 20;
	private int topWidth = 4;
	private int middleWidth = 20;
	private int bottomWidth = 60;
	
	private Torpedo[] torpedoes;
	
	public BattleShip(int x, int y) {
		this.x = x;
		this.y = y;
		
		torpedoes = new Torpedo[10];
	}

	public void respondToMouseDraggingByRepositioning() {
		
	}
	
	private void shootTorpedo() {
		for(int i=0; i<torpedoes.length; i++) {
			if(torpedoes[i]==null) {
				torpedoes[i] = new Torpedo(x, y, -10, this);
				break;
			}
		}
	}
	
	public void draw(Graphics g) {
		g.setColor(color);
		g.drawRect(x-topWidth/2, y, topWidth, height); // (x-topWidth/2, y) is the left hand corner point of the top rectangle on the Battle Ship.
		g.drawRect(x-middleWidth/2, y+height, middleWidth, height);
		g.drawRect(x-bottomWidth/2, y+2*height, bottomWidth, height);
		
		if (Math.random()<0.05){
			shootTorpedo();
		}
		
		for(int i=0; i<torpedoes.length; i++) {
			if(torpedoes[i]!=null) {
				torpedoes[i].move();
			}
			
			if(torpedoes[i]!=null) {
				torpedoes[i].draw(g);
			}
		}	
	}
	
	public void remove(Torpedo torpedo) {
		for(int i=0; i<torpedoes.length; i++) {
			if(torpedoes[i]==torpedo) {
				torpedoes[i] = null;
			}
		}
	}
}
