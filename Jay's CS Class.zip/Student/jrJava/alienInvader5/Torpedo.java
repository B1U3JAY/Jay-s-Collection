package jrJava.alienInvader5;

import java.awt.Color;
import java.awt.Graphics;

public class Torpedo {
	
	private static Color color;
	private static int width, height;
	private int x;
	private int y;
	private int vy; // We need vy < 0 in order to go up on the DrawingBoard.
	
	private BattleShip owningShip;
	
	static {
		color = Color.BLUE;
		width = 4;
		height = 12;
	}
	
	public Torpedo(int x, int y, int vy, BattleShip owningShip) {
		this.x = x;
		this.vy = y;
		this.vy = vy;
		this.owningShip = owningShip;
	}
	

	public void move() {
		y +=vy;
		
		if(y<100) { 
			owningShip.remove(this);
		}
		
		// Check whether if the collision happened or not!
		
	}
	
	public void draw(Graphics g) {
		g.setColor(color);
		g.drawRect(x-width/2, y, width, height);
	}

}
