package jrJava.linkedList1;

public class Test2 {

	public static void main(String[] args) {
		
		

	}

}
