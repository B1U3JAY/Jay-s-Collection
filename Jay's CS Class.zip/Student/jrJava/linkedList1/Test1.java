package jrJava.linkedList1;

public class Test1 {

	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		
		list.insertAtBeginning(1, 1.1);
		list.insertAtBeginning(2, 2.2);
		list.insertAtBeginning(3, 3.3);
		
		list.insertAtEnd(4, 4.4);
		list.insertAtEnd(5, 5.5);
		list.insertAtEnd(6, 6.6);
		
		// System.out.println(list.removeFirst());
		// System.out.println(list.removeFirst());
		// System.out.println(list.removeFirst());
		
		// System.out.println(list.removeEnd());
		// System.out.println(list.removeEnd());
		list.printAll();
		
		System.out.println(list.removeEnd());
		list.printAll();
		
		System.out.println(list.removeEnd());
		list.printAll();
		
		System.out.println(list.removeEnd());
		list.printAll();
		
		System.out.println(list.removeEnd());
		list.printAll();
		
		System.out.println(list.removeEnd());
		list.printAll();
	}

}
