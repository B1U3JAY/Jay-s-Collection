package jrJava.greetings;

public class GoodDay {
	
	public static void main (String[]  args) {
		System.out.println("Have a good day!");
	}
}
