package jrJava.hw1;

public class HomeWorkClass1 {

	public static void main(String[] args) {
		double priceOfRose = 3.50;
		double priceOfTulip = 4.20;
		int numberOfRose = 4;
		int numberOfTulip = 6;
		double totalCost = priceOfRose*numberOfRose + priceOfTulip*numberOfTulip;
		System.out.println("total cost is $" + totalCost);
	}
}

