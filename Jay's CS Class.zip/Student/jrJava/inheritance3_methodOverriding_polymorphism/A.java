package jrJava.inheritance3_methodOverriding_polymorphism;

public class A {
	
	public void mA() {
		System.out.println("A's mA().");
	}

}
