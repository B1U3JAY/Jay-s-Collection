package jrJava.inheritance3_methodOverriding_polymorphism;

public class Test {

	public static void main(String[] args) {
		
		B ref1 = new B();
		ref1.mA();
		
		A ref2 = new B(); // "What the object REALLY is" is a B OBJECT. So it will always execute B's mA method even if we have A's reference
		ref2.mA();
		
		A ref3 = new C(); // Same concept, but this time it REALLY is a C OBJECT. So it will always execute C's mA method even if there is A's reference.
		ref3.mA();

	}

}
