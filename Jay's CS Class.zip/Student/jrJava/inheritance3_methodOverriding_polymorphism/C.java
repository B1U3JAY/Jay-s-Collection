package jrJava.inheritance3_methodOverriding_polymorphism;

public class C extends B{
	
	public void mC() {
		System.out.println("C's mC().");
	}
	
	public void mA() {
		System.out.println("C's mA().");
	}

}
