package jrJava.inheritance3_methodOverriding_polymorphism;

public class B extends A{
	
	public void mB() {
		System.out.println("B's mB().");
	}
	
	public void mA() {
		System.out.println("B's mA().");
	}

}
