package jrJava.inheritance5_usingSuper;

public class B extends A{
	
	public void m() {
		super.m(); // This will access A's m() method.
		System.out.println("B's m() method");
		super.m(); 
	}

}
