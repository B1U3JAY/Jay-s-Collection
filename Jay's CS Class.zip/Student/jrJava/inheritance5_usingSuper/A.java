package jrJava.inheritance5_usingSuper;

public class A {
	
	public void m() {
		System.out.println("A's m() method");
	}

}
