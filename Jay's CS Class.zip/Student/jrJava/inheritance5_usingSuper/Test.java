package jrJava.inheritance5_usingSuper;

public class Test {

	public static void main(String[] args) {
		
		A obj = new B();
		obj.m();

	}

}
