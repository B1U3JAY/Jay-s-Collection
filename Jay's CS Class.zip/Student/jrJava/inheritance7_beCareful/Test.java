package jrJava.inheritance7_beCareful;

public class Test {
	
	public static void main(String[] args) {
		
		B ref = new B();
		
		System.out.println(ref.mmm(5)); // Executes A (since it has an int parameter)
		System.out.println(ref.mmm(5.0)); // Executes B (since it has a double parameter) CAREFUL: THIS IS METHOD OVERLOADING!!!!! B's method is not overriding A because parameters are different.
		
		// A ref = new B();
		// ref.mmm(5.0);
		
	}

}
