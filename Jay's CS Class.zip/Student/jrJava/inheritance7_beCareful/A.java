package jrJava.inheritance7_beCareful;

public class A {
	
	private int f = 10;
			
	public double mmm(int p) {
		return f*p;
	}

}
