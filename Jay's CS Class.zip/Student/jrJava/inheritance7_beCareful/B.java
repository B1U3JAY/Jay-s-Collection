package jrJava.inheritance7_beCareful;

public class B extends A{
	
	private int f = 20;
	
	// It is overLOADING not overRIDING
	public double mmm(double p) {
		return f*p;
	}

}
