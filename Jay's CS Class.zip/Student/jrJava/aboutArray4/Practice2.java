package jrJava.aboutArray4;

public class Practice2 {

	public static void main(String[] args) {
		
		// Arrays and For-Loops:
		
		int[] abc = {4, 1, 6, 8, 2, 6, 7, 0};
		
		// Most standard way of using a for-loop with an array:
		for(int i=0; i<abc.length; i++) {
			//System.out.println(abc[i]);
			abc[i] = abc[i] + 10; // abc[i] += 10;
		}
		
		for(int i=abc.length-1; i>=0; i--) { // Instead of going left to right, it goes right to left (Starts at the last element of the array)
			abc[i] = abc[i]*2;
		}
		
		for(int i=0; i<abc.length; i++) { 
			System.out.println(abc[i]);
		}

	}

}
