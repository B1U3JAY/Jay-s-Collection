package jrJava.aboutArray4;

public class Practice3 {

	public static void main(String[] args) {
		
		int[] fff = {2, 5, 6, 9, 11, 17, 21, 30, 0};
		printAll(fff);
		
		/*
		 WRONG SHIFTING:
		 fff[2] = fff[1];
		 fff[3] = fff[2];
		 fff[4] = fff[3];
		 fff[5] = fff[4];
		 ...
		 fff[8] = fff[7];
		*/
		
		/*
		 CORRECT SHIFTING:
		 fff[8] = fff[7];
		 fff[7] = fff[6];
		 fff[6] = fff[5];
		 fff[5] = fff[4];
		 ...
		 fff[2] = fff[1];
		*/
		
		for(int i=fff.length-1; i>1; i--) {
			fff[i] = fff[i-1]; // Override/Shifting
		}
		fff[1] = 3;
		printAll(fff);
		
	}
	
	public static void printAll(int[] ref) {
		for(int i=0; i<ref.length; i++){
			System.out.print(ref[i] + " ");
		}
		System.out.println();
	}

}
