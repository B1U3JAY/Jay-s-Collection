package jrJava.aboutArray4;

public class Practice1 {

	public static void main(String[] args) {
		
		int[] aaa = {4, 1, 3, 2, 7, -5};
		
		// int lastIndex = aaa.length - 1;
		// System.out.println(aaa[lastIndex]);
		System.out.println(aaa[aaa.length-1]);
		
		printLastElement(aaa);
	}
	
	public static void printLastElement(int[] ref) {
		
		System.out.println(ref[ref.length-1]);
		
		
	}

}
