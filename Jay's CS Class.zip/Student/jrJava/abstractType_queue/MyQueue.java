package jrJava.abstractType_queue;

// The concept is "FIFO" (First In, First Out), where the user can use a queue to put stuff in and take stuff out (based on what they first/recently put in).

// We will do this by using an array, without shifting the data:

public class MyQueue {
	
	// * We Will Learn Generic Type:
	
	private Object[] elements;
	private int front;
	
	public MyQueue(int size) {
		elements = new Object[size];
		front = -1;
	}
	
	public void enqueue(Object ref) {
		if(front==elements.length-1){ // If 'front' pointing at the very last element of the array, then we must create a new (double the size) array.
			throw new IndexOutOfBoundsException();
		}	
		// front++;
		// elements[front] = ref; // Put elements at new updated 'front'.
		// We can also use pre-incremeents:
		elements[++front] = ref;
	}
	
	public Object dequeue() { // Always pulling out from index '0'.
		// Special case (if there is nothing there):
		// It will still read from index '0' but if it is '-1' then we throw an exception:
		if(front==elements.length-1) {
			throw new IndexOutOfBoundsException();
		}
		
		Object temp = elements[0];
		
		for(int i=1; i<=front; i++) {
			elements[i-1] = elements[i]; // Left-shifting
		}
		
		front--;
		
		return temp;
	}
	
	public Object peek() {
		if(front==-1) {
			throw new IndexOutOfBoundsException();
		}
		return elements[0];
	}
	
	public boolean isEmpty() {
		return front==-1;
	}
	
	// ONLY FOR TESTING OR DEVELOPING PURPOSES:
	public void printAll() {
		for(int i=0; i<elements.length; i++) {
			System.out.println(elements[i] + " ");
			System.out.println();
		}
	}
	
}
