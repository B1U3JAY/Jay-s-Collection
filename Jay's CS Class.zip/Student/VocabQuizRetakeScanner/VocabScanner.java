package VocabQuizRetakeScanner;

public class VocabScanner {

	public static void main(String[] args) {
		
		
		
		
		
		

	}
}
