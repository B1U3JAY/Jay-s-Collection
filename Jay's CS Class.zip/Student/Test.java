import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("What is your name?");
		String name = scanner.nextLine();
		System.out.println("Your name is" + name);
		
		System.out.println("What is your age?");
		int age = scanner.nextInt();
		System.out.println("You are " + age + " years old");
		
		System.out.println("What is your grade?");
		double grade = scanner.nextDouble();
		System.out.println("Your grade is " + grade);
		
		System.out.println("what is one thing you want to change in the world?");
		String change = scanner.next();
		
		if(change=="no") {
			System.out.println("ok");
		}

	}

}
