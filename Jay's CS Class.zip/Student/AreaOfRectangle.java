
public class AreaOfRectangle {
	public static void main(String[] args) {	
		int width = 11;
		int height = 15;
		int area = width*height;
		System.out.println(area);
	}
}

