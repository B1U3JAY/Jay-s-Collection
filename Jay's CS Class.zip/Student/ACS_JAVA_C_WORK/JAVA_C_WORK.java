package ACS_JAVA_C_WORK;

public class JAVA_C_WORK {
	public static void main(String[] args) {
        /*
		int a = 0;
		int b = 0;
		int c = 0;
		int d = 0;
		*/
/*
		for(int i=0; i<100; i++) {
			if (i==0) {
				System.out.println("    *");
			}
			else if (i==1) {
				System.out.println("   **");
			}
			else if (i==2) {
				System.out.println("  ***");
			}
			else if (i==3) {
				System.out.println(" ****");
			}
			else if (i==4) {
				System.out.println("*****");
			}
		}
	}
}
*/	


		int k = 5;
		for (int i=1; i<=k; i++) {
//			for (int j=0; j<k-i; j++) {
//				 System.out.print(" ");
//			}
			for (int j=1; j<i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}

/*	
		for (int i=k; i>=1; i--) {
			for (int j=0; j<k-i; j++) {
				System.out.print(" ");
			}
			for (int j=0; j<i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
*/




/*		
				for(int k=0; k<10; k++) { 
		}
        System.out.println(a);
        
        for(int i1=0; i1<10; i1++) {
        		b--;
        		for(int j=0; j<10; j++) {
        				b++;
        		}
        }
        System.out.print(b);
        
        for(int i1=0; i1<5; i1++) {
        		d=0;
        		c++;
        		while(d<10) {
        				c++;
        				d++;
                }
           }
        	System.out.println(c);
       }
   }
}
*/
