package GradeCalculator;

import java.awt.Color;
import java.awt.Graphics;

import resources.DrawingBoard;

public class GPA {

	public static void main(String[] args) {

		/*DrawingBoard board = new DrawingBoard(150, 50, 700, 700);
		Graphics g = board.getCanvas();
		
			board.clear();
			g.setColor(Color.RED);
			g.fillOval(50, 50, 300, 300);
			board.repaint();
		*/
		double carrot = 0.72;
		double onion = 0.66;
		double potato = 0.54;
		double apple = 1.2;
		
		System.out.println("Total: " + (carrot*2 + onion*4 + potato*3 + apple*5));
	}

}
