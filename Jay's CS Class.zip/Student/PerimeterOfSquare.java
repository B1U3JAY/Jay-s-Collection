
public class PerimeterOfSquare {
	public static void main(String[] args) {	
		int length = 16;
		int perimeter = length*4;
		System.out.println(perimeter);
	}
}
