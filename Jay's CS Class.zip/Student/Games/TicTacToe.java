package Games;

import java.util.Scanner;

public class TicTacToe {
	
	static char[][] board = new char[3][3];
	public static String winner = "";
	public static Scanner scanner;

    public static void printBoard() {
        System.out.println("-------");
        for (int i=0; i < 3; i++) {
            System.out.print("|");
            for (int j=0; j < 3; j++) {
                if (board[i][j] == '\0') {
                    System.out.print(" |");
                } else if (board[i][j] == 'O' || board[i][j] == 'X') {
                    System.out.print(board[i][j] + "|");
                }

            }
            System.out.println();
            System.out.println("-------");
        }
    }

    public static void getInput() {
    	scanner = new Scanner(System.in);
    	
    	System.out.println("Enter Your Character ('O' or 'X'): ");
    	String c = scanner.next();
    	
    	System.out.println("Enter Your Row #:");
    	int row = scanner.nextInt();

    	System.out.println("Enter Your Column #:");
    	int col = scanner.nextInt();
    	
    	board[row][col] = c.charAt(0);
    }

    public static boolean isWinner() {
    	
    	// Horizontal
    	for(int i=0; i<3; i++) {
    		if(board[i][0] == board[i][1] && board[i][1] == board[i][2]) {
    			if (board[i][0] == 'O') {
    				winner = "O";
        			return true;
    			} else if (board[i][0] == 'X') {
    				winner = "X";
        			return true;
    			}
    			return false;
    		} 
    	}
    	
    	// Vertical
    	for(int i=0; i<3; i++) {
    		if(board[0][i] == board[1][i] && board[0][i] == board[2][i]) {
    			if (board[i][0] == 'O') {
    				winner = "O";
        			return true;
    			} else if (board[i][0] == 'X') {
    				winner = "X";
        			return true;
    			}
    			return false;
    		} 
    	}
    	
    	// Diagonal
    	for(int i=0; i<3; i++) {
    		if(board[0][0] == board[1][1] && board[0][0] == board[2][2]) {
    			if (board[i][0] == 'O') {
    				winner = "O";
        			return true;
    			} else if (board[i][0] == 'X') {
    				winner = "X";
        			return true;
    			}
    			return false;
    		} 
    		else if(board[2][0] == board[1][1] && board[2][0] == board[0][2]) {
    			if (board[i][0] == 'O') {
    				winner = "O";
        			return true;
    			} else if (board[i][0] == 'X') {
    				winner = "X";
        			return true;
    			}
    			return false;
    		} 
    	}
    	
    	/*
    	if(board[0][0]=='O' && board[0][1]=='O' && board[0][2]=='O') {
    		
    		return true;
    	} 
    	if(board[1][0]=='O' && board[1][1]=='O' && board[1][2]=='O') {
    		return true;
    	} 
    	if(board[2][0]=='O' && board[2][1]=='O' && board[2][2]=='O') {
    		return true;
    	}
    	
    	// Vertical
    	if(board[0][0]=='O' && board[1][0]=='O' && board[2][0]=='O') {
    		return true;
    	} 
    	if(board[0][1]=='O' && board[1][1]=='O' && board[2][1]=='O') {
    		return true;
    	} 
    	if(board[0][2]=='O' && board[1][2]=='O' && board[2][2]=='O') {
    		return true;
    	}
    	*/
    	
    	
    	return false;
    }

    public static void main(String[] args) {
        while(true) {
            printBoard();
            getInput();
            if(isWinner()==true) {
            	break;
            }
        }
        
        printBoard();
        
        System.out.println("The Winner is Player " + winner);
        
        scanner.close();
	}

}
