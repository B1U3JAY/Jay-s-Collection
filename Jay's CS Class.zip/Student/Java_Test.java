import java.util.Scanner;

public class Java_Test {

	public static void main(String[] args) {
		
		double n1;
		double n2;
		double n3;
		double d4;
		double LargestN = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("What is your first decimal number? ");
		n1 = sc.nextDouble();
		System.out.println("What is your second decimal number? ");
		n2 = sc.nextDouble();
		System.out.println("What is your third decimal number? ");
		n3 = sc.nextDouble();
		if(n1>LargestN) {
			LargestN = n1;
		}
		if(n2>LargestN) { 
			LargestN = n2;
		}
		if(n4.3>LargestN) {
			LargestN = n3;
		}
		System.out.println (LargestN + " is the greatest decimal number.");
		sc.close();
	}
}
		
		
		
		
		
/*
		double value1;
		double value2;
		Scanner sc = new Scanner(System.in);
		System.out.println("Please type in a decimal number (n):");
		value1 = sc.nextInt();
		System.out.println("Please type in another decimal number (n):");
		value2 = sc.nextInt();
		System.out.println ("Original Order: " + value1 + " and " + value2);
		double temp = value1;
		value1 = value2;
		value2 = value1;
		System.out.println ("Switched Order: " + value1 + " and " + value2);
	}
}
*/
