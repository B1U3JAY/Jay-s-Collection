package aaa.bbb.ccc;

public class PocketMoney {
	
	public static void main(String[] args) {
		
		int myMoney;
		int yourMoney;
		int total;
		
		
		myMoney = 99999;
		yourMoney = 23999;
		total = myMoney + yourMoney;
		
		System.out.println("I have $" + myMoney);
		System.out.println("You have $" + yourMoney);
		System.out.println("So, the total is $" + total);
	}

}
