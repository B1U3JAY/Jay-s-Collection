package HW_6;

public class HW_6 {
	public static void main(String[] args) {

		double priceOfApples;
		int numberOfApples;
		double priceOfOnions;
		int numberOfOnions;
		double priceOfWatermelons;
		int numberOfWatermelons;
		double total;
		
		priceOfApples = 6.25;
		numberOfApples = 12;
		priceOfOnions = 1.90;
		numberOfOnions = 15;
		priceOfWatermelons = 6.50;
		numberOfWatermelons = 2;
		
		total = priceOfApples*numberOfApples + priceOfOnions*numberOfOnions + priceOfWatermelons*numberOfWatermelons;
		
		System.out.println("The total cost will be $" + total + ".");
		

	}

}