
public class AverageOfThree {
	public static void main(String[] args) {	
		int x = 15;
		int y = 13;
		int z = 17;
		int average = ((x + y + z)/3);
		System.out.println(average);
	}
}